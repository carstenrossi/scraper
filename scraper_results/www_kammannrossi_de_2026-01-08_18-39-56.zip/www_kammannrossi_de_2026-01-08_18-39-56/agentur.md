---
url: https://www.kammannrossi.de/agentur
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Wer wir sind
---

# Kammann Rossi – Wer wir sind


#### Als eine der ältesten inhabergeführten Agenturen Deutschlands betreuen wir seit 1972 von Köln und München aus mit 20 Mitarbeitern internationale Konzerne und mittelständische Unternehmen aus der DACH-Region. Mit begeisternden Inhalten in Magazinen, Content Hubs und auf Social Media helfen wir unseren Kunden, ihre Ziele zu erreichen.


## STRATEGIE & KONZEPTION

Interne Kommunikation, Content Marketing, Reporting – vom Magazin bis zum Content Hub – Strategie mittels eigener Frameworks (Content Action, Triple E, Triple A)

## PRODUKTION & KREATION

Beratung, Text, Design, Film, Illustration, Produktion und Promotion – analog und digital unter dem Motto „Content drives action. Otherwise it's poetry.“

## TECHNOLOGIEN & TRANS­FORMATION

Wir setzen auf starke Partnerschaften und Technologien: HubSpot, Staffbase, Haiilo, pagestrip und unsere eigene KI-Suite "AssistantOS". Wir beherrschen aber nicht nur die Technologie, sondern bieten auch Enabling- und Change-Programme für die Implementierung bei euch.

## AUSGEZEICHNETE ARBEITEN VON KREATIVEN KÖPFEN


## DIE MENSCHEN HINTER KR


###### ARNE BÜDTS


#### Head of Design


#### Arne Büdts studierte Kommunikationsdesign in Düsseldorf und Köln und ist seit 2009 für Kammann Rossi tätig. Als Kreativ-Direktor ist er verantwortlich für Konzeption, Layout, Beratung und Umsetzung.


###### ARNE BÜDTS


#### Head of Design


###### CHRISTIAN DIEKMANN


#### Art Director


#### Christian Diekmann absolvierte zunächst eine Ausbildung zum Mediengestalter Digital & Print, bevor er an der KISD Fachhochschule in Köln Design studierte und sein gestalterisches Können und Wissen vertiefte.


###### CHRISTIAN DIEKMANN


#### Art Director


###### CHRISTIAN FILL


#### Managing Director


#### Als Geschäftsführer verstärkt er KammannRossi seit Dezember 2020 mit seiner Erfahrung aus rund 20 Jahren Content Marketing und Corporate Publishing.


###### CHRISTIAN FILL


#### Managing Director


###### JESSICA FRADIN


#### Office Management


#### Jessica Fradin ist seit 2008 als Assistentin der Geschäftsführung bei Kammann Rossi beschäftigt. In dieser Funktion kümmert sie sich um alle verwaltungstechnischen Belange und unterstützt hierbei sowohl die Mitarbeiter als auch die Geschäftsführung.


###### JESSICA FRADIN


#### Office Management


###### VIOLA KIRCHHOEFER


#### Managing Partner


#### Als Geschäftsführerin und Leiterin Controlling steuert Viola Kirchhoefer die internen Prozesse und Abläufe der Agentur. Sie bringt mehr als ein Jahrzehnt Erfahrung im Corporate Reporting und Corporate Publishing mit.


###### VIOLA KIRCHHOEFER


#### Managing Partner


###### BERND KIRCHHOEFER


#### Audio & Video Specalist


#### Seit 2015 ist Bernd Kirchhoefer bei Kammann Rossi für den Bereich Audio- und Videoediting zuständig. Er verfügt über eine 30jährige Berufserfahrung als Produzent, Regisseur und realisierte zahlreiche Film- und Videoprojekte für Fernseh- und Hörfunksender sowie Auftraggeber aus der Wirtschaft und Industrie.


###### BERND KIRCHHOEFER


#### Audio & Video Specalist


###### MANUEL KÖPP


#### Art Director


#### Manuel Köpp ist seit 2013 bei Kammann Rossi als Art Director tätig und arbeitet unter anderem für Kunden wie ARAG, Continental, GTAI und MANN+HUMMEL. Sein Schwerpunkt ist die Konzeption und Umsetzung von Layouts und Designs.


###### MANUEL KÖPP


#### Art Director


###### REBECCA LORENZ


#### Senior Editor


#### Seit über sieben Jahren lebt und liebt Rebecca Lorenz das Agenturleben. Sie verfügt über Erfahrung in der Magazin-Produktion, im Content Marketing sowie im Projektmanagement.


###### REBECCA LORENZ


#### Senior Editor


###### VERENA MATL


#### Art Director


#### Verena Matl verfügt über langjährige Erfahrung sowohl bei der Umsetzung von Kunden- und Mitarbeitermagazinen, Geschäftsberichten, Corporate Designs und Kampagnen als auch im Bereich Animation und Video.


###### VERENA MATL


#### Art Director


###### KATHERINA MOSER


#### Head of Project Management & Production


#### Katherina Moser, geb. Schneider ist seit 2006 Projektmanagerin und Beraterin bei Kammann Rossi und in dieser Funktion tätig für mittelständische und große Unternehmen wie zum Beispiel ARAG, Carl Zeiss, Clariant, Continental, Henkel oder MANN+HUMMEL. Seit 2017 leitet sie den Bereich Projektmanagement und Produktion.


###### KATHERINA MOSER


#### Head of Project Management & Production


###### MARION MÜLLER-GOTTHARD


#### Project Management & Consultant


#### Seit 2001 ist sie Projektmanagerin bei Kammann Rossi in den Bereichen Reporting und Corporate Publishing (Print und Online). Als Projektleiterin ist sie verantwortlich für mittelständische und große Unternehmen aus den verschiedensten Branchen, z.B. ARAG, BDEW, GTAI, MANN+HUMMEL, SAP und UBS Fund Management (Switzerland) AG.


###### MARION MÜLLER-GOTTHARD


#### Project Management & Consultant


###### MORITZ PFINGSTEN


#### AI & Digital Consultant


#### Bei Kammann Rossi setzt Moritz sein Wissen vor allem bei der inhaltlichen und strategischen Kundenberatung ein. Sein Fokus liegt auf der Begleitung von Change- und Transformationsprojekten. In seiner aktuellen Rolle treibt Moritz Pfingsten die Weiterentwicklung von AssistantOS voran.


###### MORITZ PFINGSTEN


#### AI & Digital Consultant


###### CARSTEN ROSSI


#### Managing Partner


#### Als Geschäftsführer und Experte für Content Marketing berät Carsten Rossi große und mittelständische Unternehmen auf ihrem Weg zur Content Excellence. Mit AssistantOS treibt Carsten Rossi aktuell eine innovative KI-Lösung voran, die Kommunikationsprozesse revolutioniert und Unternehmen ermöglicht, sich auf ihre Kernaufgaben zu konzentrieren.


###### CARSTEN ROSSI


#### Managing Partner


###### MARC RIBBROCK


#### Head of Content & Strategy


#### Marc Ribbrock ist Leiter Content & Strategie bei Kammann Rossi und seit über 15 Jahren in den Bereichen Corporate Publishing und Content Marketing tätig. Sein Wissen und seine Erfahrungen setzt er vor allem bei der Erarbeitung von Content Strategien und deren Umsetzung ein.


###### MARC RIBBROCK


#### Head of Content & Strategy


###### JÖRG SCHNEIDER


#### Illustrator & Layouter


#### Jörg Schneider ist seit 2008 in den Bereichen Layout, Illustration und Produktion bei Kammann Rossi in Print- und Web-Anwendungen tätig. Er betreut unter anderem Unternehmen wie Dr. Kleeberg & Partner oder Atruvia vom grafischen Konzept bis zur Realisation.


###### JÖRG SCHNEIDER


#### Illustrator & Layouter


###### FLORIAN STÜRMER


#### Digital & Technical Specialist


#### Florian Stürmer ist bereits seit 2009 bei Kammann Rossi. Als Digital Consultant verantwortet er die Umsetzung neuer technischer Trends und ist für die Implementierung von Online-Projekten zuständig. Aktuell widmet er sich der Entwicklung von AssistantOS, einer KI-basierten Lösung, die als kreativer Assistent den Fokus wieder auf das Wesentliche lenkt.


###### FLORIAN STÜRMER


#### Digital & Technical Specialist


###### JENS TAPPE


#### Senior Art Director


#### Jens Tappe studierte Kommunikationsdesign in Köln und verfügt über nunmehr 24 Jahre Erfahrung als Designer für Geschäfts- und Nachhaltigkeitsberichte. Als Senior Art Director weiß er, wie man die Fäden zusammenhält und ist bei Kammann Rossi von der Konzeption über das Layout bis hin zum Projektmanagement in namhafte Projekte involviert.


###### JENS TAPPE


#### Senior Art Director


###### MARTINA THELEN


#### Content Strategist & Platform Specalist


#### Martina Thelen hat irgendwann mal Kommunikationsdesign studiert, aber bei Kammann Rossi schnell die Liebe zu Sozialen Medien, Networking und Kundenberatung entdeckt. Inzwischen berät sie Kunden bei der Erarbeitung einer Content Strategie und deren Umsetzung.


###### MARTINA THELEN


#### Content Strategist & Platform Specalist

