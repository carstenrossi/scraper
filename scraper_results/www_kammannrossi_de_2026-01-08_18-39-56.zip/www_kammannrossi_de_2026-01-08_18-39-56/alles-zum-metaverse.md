---
url: https://www.kammannrossi.de/alles-zum-metaverse
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Know-How – Alles zum Metaverse
---

# Kammann Rossi – Know-How – Alles zum Metaverse

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### KNOW-HOW@KR


# Einführung ins Metaverse


## /(Fast) Alles in einer Liste

vonCarsten Rossi| 27.09.2022 |
Schnelleinstieg
- Warum das Metaverse
- Die Grundlagen
- Organisationen
- Corporate Metaverse Plattformen
- Mal-reinsehen Plattformen
- Veranstaltungen
- KR und das Metaverse
- Metaverse News
- Kontakt und Impulswebinar
Schnelleinstieg
- Warum das Metaverse
- Die Grundlagen
- Organisationen
- Corporate Metaverse Plattformen
- Mal-reinsehen Plattformen
- Veranstaltungen
- KR und das Metaverse
- Metaverse News
- Kontakt und Impulswebinar

#### Warum das Metaverse?

Kammann Rossi ist im Metaverse aktiv. Wir haben mittlerweile eine eigene Academy, Carsten Rossi istLableiterim Ressort Metaverse des BVDW, wir haltenVorträgeund gebenImpulswebinare, z.B. bei der scm, dem CMF, auf der dmexco und bei Kongress Media und wirtweeten und posten, was das Zeug hält..Warum?Weil wir daran glauben, dass das Metaverse das Web 3.0 (*) sein wird, also die "nächste Generation Internet". Nicht heute, nicht morgen, aber in 5-10 Jahren wird es das Web 2.0 abgelöst haben undunsere Nutzererfahrung wird dann vor allem eins sein: immersiv.
Wir raten zur Zeit niemandem "zu wechseln". Im Hype Cycle sind wir gerade in der Phase derEarly Adopter. Aber wir raten dazu, rechtzeitig zu verstehen, sich vertraut zu machen, zu pilotieren und Chancen zu nutzen, die sich schon ergeben müssen. DieseLinkliste(**) dient genau dazu:es Ihnen zu erleichtern, sich umzusehen und up-to-date zu bleiben. Wie man es nun einmal tut, wenn man ein Profi ist und die Welt verstehen will.
Wir konzentrieren uns dabei übrigens auf Informationen, die für unsere Kunden besonders interessant sind, d.h. für MItarbeiter der internen und Unternehmenskommunikation. Industrielle Anwendungen und Informationen dazu nehmen wir z.B. hier nicht auf.
Übrigens: wer mehr Links für uns hat, darf sich gerne melden. Wir nehmen alles auf, was passt. Einfach eine Email anCarsten Rossischicken.(*) Bitte das"Web 3.0" nicht mit dem "web3" verwechseln. Ersteres ist die "nächste Generation" des Internets, "web3" hingegen bezeichnet den Technologiestack rund um Blockchains, NFT und Crypto.(**) Diese Listen werden wir kontinuierlich aktualisieren. Deshalb am besten einen Bookmark setzen.

#### Die Grundlagen

Links zu Definitionen, Einführungen und Übersichtsdokumenten. Und, natürlich, gleich zu Beginn, die gemeinsam mit dem BVDW erarbeitete ultimative Definition:
> "Die ultimative Vision des Metaverse ist ein dezentralisiertes, interoperables, beständiges und mit allen Sinnen wahrnehmbares, digitales Ökosystem mit unbegrenzter Nutzerkapazität. Es wird sowohl in einer erweiterten (AR) als auch in einer rein virtuellen Realität (VR) mit der physischen Welt koexistieren. Das voll entwickelte Metaverse wird mit dem realen Leben verschmelzen und unsere Gesellschaft und die Art und Weise, wie wir uns vernetzen, miteinander arbeiten, leben und mit Marken interagieren, grundlegend verändern."
"Die ultimative Vision des Metaverse ist ein dezentralisiertes, interoperables, beständiges und mit allen Sinnen wahrnehmbares, digitales Ökosystem mit unbegrenzter Nutzerkapazität. Es wird sowohl in einer erweiterten (AR) als auch in einer rein virtuellen Realität (VR) mit der physischen Welt koexistieren. Das voll entwickelte Metaverse wird mit dem realen Leben verschmelzen und unsere Gesellschaft und die Art und Weise, wie wir uns vernetzen, miteinander arbeiten, leben und mit Marken interagieren, grundlegend verändern."
- Infoblatt des BVDW(mit Definition und Technologieüberblick)
- Mark Zuckerbergs "Meta"-Präsentationauf der Connect 2021
- Der schnellste Überblick:Das Buch "30 Minuten Metaverse" von Collin Croome.
- Umfassendster Einstieg: Das Buch "Das Metaverse: Und wie es alles revolutionieren wird" von Mathew Ball.Viel besser als der TItel klingt und auch mit einer sehr nützlichen Definition:“A massively scaled and interoperable network of real-time rendered 3D virtual worlds that can be experienced synchronously and persistently by an effectively unlimited number of users with an individual sense of presence, and with continuity of data, such as identity, history, entitlements, objects, communications, and payments.”Ball, Matthew. The Metaverse: And How It Will Revolutionize Everything (S.29). Liveright. Kindle-Version, abgerufen am 2. Oktober 2022)
- Corporate Playbookdes BVDW: How to enter the Metaverse.
- Bitkom: Wegweiser in das Metaverse
- Metaverse und web3 im Gartner Hype Cycle
- Die größten Metaverse Plattformen nach aktiven Usern
- Metaverse Market Map- von Infrastruktur bis Experience
- Die Metaverse Wertschöpfungskette("7 Layers")

#### Organisationen

Institutionen, die einem weiterhelfen oder die das Metaverse mitgestalten.
- BVDW- der beste Verband 😉 mit einem eigenen Ressort für das Metaverse.
- Der Bitkom zum Metaverse.
- Metaverse Standards Forum- mehr als 1500 Unternehmen und ein Thema.
- IEEE- Diese Ingenieure und IT Fachleute veröffentlichen sehr viel zum Thema.

#### Best Practices und Cases

Dies kann natürlich nur eine beispielhafte Auswahl sein - wir tragen sehr breit alles zusammen was unserer Meinung nach innovativ und manchmal nachahmenswert ist. Wir berücksichtigen Projekte aus den Bereichen VR, AR und web3/NFT.
- Unser Lieblingsprojekt:Non Fungible Animalsvom WWF. Endlich mal NFTs für einen guten Zweck.
- NochmalWWF: Eine virtuelle Welt für einen Wal.
- Natürlich viele Autos überall. Zum Beispiel Mini mit demMiniverse.
- Augmented Reality als Showroom in der Lobby,bei Rehau.
- Der klassische Showroom in VR, hier beiHAWE.
- Anzeigen gleichzeitig in Instagram und decentraland schalten? Geht mit42 Meta.
- Die SAPAcademy For Customer Successin einer VR Umgebung.
- Natürlich, die Mode:Gucciin Roblox, außerdemNike und Adidasüberall.

#### Corporate Metaverse Plattformen

Der einfachste Weg zu einem "Corporate Metaverse" ist es, eine der vorhandenen Software as a Service Plattformen zu nutzen und sich dort einen Meetingraum, eine Event-Location oder eine ganze "Welt" zu mieten. Hier ein paar Anbieter.
- RAUM- definitiv der bestaussehendste Anbieter, aus unserer Heimatstadt Köln.
- FrameVR- nicht so schön, aber enorm einfacher (kostenloser) Einstieg. Browser reicht,
- MeetinVR.Für Meetings unschlagbar.
- Spatial. Toll für Kunst und Ausstellungen.
- rooom, aus Jena, Virtual Reality UND Augmented reality.
- Und noch ein paar, die wir noch nicht ausprobiert haben:Glue,Nextmeet,PixelMax.

#### "Mal reinsehen"-Plattformen

Hier ein paar Links zu den großen Metaverse Plattformen, von denen alle immer reden. Manche funktionieren wie Spiele, andere wie Städte und einige wie Vergnügungsparks.
- Decentraland: teure Immobilien, aber nur bei Events was los.
- The Sandbox: So eine Art Minecraft auf der Blockchain.
- Roblox: Uralt, sehr fancy, sehr beliebt - und so eine Art Minecraft ohne Blockchain.
- AltspaceVR: Microsofts Schlachtschiff und eine VR Metaverse World, wie man sie sich vorstellt.
- VR Chat: Umfassendste soziale Erfahrung, je nach ausgewählter Umgebung braucht man aber gute Nerven. Aber die Biennale war auch schon da.
- Horizon Worlds: Metas Schlachtschiff, in Deutschland leider erst "bald" verfügbar.

#### Veranstaltungen

Ein paar ausgewählte Veranstaltungen für 2022. Ehrlich gesagt gibt es unzählige, aber ein paar wollen wir empfehlen oder sind selber daran beteiligt.
- Lunch-Session: Ist das Metaverse oder kann das weg?(CMF)-  20. Oktober 2022
- Metaverse Fashion Summit- 26.-28. Oktober 2022
- NTR - The Metaverse Summit(BVDW) - 1. und 2. Dezember 202
- Metaverse Meetup Köln: ca. alle 2 Monate
- Metaverse Events Calendar
- Event Liste bei Google

### Was wir so treiben und tun

- Januar 22:Kammann Rossi nutzt dreidimensionale und immersive Technologien, um einen neuen Markenauftritt für einen B2B Kunden zu entwickeln.
- Februar 2022:Kammann Rossi ist Gründungsmitglied des neugeschaffenenRessorts Metaverse im Bundesverband der Digitalen Wirtschaft(BVDW).Weitere Unternehmen, die zur Gründung mit dabei sind, sind u.a. Google, Meta, Telekom, Ströer, Digitas Pixelpark.
- April 2022:Unser Geschäftsführer Carsten Rossi wird Leiter des Labs "Society" im Ressort Metaverse des BVDW.
- Juni 2022:Kammann Rossi wird Mitglied imMetaverse Standards Forum.
- Juli 22022:Carsten Rossi wird von Thomas Riedel in seinemMetaverse Podcastinterviewt
- August 2022:Carsten Rossi veröffentlicht einen Kommentar in der Internetworld. Die wenig dezente Überschrift: "Das Metaverse ist ein Knaller"
- September 2022:Carsten Rossi spricht im Podcast "Social Media Schnack" zum Thema "Aufbruch in eine neue Welt ... oder doch nicht?"
- September:Carsten Rossi spricht auf der dmexco unter dem Titel "Welcome to the Metaverse 2022: Navigating the unknown"
- September 2022:Kammann Rossi auf den Inkometa Days zum Thema "Metaverse in der IK – Was können wir damit anfangen und wie?"
- Oktober 2022:Carsten Rossi startet seinen Podcast "Das Metaverse in drei Minuten".
- November 2022:Kammann Rossi entwickelt einen immersiven Showroom für einen Technologiekunden
- November 2022:Kammann Rossi startet eine "Lernreise Metaverse" zusammen mit Kongress Media
- November 2022:Die Kammann Rossi Metaverse Academy aufSpatialgeht live.
- Dezember 2022:Kammann Rossi unterstützt Deutschland größten Metaverse SummitNTR.land. Carsten Rossi ist dort als Keynote Speaker und Moderator vertreten.
- Januar 2023:Wir launchen"MORE REALITY", unsere Services für die Metaverse Economy. Unsere neue Metaverse Produktlinie bietet standardisierte, aber natürlich adaptierbare, Lösungen für die Interne Kommunikation und das Content Marketing. Unser Serviceangebot umfasst aktuell die folgenden Leistungen:

##### "More Internal Reality" - Das Metaverse in der Internen Kommunikation

- "Metaverse Editorials", Erweiterung von gedruckten und digitalen Mitarbeitermagazinen per Augmented Reality und Virtual Reality
- Immersive Meetings und VR-Events, z.B. für Change Kommunikation, Townhalls, Q&As, Workshops etc
- Immersives Recruitingund Onboarding
- Immersiv gestaltete Foyers, Ausstellungen, Messen und Jubiläen per VR und AR

##### "More External Reality" - Das Metaverse im Content Marketing

- "Metaverse Editorials",Erweiterung von gedruckten und digitalen Content Hubsper Augmented Reality und Virtual Reality
- ImmersiveProdukt-, Marken- und Servicepräsentationen(Showrooms, Virtuelle Touren, Demos, Insides, Experiences, Walkabouts)
- Storytelling-Beratungund Konzeption für redaktionelle Metaverse-Produktionen
- NFT-Servicesfür PR und Marketing (ETH- bzw. PoS-Blockchains only)
- Januar 2023:Carsten Rossi bietet zusammen mit Kongress Media den zweiten Teil seiner "Lernreise Metaverse" an.

### Metaverse News

Auf Scoop.it kuratiert Carsten Rossi täglich neue Nachrichten zu immersiven Erfahrungen, Social VR & AR und zur Zukunft des Metaverse. Für den ganzen Blick einfach auf das Bild  klicken.

### Kontakt und Impulswebinar

