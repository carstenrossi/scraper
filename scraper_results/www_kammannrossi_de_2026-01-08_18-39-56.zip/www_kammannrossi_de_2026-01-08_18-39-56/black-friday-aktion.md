---
url: https://www.kammannrossi.de/black-friday-aktion
scraped_at: 2026-01-08 18:39
title: Black Friday Aktion
---

# Black Friday Aktion


# Black Weeks bei KR


#### Die Black Weeks bei Kammann Rossilaufen vom 3. bis 28. November 2025. In diesem Zeitraum geben wir ausgewählte Agentur-Services zu Sonderkonditionen frei. Die Anzahl der Deals ist begrenzt, damit wir die gewohnte Qualität garantieren können. Sie beauftragen im Aktionszeitraum, starten das Projekt aber flexibel in den kommenden Wochen (spätester Start bis 31.03.2026). Transparent, fair und auf Ergebnisse ausgerichtet.


## Sichern Sie sich jetzt Ihren Top-Deal-Aktionszeitraum:3. – 28. November 2025


#### CONTENT-STRATEGY-SPRINT


#### DigitalisierungMagazin


#### KI-ENABLINGLIGHT


#### WILDCARD:Stundenkontingent


##### DEAL 1


## IHRE STRATEGIE Innerhalb von 3 Wochen

Sie wollen auf dem schnellsten Wege zu einer klaren Content-Strategie? Wir liefern den Plan – kompakt, messbar, umsetzbar.
Innerhalb von3 Wochenentwickeln wir gemeinsam mit Ihnen einenContent-Strategy-Blueprintmit Audit, Themenarchitektur, Roadmap und KPI-Framework. Alles, was Sie brauchen, um von Strategy zu Action zu kommen.
Ob als Agenturleistung oder Co-Creation-Sprint – am Ende steht eine Strategie, die sofort wirkt.

##### Das bekommen Sie von uns


#### Content-Strategy-Blueprint

- Executive Summary mit Key Insights
- Content-Audit-Light-Zusammenfassung
- Zielgruppen-Matrix
- Themenwelten, Themen-Architektur, Kanal-Strategie
- 90-Tage-Roadmap
- KPI-Vorschläge (alternativ: Template-Entwicklung für KPI-Dashboard)
Unser Black-Weeks-Add-on
- Content Calendar Template (3 Monate)

#### Unser Black-Weeks-Preis: 22.000 €


###### (regulär: 30.000€)


###### Flash-Preis (bei Buchung bis zum 8. November):minus 10 Prozent


## FAQ ZUM 3-WOCHEN-STRATEGY-SPRINT


##### Was bekomme ich nach 3 Wochen?


##### Deckt der Sprint eine komplette Content-Strategie ab?

Nicht ganz – und das ist Teil des Konzepts.Der 3-Wochen-Sprint schafft diestrategischen Grundlagen, auf der Sie Ihre Content-Arbeit gezielt ausbauen können.Er bietet Struktur, Prioritäten und messbare Ziele – also alles, was Sie brauchen, um schnell und sicher Entscheidungen zu treffen.Eine umfassende, tiefgreifende Content-Strategie über alle Unternehmensbereiche hinweg wäre ein mögliches Folgeprojekt. Der Sprint ist Ihrschneller und wirkungsvoller Startpunkt.

##### Wie läuft der 3-Wochen-Sprint ab?

Sie übergeben uns alle Materialien entsprechend der Mindestanforderungen, die für die Erstellung der Content-Strategie notwendig sind (z. B. Kernbotschaften, Ziele, Zielgruppen, Kanäle).
Phase 1:Analyse & Zielgruppen-MappingPhase 2:Strategieentwicklung & ThemenarchitekturPhase 3:Formate, Prozesse & GovernancePhase 4:KPI-Framework, Präsentation & Handover

##### Was ist im Preis enthalten – und was nicht?

ImPreis (22.000 €)sind ein digitaler Kick-off, alle Analysen und die Präsentation des finalen Blueprint mit bis zu 30 Seiten enthalten.Nicht enthalten sindtiefgehende SEO-Audits, komplexe Personas oder Performance-Setups– der Fokus liegt klar aufStrategie, Struktur und Umsetzbarkeit. Optional können Sie ein90-Tage-Support-Paketbuchen, um den Transfer in die Praxis zu begleiten.

##### Für wen ist der Strategy-Sprint ideal?

Für Unternehmen, dieschnell Klarheit und Richtungbrauchen – zum Beispiel bei einem Relaunch, Strategiewechsel oder neuen Kommunikationszielen.Ideal fürMarketing- und Kommunikationsverantwortliche, die eineklare, messbare Strategiegrundlagewünschen, ohne monatelange Analysephasen.Kurz gesagt:Für alle, diein 3 Wochenmehr erreichen wollen als andere in drei Monaten.

##### DEAL 2


## Endlich Online – Ihre Magazin-Digitalisierung in nur 3 Wochen

Printmagazine haben keine Zukunft. Das sagen44 Prozent der Deutschen. Trotzdem zeigt die Studie „Die Zukunft der Mitarbeiterzeitung” von Kammann Rossi und SCM, dass 74,6 Prozent der Unternehmen in Deutschland weiterhin ein Mitarbeitendenmagazin haben.
In nur 3 Wochen zeigen wir Ihnen, wie Ihr bestehendes Mitarbeitendenmagazin als digitale Ausgabe aussehen kann.

##### Das bekommen Sie von uns


#### Mitarbeitenden-Magazin Digital

- Design-Konzeption
- Bestandsaufnahme und Analyse des aktuellen Mitarbeitendenmagazins (Print)
- Digitalisierung des Grunddesign
- Mini-Guidelines (Farben/Typo/Anwendungen)
- Vorschlag zur technischen Umsetzung
- Klick-Dummy
Unser Black-Weeks-Add-on
- Vorschläge zur Verbesserung der digitalen Experience (Umfragen, Videos etc.)

#### Unser Black-Weeks-Preis:7.500 €


###### (regulär 10.000€)


###### Flash-Preis (bei Buchung bis zum 8. November):minus 10 Prozent


## FAQ ZUR MAGAZIN-DIGITALISIERUNG


##### Was bekomme ich nach den 3 Wochen?

Sie erhalten Ihr bestehendes Mitarbeitendenmagazin als Klick-Dummy (Startseite und 8 Artikel) inklusive einer ausführlichen Präsentation zur Konzeption (bis zu 30 Seiten) auf Basis der Bestandsaufnahme und Analyse einer bestehenden Print-Ausgabe sowie kompakte Mini-Guidelines (Farben/Typo/Anwendung light). Zusätzlich erhalten Sie Vorschläge zur Verbesserung der digitalen Experience.

##### Wie genau läuft die Digitalisierung ab?

Sie übergeben uns aktuelle Printausgaben, das Corporate-Design-Manual und ggf. Leserfeedback.Wir analysieren und bewerten zunächst Ihr aktuelles Mitarbeitendenmagazin. Anschließend erstellen wir anhand einer bestehenden Ausgabe einen Klick-Dummy (Startseite und 8 Artikel). Am Ende erhalten Sie den Link zum Klick-Dummy inklusive einer Präsentation zur Vorgehensweise und Optimierungsmöglichkeiten.

##### Was ist im Preis enthalten – und was nicht?

Im Preis enthalten sind der Klick-Dummy und die Präsentation zur Konzeption (bis zu 30 Seiten). Nicht enthalten sind umfangreiche Neukonzeptionen, zusätzliche Ausgaben oder technische Implementierungen.

##### Für wen ist die Digitalisierung MAZ ideal?

Das Angebot richtet sich an Unternehmen, die ihr bestehendes Mitarbeitendenmagazin zeitgemäß und zukunftssicher digitalisieren möchten, ohne eine komplette Neuentwicklung zu benötigen. Ideal für alle, die ihr Magazin erhalten, aber effektiv digital weiterentwickeln wollen.

##### DEAL 3


## KI, die wirkt – Enabling für Ihre Kommunikation in 3 Monaten

KI hat das Potenzial, die Arbeit von Unternehmenskommunikation und Marketing grundlegend zu verändern. Doch die technische Implementierung ist nur der erste Schritt – entscheidend ist, wie gut Ihr Team KI in die täglichen Abläufe integriert.
Unser strukturiertes Adoption-Programm setzt genau hier an: Wir begleiten Sie drei Monate lang auf dem Weg zu nachhaltigem KI-Einsatz in der Kommunikation.

##### Das bekommen Sie von uns


#### KI-Enabling light(in 3 Monaten)

- Kick-off-Workshop „KI-Grundlagen für Kommunikator*innen“
- Maßgeschneiderte KI-Guidelines für Ihr Team
- AI-Bootcamp mit Kurz-Impulsen & praktischen Challenges
- Gemeinsame Ermittlung der wichtigsten Use-Cases
- Kontinuierlicher Support durch regelmäßige AMAs („Ask-me-anything“)
Unser Black-Weeks-Add-on:
- Nutzung der agentureigenen KI-Plattform „AssistantOS“ für 3 Monate

#### Unser Black-Weeks-Preis: 12.000 €


###### (regulär 18.000€)


###### Flash-Preis (bei Buchung bis zum 8. November):minus 10 Prozent


## FAQ ZUM KI-ENABLING LIGHT


##### Was bekomme ich in den 3 Monaten?


##### Wie genau läuft das KI-Enabling ab?

Das Programm erstreckt sich über drei Monate und folgt einem strukturierten Ansatz: Nach einem gemeinsamen Kick-off-Workshop entwickeln wir in Zusammenarbeit Ihre kommunikationsspezifischen Richtlinien und identifizieren relevante Use-Cases. Im AI-Bootcamp vertiefen Sie Ihr Wissen durch praxisnahe Impulse und Challenges, während regelmäßige „Ask Me Anything“-Sessions kontinuierliche Unterstützung bei allen weiteren Fragen rund um die Arbeit mit KI bieten. Für die gesamte Programmdauer stellen wir Ihnen eine zentrale Community-Plattform zur Verfügung, auf der wir uns austauschen können und alle relevanten Materialien zur Verfügung stellen. Die Nutzung unserer agentureigenen KI-Plattform „AssistantOS“ bietet zusätzliche praktische Unterstützung.

##### Was ist im Preis enthalten – und was nicht?

Im Preis enthalten ist die dreimonatige Begleitung Ihres Teams im Rahmen des KI-Enabling-Programms inklusive Kick-off-Workshop, AI-Bootcamp, regelmäßiger „Ask Me Anything“-Sessions, der Entwicklung kommunikationsspezifischer Richtlinien und Use Cases sowie der Nutzung der Community-Plattform und „AssistantOS“ für drei Monate. Nicht enthalten sind weitergehende technische Implementierungen, individuelle Softwareentwicklung oder der Erwerb zusätzlicher Lizenzen außerhalb von „AssistantOS“.

##### Für wen ist das KI-Enabling light ideal?

Das Angebot richtet sich an Kommunikations- und Marketingteams, die strukturiert in die professionelle KI-Nutzung einsteigen und KI strategisch in ihre Arbeitsabläufe integrieren wollen – mit fundiertem Grundlagenwissen, kommunikationsspezifischen Richtlinien und maßgeschneiderten, praxisnahen Use-Cases. Ohne komplexe technische Hürden, sondern mit direkter Anwendbarkeit.

##### DEAL 4


## Ihre flexible Agentur-Assistenz –Wildcard für Design, Redaktion & KI

Sie haben kein konkretes Anliegen, suchen aber Unterstützung in den Bereichen Design, Redaktion oder KI?
Nutzen Sie uns als flexible Agentur-Assistenz für alle anfallenden grafischen, redaktionellen und KI-bezogenen Aufgaben – von der visuellen Gestaltung über Textproduktion bis hin zum Prompt Engineering für KI-Assistenten und Content-Automation.
Testen Sie unser Angebot bis zu 3 Monate lang – Sie entscheiden, wie viele Stunden Sie brauchen!

##### Das bekommen Sie von uns


#### Wildcard Kontingent

- Redaktion:Interviews, Blogbeiträge, LinkedIn-Posts etc.
- Design:Layouts, Visuals, Grafiken, Videos, Animationen etc.
- KI & Prompt Engineering: Entwicklung und Optimierung von Prompts, Training und Feintuning von KI-Assistenten für Copilot, ChatGPT, Claude, Gemini und AssistantOS
- S– 20 Std./Monat: 2.300 €(regulär: 2.560 €)
- M– 40 Std./Monat: 4.500 €(regulär: 5.120 €)
- L– 60 Std./Monat: 6.800 €(regulär: 7.680 €)

#### Unser Black-Weeks-Preis:ab 2.300 €/Monat


###### Flash-Preis (bei Buchung bis zum 8. November):minus 10 Prozent


## FAQ ZUM WILDCARD STUNDENKONTINGENT


##### Was bekomme ich im Monat?


##### Kann das Stundenkontingent auf den Folgemonat übertragen werden?

Bis zu 20% des Stundenkontingents können in den Folgemonat übertragen werden (Roll-over).

##### Wie behält man den Überblick über die geleisteten Stunden?

Sie erhalten einen wöchentlich Stundenstatus.

##### Für wen ist die Wildcard ideal?

Die Wildcard eignet sich für Unternehmen, die projektbezogene oder fortlaufende Unterstützung in Design, Redaktion und Prompt Engineering benötigen, ohne sich langfristig binden zu wollen. Perfekt für alle, die flexibel und schnell auf wechselnde Anforderungen reagieren möchten.

##### KR BLACK WEEKS


## Jetzt buchen!

