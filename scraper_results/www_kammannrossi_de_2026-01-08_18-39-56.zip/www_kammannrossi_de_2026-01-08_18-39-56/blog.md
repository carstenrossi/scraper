---
url: https://www.kammannrossi.de/blog
scraped_at: 2026-01-08 18:39
title: Kammann Rossi - Content Action Blog
---

# Kammann Rossi - Content Action Blog


## Black Weeks bei KR – echt jetzt?


##### vonCarsten Rossi| 06.11.2025 10:04:37 | 1 Minute Lesezeit


## Magazin: Vom Lagerhaus zum Lesestoff


##### vonDr. Christian Fill| 14.05.2025 10:58:33 | 3 Minuten Lesezeit


## CRSD: Mehr Chance als Nachteil!


##### vonDr. Nicolas Oxen| 13.03.2025 15:09:24 | 5 Minuten Lesezeit


## Praktikum mit Goldrand: Wie eine Herausforderung zum Erfolg wurde


##### vonJürgen Jehle| 17.02.2025 09:23:40 | 6 Minuten Lesezeit


## Schülerpraktikantinnen als Magazinmacherinnen bei Kammann Rossi


##### vonJürgen Jehle| 17.02.2025 09:22:35 | 2 Minuten Lesezeit


# „Die Zukunft des Mitarbeitermagazins 2022“


### Ausführliche Ergebnisse


## #keineagentur: Die KI-Roadshow für Kommunikationsteams startet in Köln


##### vonCarsten Rossi| 08.01.2025 13:04:24 | 2 Minuten Lesezeit


## Warum Magazine in jede Content-Strategie gehören.


##### vonDr. Christian Fill| 12.12.2024 09:00:00 | 3 Minuten Lesezeit


## Beispiele für die besten Mitarbeiterzeitungen 2024


##### vonArne Büdts| 14.11.2024 10:11:12 | 3 Minuten Lesezeit


## „AI Fusion“ für Magazine: Smarter arbeiten für bessere Publikationen


##### vonCarsten Rossi| 13.11.2024 17:13:04 | 5 Minuten Lesezeit


### Erfahren Sie mehr!


### Aktuellste Beiträge


### Beliebteste Beiträge


### Newsletter-Anmeldung

