---
url: https://www.kammannrossi.de/blog/12-kreative-formate-für-die-digitale-interne-kommunikation-0
scraped_at: 2026-01-08 18:39
title: 5 Storytelling-Formate für die digitale Interne Kommunikation
---

# 5 Storytelling-Formate für die digitale Interne Kommunikation


# 5 Storytelling-Formate für die digitale Interne Kommunikation

vonCarsten Rossi| 02.11.2022 07:30:00 | 3 Minuten Lesezeit
Es begann mit dem Virus, aber es hat auch mit der (relativen) Entspannung nicht mehr aufgehört: Unternehmen kommunizieren mit denMitarbeiter*innen mehr und mehr digital, auf immer mehr Kanälen. Falls Sie deshalb nach Contentideen suchen, haben wir schon letztes Jahr12 Formateveröffentlicht und haben hierfünf neuefür Sie, dieses Mal mit dem FokusStorytelling.
Diedigitale Kanalarchitekturvieler Unternehmen kann einen schwindlig machen: Social Intranets, Microsoft Teams, Mitarbeiterapps, digitale Mitarbeitermagazine, etliche Newsletter etc. Und all das wird aktuell auch noch in höherer Frequenz als früher genutzt – New Work und Gen Y sei Dank. Wer da mithalten will, stößt mitStandardformatenbald an seine Grenzen. Wer auffallen will, Engagement sucht und Dialog fördern will, muss wenigstens hin und wieder zu neuen Mitteln greifen. Wir glauben, dass besondersStorytellingdafür das Mittel der Wahl ist. Menschen reagieren am intensivsten auf Menschen - dafür sorgen unser Gehirn, unser Nervensystem und unsere Hormone.

#### Storytelling für Engagement, Identität und Change

FürKunden und Kundinnensowie auf Veranstaltungen unseres Event-Partners scm  erarbeiten wir in vielen digitalen Workshops zahlreiche redaktionelle, kreative und interaktive Formate, die auf etlichen Plattformen funktionieren müssen. Im Fokus stehen dabei zumeist drei Ziele, die an uns herangetragen werden.
- Engagement steigern: Viele digitale Kanäle gleichen einer Geisterbahn. Sie sind erschreckend leer und außer vereinzelten Aufschreien ist nichts zu hören. Es braucht Formate, die die Kanäle in einen lebendigen Ort verwandeln. Storys machen aus unbelebten Orten Treffpunkte.
Engagement steigern: Viele digitale Kanäle gleichen einer Geisterbahn. Sie sind erschreckend leer und außer vereinzelten Aufschreien ist nichts zu hören. Es braucht Formate, die die Kanäle in einen lebendigen Ort verwandeln. Storys machen aus unbelebten Orten Treffpunkte.
- Identität steigern: Home Office und New Work sind hilfreich, sie nagen aber an der Identität. Gerade neue Mitarbeiter*innen haben es schwer, sich in die Organisation einzufinden. Digitale Formate müssen da Ersatz schaffen - und Geschichten sind gelebte Identität-
Identität steigern: Home Office und New Work sind hilfreich, sie nagen aber an der Identität. Gerade neue Mitarbeiter*innen haben es schwer, sich in die Organisation einzufinden. Digitale Formate müssen da Ersatz schaffen - und Geschichten sind gelebte Identität-
- Change ermöglichen: Unternehmen verändern sich weiterhin und manchmal noch schneller. Die digitale Interne Kommunikation muss diesen Wandel unterstützen - durch Geschichten von Vorbildern und guten Projekten.
Change ermöglichen: Unternehmen verändern sich weiterhin und manchmal noch schneller. Die digitale Interne Kommunikation muss diesen Wandel unterstützen - durch Geschichten von Vorbildern und guten Projekten.
Storytelling kann all diese Ziele unterstützen. Deshalb hier aus unserem großen Agentur-Katalog fünf Formate, mit denen sich gute Geschichten erzählen lassen.

#### #1 Praktikantin für einen Tag

Diese Rubrik stellt den Wechsel einer Kollegin/eines Kollegen für einen Tag in eine andere Abteilung vor. Die Kollegin/der Kollege macht Fotos/Videos von ihrem/seinem „Praktikum“ und stellt so ein kleines Foto-/Videotagebuch zusammen.
Beste Kanäle: Mitarbeiterzeitung, Mitarbeiterapp

#### #2 Was macht eigentlich ...?

Menschen sind die „Helden“ des Unternehmens. Sie leisten – inspiriert durch tolle Produkte und ein hilfreiches Management - Großartiges. Doch was machen sie eigentlich genau? Das Format „Was macht eigentlich...?“ stellt genau diese Frage und stellt Menschen und ihre Berufe vor. Z. B.: „Was macht eigentlich ein Cyber-Security-Engineer?“
Beste Kanäle: Intranet, Mitarbeiterzeitung, Mitarbeiterapp, Corporate Blog
So sehen die Formatkarten in unserem Agenturkatalog aus.

#### #3 Change Pioneers

Wem soll ich im Social Intranet zu diesem Change  folgen? Wer ist zu aktuellen Themen aktiv und hat erfolgreiche Use Cases? Was zeichnet sie/ihn aus und was ist zu erwarten, wenn man ihr/ihm folgt? Diese Personen regelmäßig vorstellen und mit anderen vernetzen.
Beste Kanäle: Social Intranet, Mitarbeiterapp

#### #4 Junges Wissen, Altes Wissen

In Ihrem Unternehmen arbeiten Menschen aller Altersbereiche. Junge Mitarbeiter bringen dabei ein anderes fachliches Wissen mit oder gehen anders an Dinge heran als Mitarbeiter, die über Jahre fachspezifisches Wissen angesammelt haben. In diesem Format werden beide Seiten aus Sicht der jeweiligen Altersgruppe gegenübergestellt und Vor- und Nachteile hervorgehoben. Funktioniert auch mit „Gewohnheiten“ (junge Gewohnheiten - alte Gewohnheiten). Themen könnten sein: Entwicklung, Innovationen, Messen, Dienstreisen, Arbeitsgewohnheiten, u.v.m.
Beste Kanäle: Intranet, Corporate Blog

#### #4 Das rote Band

Ein Mitarbeiter stellt sich vor, seine Aufgaben,Besonderheitenan seinem Standort etc. Und wird dabei mit einem roten (oder andersfarbigen, je nach CI des Unternehmens) Band abgelichtet. Dann nominiert er einen Mitarbeiter/eine Mitarbeiterin aus einem anderen Land, mit dem/der er oft zu tun hat und nominiert ihn/sie für das nächste Porträt (er/sie übergibt praktisch das Band).
Beste Kanäle: Social Intranet, Mitarbeiterapp
Wir hoffen, dass die eine oder andere Anregung für Sie dabei ist, wenn auch vielleicht nur als Impuls für weitere kreative Ideen. Falls Sie Lust auf mehr haben, einfach melden, hier im Kontakt oder per Mail anc.rossi@kammannrossi.de.
