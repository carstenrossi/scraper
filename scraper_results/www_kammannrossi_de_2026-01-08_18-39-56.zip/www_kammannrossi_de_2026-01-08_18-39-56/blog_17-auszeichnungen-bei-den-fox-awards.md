---
url: https://www.kammannrossi.de/blog/17-auszeichnungen-bei-den-fox-awards
scraped_at: 2026-01-08 18:39
title: 17 Auszeichnungen bei den Fox Awards
---

# 17 Auszeichnungen bei den Fox Awards


# 17 Auszeichnungen bei den Fox Awards

vonJürgen Jehle| 05.10.2020 10:00:00 | 2 Minuten Lesezeit
Screenshot foxawards.de
Im Jahr zehn des Effizienz-Wettbewerbs für Content-geprägte Kommunikationslösungen freuen wir uns zusammen mit unseren Kunden über einen wahren Preisregen bei den FOX AWARDS, FOX VISUALS und FOX FINANCE AWARDS. Insgesamt wurden an Kammann Rossi Projekte 17 Auszeichnungen für „effiziente Lösungen aus Marketing und Kommunikation in Print und Digital“ verliehen.
Das„ARAG Spezial“-Magazin zum Nachhaltigkeitsbericht2019 wurde mit einem FOX AWARD in Silber und Gold bei den VISUALS gekürt. Der dazugehörigeARAG Nachhaltigkeitsberichträumte bei den FOX FINANCE AWARDS gleich zweimal Gold in beiden Kategorien (Konzept und kreative Umsetzung) ab.
„moizeit! Das Mitarbeitermagazin von Frauscher“, wurde mit einem FOX AWARD in Silber und Gold bei den VISUALS ausgezeichnet.
„WASSER BESSER MACHER“, das Mitarbeitermagazin der Stadtentwässerungsbetriebe Köln (StEB), erhielt ebenfalls Gold bei den VISUALS.
Die Kommunikationsmaßnahmen, Kampagnen, den Internetauftritt sowie die Social-Media-Aktivitäten für denFörderverein Kinderkrankenhaus Amsterdamer Straße Köln e.V.,den wir seit 2018 betreuen, zeichnete die Jury mit je einem Silber-FOX (Konzept und Umsetzung) aus.
Je ein Gold-FOX in der Kategorie Visuals ging an das Informationsportal„2025 AD – The Autonomous Driving Community“von Continentalund dieMitarbeiter-App der Deutschen Bahn Fernverkehr „echt:klar“, die bei den diesjährigenInkometa Awardsebenfalls mit Gold geglänzt hat.
Je einen silbernen FOX AWARD erhielten„Canada Life – Themenportal: Meine Zukunft und ich“von Canada Life, das auch bei denBCM Awards2020 auf der Shortlist stand, sowie„move – the  technology hub“, der Mitarbeiterkanal mit Fachthemen für Ingenieure von Continental.
DerFinanzbericht der Oldenburgischen Landesbankwurde bei den FOX FINANCE AWARDS zwei Mal mit Silber ausgezeichnet.
Last but not least wurde derIntegrierte Bericht 2019 von Clariant, für den wir neben der grafischen Umsetzung den Storytellingteil realisieren, mit zwei Gold-FOX (Konzept und Umsetzung) ausgezeichnet. Der Bericht stand bereits beim BCM Award 2020 auf der Shortlist und hat Platz 2 belegt beim diesjährigenRanking der besten Schweizer Geschäftsberichte.
Maßgeblich für Gold oder Silber bei den FOX AWARDS war – wie immer – ausschließlich die erreichte Punktzahl. Im Unterschied zu einem Knock-out-System konnten so innerhalb einer Branche auch wieder mehrere Einreichungen mit Gold oder Silber geehrt werden. Mit neuer Gewichtung hielten 2020 Social Media Einzug in die Bewertungsmatrix. Und mit der Ausweitung der Channel-Bewertungen wuchs in diesem Jahr erneut die Komplexität der Auswertung. Zugleich wurden die FOX AWARDS so erneut ihrem Anspruch gerecht, Spiegel der immer anspruchsvolleren Zielgruppen-Kommunikation zu sein.
Die Gesamtauswertung alles FOX AWARDS, FOX VISUALS und FOX FINANCE AWARDS finden Sie unterwww.foxawards.de.
