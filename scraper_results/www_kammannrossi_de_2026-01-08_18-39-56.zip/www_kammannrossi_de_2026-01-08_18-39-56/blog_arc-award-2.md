---
url: https://www.kammannrossi.de/blog/arc-award-2
scraped_at: 2026-01-08 18:39
title: Jurierung von GB und CSR für den ARC Award 1
---

# Jurierung von GB und CSR für den ARC Award 1


# Jurierung von GB und CSR für den ARC Award 1

vonBrigitte Läpper Röhricht| 15.12.2020 10:49:37 | 2 Minuten Lesezeit
DerARC Awardin New York ist einer der größten Wettbewerbe für Geschäftsberichte und CSR-Berichte weltweit, mit jährlich über 2.000 Einsendungen. Der Oscar der Geschäfts-und CSR-Berichte.
Im zweiten Teil unserer Blogreihe zu den ARC Awards möchte ich über die allgemeinen Tendenzen der eingesandten Geschäfts- und CSR-Reports berichten.Bemerkenswert in diesem Jahr ist, dass der proportionale Anteil an deutschen Berichten immer weiter abgenommen hat. Wie schade.
Immer noch sind diese Berichte von gestalterisch meisthoher Qualität.Es fehlt wie so oft an den Etats, um hier spannende Geschichten zu erzählen und zu visualisieren.Vielleicht ist nach dem Boom der GBs in den 2010er Jahren, in dem jeder Bericht immer größer, aufmerksamkeitsstärker und aufwändiger wurde und wir eine Hochkultur entwickelten, eine Verschiebung der Berichte in Richtungdigitaler Kommunikationentstanden?Schön wär's.
Wie so oft, wurden eher die Etats gekürzt, da der Wert dieser testierten und authentischen Kommunikation völlig unterschätzt wurde und wird.Reduce to the Max.
Die CSR-Berichte, die heute ein notwendiger Kommunikationsbestandteil nicht nur bei den börsennotierten Aktiengesellschaften sind, und ohne die keine Investmententscheidungen und keine Sustainable Finance mehr gewährt wird, haben einen neuen Platz eingenommen.In den meisten Fällen allerdings, nur noch nicht mit dem notwendigen Aufwand an Gestaltung und Inhalt. Auch hier versucht man mal wieder mit geringem Aufwand eine Pflichtlektüre zu erstellen.
Der CSR-Report der China Southern Airline ist Grand Winner der Kategorie „Best Infographics“.
Hier wäre eine Zielgruppenerweiterung mit einzubeziehen, die mit einer großartigen Gestaltung, mit interessanten Unternehmensgeschichten und zielgerichteten Informationen möglich wäre, die bessere Wahl.Neue, gut ausgebildete Mitarbeitende entscheiden sich auch über Nachhaltigkeitskriterien zu welchem Unternehmen sie wechseln.
Interne Informationen können durch gute und gezielt formulierte Kommunikation für alle Stakeholder aufbereitet werden – auch für den Finanzmarkt.Zurzeit sehen wir leider auch hier eher Schmalspurberichte.Aber vielleicht kommt das ja noch.
Der GB der Nissin Foods Holding ist Grand Winner in den Kategorien „Non-Traditional Annual Reports“, „Cover Design“, „Illustrations“ und „Best of Japan“.
Nun haben die Asiaten den Spielball aufgenommen. Ihrer Kultur entsprechend mit ganz anderenästhetischen, aber auch inhaltlichen Konzepten.Oberste Priorität sind zunächst hierarchisch geprägte Aufbauten und Strukturen.Fotos von Vorständen, Aufsichtsräten und Regierungsmitgliedern oder Präsidenten stehen an erster Stelle, danach folgen Luftaufnahmen, Gebäudefotos und Produkte.Eine gute grafische Aufbereitung von Diagrammen oder typografische Highlights sind leider selten.Die Bemühungen sich an europäischen oder internationalen tätigen Unternehmen zu orientieren, schlagen meist fehl.
Bemerkenswert, dass bei aller gewöhnungsbedürftigen Gestaltung, das Wording inzwischen komplett auf Nachhaltigkeit umgeschwenkt hat.Es gibt kaum einen Bericht, auch Geschäftsbericht, der nicht schon auf dem Titel Sustainability propagiert.
Im nächsten Teil der Blog-Serie werde ich konkreter zu einzelnen Berichten Stellung nehmen. Teil 1 zum ARC Award finden Siehier.
