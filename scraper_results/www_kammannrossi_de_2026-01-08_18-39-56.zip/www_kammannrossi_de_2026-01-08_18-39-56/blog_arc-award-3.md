---
url: https://www.kammannrossi.de/blog/arc-award-3
scraped_at: 2026-01-08 18:39
title: Jurierung von GB und CSR für den ARC Award 2
---

# Jurierung von GB und CSR für den ARC Award 2


# Jurierung von GB und CSR für den ARC Award 2

vonBrigitte Läpper Röhricht| 16.12.2020 09:04:27 | 3 Minuten Lesezeit
DerARC Awardin New York ist einer der größten Wettbewerbe, für Geschäftsberichte und CSR-Berichte weltweit, mit jährlich über 2000 Einsendungen. Der Oscar der Geschäfts- und CSR-Berichte.
Im dritten Teil unserer Blogreihe zu den ARC Awardsmöchte ich über die von mir jurierten Berichte ein Resümee ziehen.
Der Sino Media Geschäftsbericht 2019
Besonders aufgefallen ist mir in diesem Jahr der Bericht derSino Media, einem chinesischen Kommunikationsunternehmen.Hier sollte sicherlich Nähe und Dynamik ins Bild kommen. Der CEO reicht dem Betrachter imaginär die Hand – und das in Corona-Zeiten.Weitere Vorstände folgen dem Konzept der Aktion und machten völlig irritierende Hand- und Armbewegungen, überhaupt nicht zu ihrer Position und ich finde, auch nicht zur Kultur passend.Zumindest sehen die Vorstände mit dieserFoto-Auffassungnicht sehr glücklich aus.
Einige der eingereichten, digitalen Berichte verwundern mich ebenfalls.Es könnte der Neuanfang der Unternehmenskommunikation geschaffen werden.Gute Stories, Grafiken, Fotos oder Videos, deren Inhalte vielfältig genutzt werden könnten.Interaktivität, kleine Videos, neue gelernte Kommunikationsmittel und neue digitale Umgangsformen wären hier nutzbar.Ein Vorstand, dessen Vorwort als Video gezeigt würde und wenn schon Produkte, dann interaktiv präsentiert.Hier böte sich die ganze Spielwiese der animierten und digitalen Möglichkeiten – genutzt wird sie in den seltensten Fällen.
Der Evonik-CSR-Report 2019
Selbst derdigitale Geschäftsbericht der Evoniknutzt diese Möglichkeiten nicht. Bei dem eingesandten Bericht handelt sich um ein PDF, das in keiner Weise interaktiv nutzbar ist.Der Bericht selbst ist sehr bunt, massiv und zeigt die klassischen Luftaufnahmen und Industrieanlagen ohne sichtbares fotografisches oder grafisches Gesamt-Konzept. Ein langweiliger, wie vor 20 Jahren gestalteten Geschäftsbericht ohne interessante Geschichte oder unterhaltsame Grafiken. Sicherlich dem Sparkonzept zum Opfer gefallen.
Der Geschäftsbericht 2019 der Triglav Group
Ich komme jetzt zu meinem Lieblingsbericht: Dem digitalen Geschäftsbericht derTriglav Groupaus Slowenien.Es ist meiner Meinung nach der beste digitale Geschäftsbericht, der alle Möglichkeiten, die ein digitales Medium bietet, hier beispielhaft nutzt:Filme, die eingebunden werden, Interviews, in denen der Vorstand mit verschiedenen Mitarbeitenden diskutiert, die wichtigen Themen werden grafisch dargestellt und es gibt immer die Möglichkeit einen Button zu benutzen, um ein kleines Video oder eine einlaufende Animation einer Grafik anzusehen.Darüber hinaus ist er hervorragend gestaltet, authentisch, erzählerisch und macht neugierig auf ein solches Unternehmen.Er bewegt sich wirklich außerhalb der bisher gesehenen digitalen Geschäftsberichte und sollte als Vorbild für Viele dienen.
Abschließend möchte ich den Geschäftsberichts-Titel derSumitomo Chem QJP, einem japanischen Chemieunternehmen, vorstellen. Dieser Titel ist so unfassbar.Hier fliegt ein altes Holzschiff mit dem Namen Sumitomo, so wie das Unternehmen Sumitomo, durch die Wolken, wie in einem Märchen der Wolkenvölker angetrieben von vier alten Propellern. Es erinnert an ein altes Kriegsschiff oder an eine Arche Noah, die alle Bäume, Blumen und Tiere transportiert. Selbst ein riesiges Aquarium im Mitteltrakt zeigt für mich eher ein Haifischbecken.Es gibt mir das Gefühl, dass diese Arche, nachdem Sumitomo Chem die Erde verwüstet hat, nun in den Himmel flüchten muss und die letzten Völker, selbstverständlich auch die beiden Headquarter von Sumitomo Chem samt dazugehöriger Kupferminen rettet.Diese Illustration segelt unter dem Thema Change und Innovation 3.0 in den blauen Himmel, ganz ohne Smog.
Sicherlich gäbe es hier noch einige Annual- und CSR-Reports zu erwähnen.Ich habe die für mich signifikanten herausgesucht, um einen kleinen Überblick über die Berichtswelt zu geben.
Hier geht es zu Teil 1 und Teil 2 des ARC Award.
