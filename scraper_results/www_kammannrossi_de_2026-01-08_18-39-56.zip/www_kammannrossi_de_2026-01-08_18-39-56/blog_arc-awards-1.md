---
url: https://www.kammannrossi.de/blog/arc-awards-1
scraped_at: 2026-01-08 18:39
title: ARC Award
---

# ARC Award


# ARC Award

vonBrigitte Läpper Röhricht| 11.12.2020 16:34:30 | 3 Minuten Lesezeit
DerARC Award, die MerComm Annual Report Competition in New York, ist einer der größten Geschäftsberichts- und Nachhaltigkeits-Wettbewerbe weltweit.Mit 2.100 Einreichungen aus 34 Ländern ist er auch ein internationales Schwergewicht und wird als Oscar derGeschäftsberichtebezeichnet.
Er zeigt anschaulich globale Trends und Entwicklungen in der Finanz-, Nachhaltigkeits- und Unternehmens-Kommunikation auf.Die Aussagekraft und Kreativität der Berichte zeigen die genialen Möglichkeiten auf, die sie als Kommunikationsinstrument bieten.Die Kraft einer gut gestalteten und gezielt eingesetzten Finanzkommunikation wird gerade in der letzten Zeit oft verkannt.Sie mutiert zur lästigen und zu aufwändigen Pflicht. Dabei ist heute, mehr denn je, das Hintergrundwissen über Unternehmen gefragt.The Story is the hero.

##### Der Clariant Integrated Report 2019

Der Integrated Report unseres Kunden Clariant International AG ist Grand Winner in der Kategorie „Specialized Annual Reports“.
Wer sich die Einreichungen dieses Wettbewerbs und die Variabilität ihrer Gestaltungsmöglichkeiten anschaut – sei es in Form vonFotografie, Illustrationen oder der grafischen Umsetzung von Diagrammen in ihren unterschiedlichen nationalen und kulturellen Ausprägungen – wird diese abwertende Sichtweise auf Geschäftsbericht sicher überdenken.
Seit fast 40 Jahren zählt der ARC Award zu den weltweit größten Wettbewerben dieser Art und ist durch seine Internationalität herausragend.*Nirgendwo wird es so deutlich, welche kulturellen Ansprüche und Ausgestaltungen zu ein- und demselben Thema visualisiert werden können.Die Unternehmen, die sich um diese Auszeichnung bewerben, sind aus der ganzen Welt – Europa, Asien und Amerika.Auch dieJurorensind Fachleute, die Tag für Tag mit der Erstellung von Geschäftsberichten beauftragt sind. Darüber hinaus aber auch Professoren und IR-Spezialisten, die sich aus der ganzen Welt rekrutieren.
Gerade in den letzten Jahren haben diedigitalen Berichteenorm zugenommen. Schön zu sehen, dass gerade Unternehmen aus kleinen Ländern einen großen Aufwand betreiben, um ihre Company, ihre Dienstleistungen und Produkte aber auch ihre Besonderheiten im besten Licht darzustellen.
Die Awards werden in Gold, Silber, Bronze und Honors vergeben.Der beste Bericht einer Kategorie erhält den Gold Award, deren Preisträger sind automatisch für dieGrand Awardsnominiert.
Im letzten Jahr fand die Preisverleihung im Oktober inSeoulstatt.Wie bei den Oscars, ist an diesem Abend das „Who is Who“ der Szene vertreten.Die Gewinner, Juroren und Agenturen feiern sich in einer großen Gala, die in diesem Jahr in Barcelona hätte stattfinden sollen.
Seit vielen Jahren bin ich,Brigitte Läpper Röhricht, Mitglied dieser Jury und es ist mir immer wieder eine Freude, Jahr für Jahr die unterschiedlichsten Berichte zu Gesicht zu bekommen. Imkommenden Teil dieser Blogpost-Reihe werde ich die Berichte vorstellen, die mir in diesem Jahr besonders aufgefallen sind und ein Resümee ziehen, aus dem was sich hier an Interessantem, Besonderem aber auch für mich Merkwürdigem gezeigt hat.
*Aktuell ist Kammann Rossi auf Platz 4 desLOUT Chartbreaker Reporting, einem Ranking, in dem Ergebnisse nationaler und internationaler Wettbewerbe noch einmal mit dem Fokus auf Reports ausgewertet werden. Für Geschäfts-, CSR/Nachhaltigkeits-, Integrierte und Tätigkeitsberichte in Print und Online vergebene Punkte führen dann zu diesem Ranking. Der ARC Award ist einer dieser internationalen Wettbewerbe.
