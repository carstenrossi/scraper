---
url: https://www.kammannrossi.de/blog/award-für-interne-kommunikation-die-beste-mitarbeiterzeitung-und-viel-mehr
scraped_at: 2026-01-08 18:39
title: Inkometa Award für Interne Kommunikation:  Mitarbeiterzeitungen & mehr
---

# Inkometa Award für Interne Kommunikation:  Mitarbeiterzeitungen & mehr


# Inkometa Award für Interne Kommunikation:  Mitarbeiterzeitungen & mehr

vonCarsten Rossi| 09.01.2018 14:59:49 | 4 Minuten Lesezeit
Endlich ist es soweit: Die Interne Kommunikation in Deutschland bekommt einen eigenen Preis. Seit diesem Jahr lobt dieSCM - School for Communication and Management den INKOMETA Award aus. Alle Unternehmen, die eine regelmäßige interne Unternehmenskommunikation betreiben, sind aufgerufen, ihre Instrumente und Maßnahmen in den KategorienMedien, Strategie, Digital Workplace und Kampagneneinzureichen.Carsten Rossi,Geschäftsführer der Kammann Rossi GmbH, wirdModerator der Fachjury "Medien". Er ist unter anderem Herausgeber der regelmäßigen Studie "Zukunft der Mitarbeiterzeitung".
DerInkometa-Awardbewertet das operative und strategische Handeln in der Mitarbeiterkommunikation. In einemzweistufigen Auswahlverfahrenmüssen sich die Einreichungen nicht nur in der fachlichen Qualität, sondern auch in ihrer Wirkung beweisen. Neben den genannten Kategorien vergibt die Jury auch diverse Sonderpreise. Die Finaljury besteht aus Dr. Gerhard Vilsmeier (Vorsitzender), Steffen Henke (Vodafone Deutschland), Birgit Ziesche (Henkel), Ariana Fischer, Ulrike Führmann, Tobias Geiger (Deutsche Bahn), Prof. Dr. Ulrike Buchholz und Matthias Wesselmann.
Für jede Einreichung gibt es eine Kurzanalyse.Auf Wunsch und gegen einen Aufpreis ist auch eine qualifizierte Expertise möglich. Zusätzlich erhalten die Einreicher endlich das in Deutschland bisher fehlende exklusive "große Forum": Vom Networking auf der abendlichenAward-Party und der IK-Fachtagungam folgenden Tag, bis hin zur medialen Weiterverarbeitung der Einreichungen. Die Preisverleihung des Inkometa-Awards findet am 2. Mai 2018 in Düsseldorf statt.
Carsten Rossi wird mit Kollegen aus Agenturen und Unternehmen zusammen die besten Arbeiten in der Kategorie "Medien" ermitteln.Dabei können Maßnahmen in den folgenden Unterkategorien eingereicht werden:

### 1. Beste Mitarbeiterzeitungen/beste Mitarbeitermagazine (Print)

Die gedruckte Mitarbeiterzeitung bleibt in Zeiten der Digitalisierung ein unverzichtbares Kommunikationsinstrument. In der Kategorie "MAZ Print" küren wir die als Gesamtprodukt überzeugendste Publikation. Das müssen beileibe nicht immer die "üblichen Verdächtigen" von Siemens, Commerzbank oder Lufthansa sein - auch kleine Unternehmen haben hier bei gutem Einsatz eine echte Chance.

### 2. Mitarbeiterzeitung Digital

Erscheint Ihre MAZ auch in einer digitalen Variante? Reichern Sie die digitale Version gar noch um besondere Features an? Oder gibt es diese nur noch digital? - Dann hat Ihre MAZ gute Chancen, in der Kategorie MAZ Digital prämiert zu werden.

### 3. Bestes Cover einer Mitarbeiterzeitung

Ob provokant, witzig oder emotional – ein gutes Cover fesselt den Betrachter sofort und kann eine große Wirkung entfalten. Reichen Sie das Cover einer MAZ-Ausgabe ein, auf das Sie besonders stolz sind. Aufmerksamkeitsstärke ist hier Trumpf.

### 4. Apps für Mitarbeiter

Mitarbeiter-Apps erfüllen inzwischen ganz unterschiedliche Funktionen für die Belegschaft. Gesucht werden in dieser Kategorie die besten Verknüpfungen von Content und Funktionalität in einer Mitarbeiter-App. Interessant ist hier vor allem was sie aus den Standard Apps der Anbieter, wie z.B. Staffbase Eigenes geschaffen haben.

### 5. Blog für die Interne Kommuniation

Ein Blog bietet viele Kommunikationsansätze um mit der Belegschaft in den Dialog zu treten. Wir suchen Blogs, die die Anforderungen der IK an dieses Medienformat vorbildlich erfüllen. Uns interessiert natürlich auch, ob ein Dialog überhaupt stattgefunden hat.

### 6. Mitarbeiter-Newsletter (Online/Print)

Wir prämieren in der Kategorie Newsletter das beste Format aus dieser Gattung. Eingereicht werden können nicht nur per Mail verschickte Newsletter, sondern auch Printvarianten dieser Gattung.

### 7. Microsite für die Mitarbeiterkommunikation

Ein Format, prädestiniert für spannende und innovative Projekte! Mit welcher Microsite haben Sie 2016 oder 2017 Ihre Belegschaft unterhalten und/oder informiert? Was war wichtig genug, um nicht im normalen Intranet oder ESN unterzugehen?

### 8. Infografik/Bild/Poster für Mitarbeiter

Visuelle Kommunikation ist ein effizientes Mittel der internen Kommunikation. Gesucht werden Infografiken, Bilder, Cartoons, Fotos und Poster, die zum Zweck der internen Kommunikation angefertigt wurden, der Belegschaft im Gedächtnis blieben und so einen nachhaltigen Effekt entfalten konnten.

### 9. Storytelling in der Internen Kommunikation

Gesucht wird ein Beitrag aus Ihren internen Medien, welcher beispielhaft das Storytelling des Unternehmens oder der Organisation unterstreicht. Wie erzählen Sie Geschichten? Wie fesselnd, informierend oder aufmerksamkeitsstark werden die Geschichten erzählt?

### 10. Bester journalistischer Beitrag (Text)

Aus den Medien der Internen Kommunikationsuchen wir den besten journalistischen Beitragaus der Kategorie „Text“ – beispielsweise Interviews, Kolumnen oder Reportagen. Wir suchen nach dem besten Handwerk, welches hilft die Interne Kommunikation zu verbessern.
> Ich finde, dass dieser Award vor allem ein Anlass zum Dialog über Best Practices Interner Kommunikation in Unternehmen sein sollte. Deshalb werde ich regelmäßig auf Twitter das Gespräch mit der Fachcommunity suchen. Einen Überblick über meine Tweets bekommen Siehinter diesem Link. Außerdem können Siehiermein Inkometa Tagebuch per Mail abonnieren. Und hier können Sieeinen Beispieleintrag lesen. (Carsten Rossi)
Ich finde, dass dieser Award vor allem ein Anlass zum Dialog über Best Practices Interner Kommunikation in Unternehmen sein sollte. Deshalb werde ich regelmäßig auf Twitter das Gespräch mit der Fachcommunity suchen. Einen Überblick über meine Tweets bekommen Siehinter diesem Link. Außerdem können Siehiermein Inkometa Tagebuch per Mail abonnieren. Und hier können Sieeinen Beispieleintrag lesen. (Carsten Rossi)

### 11. Bester journalistischer Beitrag (Audiovisuell)

Aus den Medien der Internen Kommunikationsuchen wir den besten journalistischen Beitrag aus der Kategorie „Audiovisuell “ – beispielsweise Filme oder Podcasts. Professionalität ist hier eine besondere Herausforderung für viele Unternehmen.

### 12. Mitarbeiter-Event

Welches Event, welche Veranstaltung im Jahr 2016 oder 2017 konnte das Ziel für die Unternehmenskultur, das interne Employer Branding und die Interne Kommunikation in beispielhafter Weise erreichen? Berichten Sie uns von prägenden Veranstaltungen, mit denen Sie Ihre Mitarbeiter angesprochen haben.

### 13. Design der Medien und Instrumente

Wir suchen die besten Designs von Websites, Zeitschriften und Apps, in denen die verschiedenen Medienformate am besten zur Geltung kommen.

### 14. Innovativer Medieneinsatz in der internen Kommunikation

Sie haben ein Medienformat etabliert, das nicht vollständig in den vorgeschlagenen Kategorien aufgeht? Wir sind gespannt auf Ihre Einreichungen in der Kategorie „innovativer Medieneinsatz“! Wir lassen uns gerne überraschen!
Alle weiteren Informationen zur Jury, zum Auswahlverfahren und zu den Einreichungsmodalitäten finden Sieauf dieser Website.
