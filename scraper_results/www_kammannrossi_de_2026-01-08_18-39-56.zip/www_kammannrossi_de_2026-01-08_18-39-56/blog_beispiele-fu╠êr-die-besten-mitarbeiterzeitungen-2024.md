---
url: https://www.kammannrossi.de/blog/beispiele-für-die-besten-mitarbeiterzeitungen-2024
scraped_at: 2026-01-08 18:39
title: Beispiele für die besten Mitarbeiterzeitungen 2024
---

# Beispiele für die besten Mitarbeiterzeitungen 2024


# Beispiele für die besten Mitarbeiterzeitungen 2024

vonArne Büdts| 14.11.2024 10:11:12 | 3 Minuten Lesezeit
Alle Jahre wieder ist es soweit: Der Inkometa bittet zur Jurysitzung. Ich freue mich immer auf dieses Event mit vielen netten Kollegen, an einem schönen Ort und mit den neusten Mitarbeitermagazinen und -zeitungen frisch aus der Druckerpresse (oder aus dem Grafikkartenprozessor). Ein Tag lang Diskussion, Moderation und vor allem Inspiration. MeineMagazin-Highlights aus dem letzten Jahr möchte ich euch nicht vorenthalten:

## „Plus“ der R+V Versicherungen – Corporate Media auf Kiosk Niveau

Bei diesem Magazin erwische ich mich dabei, dass ich selbst anfange zu lesen, obwohl ich mit der R+V Versicherung wirklich nichts am Hut habe. Vielleicht ist es die kurzweilige Inszenierung der Unternehmenswerte am Anfang, die mich ködert. Denn sind wir mal ehrlich, die Gleichung Vorstellung der Unternehmenswerte = Tolles Storytelling geht in den seltensten Fällen auf. Und da wir grade bei Gleichungen sind, wer hat schon den Mut, ein ganzes Heft über Mathematik zu machen? In der Ausgabe „Die Quadratur des Kreises“ geht man jedenfalls dieses Risiko ein. Und herausgekommen ist ein Magazin über Unternehmens-Mathe-Nerds für ein Publikum, das am Ende ahnt, dass es eben diese Nerds sind, die die Welt da draußen ein bisschen besser begreifen. Ich könnte jetzt noch viel schreiben, zum Beispiel über das Wimmelbild mit zu findenden Versicherungsfällen oder emotionalen Formaten wie „Papa, was machst du den ganzen Tag“ mach ich aber nicht, denn sonst sprengt der Blogpost die empfohlene Höchstmenge an Zeichen.

## „bereit*“ von UCB Pharma – das wirklich bunte Mitarbeitermagazin

Schon zum zweiten Mal dabei und schon wieder ganz oben. Was mich an diesem Magazin freut, ist der Mut zur Gestaltung. Der ist nämlich in den letzten Jahren selten geworden: Es gibt Corporate Designs, Magazin-Templates und Branding Verantwortliche, die auf jeden Entwurf ihren Stempel platzieren müssen. Hier pfeift man drauf. Jede Seite eine andere Inszenierung, die sicherlich nicht jedem gefallen wird. Muss Gestaltung aber auch nicht. Sonst wird sie zur gepflegten Langeweile. Und das kann man von diesem Heft wirklich nicht behaupten.

## „Globe“ von GF – Das Corporate Media Get-together

Hier wird ein Wandel (nämlich eine Unternehmensfusion) kommunikativ begleitet, was oftmals zu einer reinen Pflichtveranstaltung gerät. Aber nicht in diesem Magazin, denn man hat sich mal Gedanken gemacht, wie man den Mitarbeitern die Angst vor Veränderung nehmen kann. Durch emotionale, authentische Reportagen, Quizformate und Gamification-Elemente werden die Menschen in den verschiedenen Unternehmen einander näher gebracht und das ohne zu langweilen. Das zeigt sich auch in der Gestaltung, endlich wird ein Wendecover mal sinnvoll eingesetzt!

## TÜV SÜD IN – Storytelling Mix aus Nabelschau und Tellerrand

Der TÜV Süd leistet sich seit Jahren ein toll gemachtes Kundenmagazin. About Trust erzählt spannende Geschichten über die Arbeit des TÜV in einer hochwertigen Gestaltung. Auch ein Magazin bei dem ich mich in anderen Juryrunden (BCM) beim Schmöckern ertappt habe. In der internen Kommunikation scheint man ebenso Wert auf gute Publikationen zu legen: Kurzweilige Unterhaltung, die nicht nur Mitarbeiter in den Fokus nehmen, sondern auch Stücke, die über den Tellerand hinausgehen. Wie bei den meisten Mitarbeitermagazinen, gibt es auch hier textlastigere Meldungen mit weniger gutem Bildmaterial. Diese werden aber durch die gute Grundgestaltung und eine eindeutige Informationshierarchie (die Abgrenzung der Division Highlight) gut eingebunden.

## Wasserbessermacher der StEB – die Hidden Champions der Mitarbeitermagazine und -zeitungen

Und zum Schluss etwas von uns. Wer jetzt Eigenlob erwartet, wird enttäuscht, denn hierbei handelt es sich um die Arbeit eines Kollegen. Und was der mit dem Kunden zusammen auf die Beine stellt, verdient es in diese Liste mit aufgenommen zu werden. Und mit ihm alle Verantwortlichen auf Unternehmens- und Agenturseite, die mit kleinstem Budget trotzdem hochwertige Magazine produzieren. Denn eins wird Ihnen jedes Jurymitglied hinter vorgehaltener Hand bestimmt bestätigen: Juryarbeit ist per se unfair, weil man Äpfel mit Birnen vergleicht. Große Magazine, wie der Bosch Zünder oder Plus (R+V Versicherungen) verfügen über ein anderes Budget als die Stadtentwässerungsbetriebe Köln und haben dadurch bei Preisverleihungen immer die Nase vorn. Schade eigentlich!
Schauen Sie in den nächsten Wochen und Monaten auf unseren Kanälen vorbei und achten Sie auf #welovemags.
