---
url: https://www.kammannrossi.de/blog/black-weeks-bei-kr-echt-jetzt
scraped_at: 2026-01-08 18:39
title: Black Weeks bei KR – echt jetzt?
---

# Black Weeks bei KR – echt jetzt?


# Black Weeks bei KR – echt jetzt?

vonCarsten Rossi| 06.11.2025 10:04:37 | 1 Minute Lesezeit
Wir melden uns mal lieber proaktiv, weil der oder die eine oder andere Interessierte es wahrscheinlich schon mitbekommen hat: Wir haben "Black Weeks" bei KR.
Wir wissen, das klingt eher nach Elektromarkt als nach Agentur.  Aber machen wir uns nichts vor: Die Zeiten sind hart.
Der Markt für Kommunikations- undMarketing-Dienstleistungen steckt mitten in einerKrise. 60 Prozent der europäischen Marketingverantwortlichen planen laut eMarketer, ihre Werbe- und Marketingausgaben 2025 zu kürzen. Und Little Black Book zitiert den CEO von Team BBDO mit den Worten: „Germany is experiencing an unprecedented marketing crisis.“Das spüren alle, wir und unsere Kunden: Budgets werden enger, Projekte kleiner, Entscheidungen vorsichtiger. Und, ehrlich gesagt: Der Markt hat das Black-Friday-Prinzip längst zum Standard „engineered“:Jede Ausschreibung, jeder Pitch, jedes Projekt-Briefing verlangt nach mehr Leistung in weniger Zeit– zu besseren Konditionen.Also gehen wir aufAttackeund drehen den Spieß für ein paar Wochen einfach mal um: Wir bieten vier unserer beliebtesten Leistungen als kompakte, rabattierte Aktionspakete an – klar umrissen, sauber kalkuliert, sofort buchbar.Nicht, weil wir plötzlich auf Rabatte stehen.
Sondern weil wir es können.
Mehr ist möglich. Jetzt!
