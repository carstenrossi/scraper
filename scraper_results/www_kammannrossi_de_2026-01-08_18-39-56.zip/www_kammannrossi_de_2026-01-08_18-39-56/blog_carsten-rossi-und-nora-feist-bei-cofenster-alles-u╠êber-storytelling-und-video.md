---
url: https://www.kammannrossi.de/blog/carsten-rossi-und-nora-feist-bei-cofenster-alles-über-storytelling-und-video
scraped_at: 2026-01-08 18:39
title: Carsten Rossi und Nora Feist bei cofenster: Alles über Storytelling und Video
---

# Carsten Rossi und Nora Feist bei cofenster: Alles über Storytelling und Video


# Carsten Rossi und Nora Feist bei cofenster: Alles über Storytelling und Video

vonKR Redaktion| 12.09.2022 17:17:04 | 1 Minute Lesezeit
Am 26.9. von 11-12 Uhr sprechen Nora Feist und Carsten Rossi zum Thema"Storytelling in der Internen Kommunikation mit Hilfe vonemployee generated videos". Dieses Webinar ist interessant für Dich, wenn Du
- wissen willst, wie du im Business-Kontext fesselnde Geschichten erzählst;
- lernen willst, wie du deine interne Kommunikation modern gestaltest;
- wenig Zeit aber ganz viele kreative Ideen hast und wie du sie umsetzt;
- erfahren willst, welche Video Formate für deine Kommunikation passen;
- sehen möchtest, wie andere Unternehmen employee generated videos nutzen.
Du kannst Dich direkt hier anmelden oder übercofenster.
Wir freuen uns auf Euch.
