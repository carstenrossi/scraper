---
url: https://www.kammannrossi.de/blog/chemie-kann-so-spannend-sein
scraped_at: 2026-01-08 18:39
title: Der Blog „The Moleculist“ von Clariant: Chemie kann so spannend sein!
---

# Der Blog „The Moleculist“ von Clariant: Chemie kann so spannend sein!


# Der Blog „The Moleculist“ von Clariant: Chemie kann so spannend sein!

vonDr. Christian Fill| 25.08.2022 13:28:05 | 2 Minuten Lesezeit
Wussten Sie, dass Geckos wahre Superhelden sind? Sie können mit einem Meter pro Sekunde eine Wand hochlaufen, können sich mit einer Drehung des Schwanzes in der Luft aufrichten und mit einem Meter pro Sekunde über Wasser laufen können. Das kann kein anderes Lebewesen!
Der Chemiekonzern Clariant hat sich bei den kleinen Helden viel abgeschaut – und diese Erkenntnisse für die eigene Klebstoff-Superstars, die Licocene®-Klebstoffadditive, in Sachen Agilität, Ressourcenschonung und Regeneration genutzt. Solche spannenden Phänomene und Storys erfahren die Leser imBlog „The Moleculist“.

##### Clariant macht Wissenschaft und Chemie greifbar, menschlich

Mit dem Blog bietet Clariant im B2B-Bereich einen Deepdive in die Welt der „großen Moleküle“. Dabei sind Nachhaltigkeit und Innovation strategische Wachstumstreiber für Clariant. Die auf Nachhaltigkeit ausgerichtete Innovationen unterstützen das durchschnittliche jährliche Wachstum von Clariant immerhin um etwa ein Prozent, wobei der Schwerpunkt auf biobasierten basierten Produkten, Dekarbonisierung und der Kreislaufwirtschaft liegt und mit „The Moleculist“ bietet Clariant einen facettenreichen Einblick in die Welt der Clariant-Innovationen.
Durch interessante, aufschlussreiche, teilbare und inspirierende Inhalte erweckt der Blog die Innovationen von Clariant in der Chemie zum Leben und steigert das Bewusstsein für die Innovationen, Produkte, Dienstleistungen und Kooperationen von Clariant. Zudem zeigt das Unternehmen die leidenschaftlichen Menschen hinter den Produkten und Dienstleistungen. So kann Clariant auch das Bewusstsein für die Marke des Unternehmens und die Loyalität zu ihr stärken. Zu den Zielgruppen des Blogs zählen die breitere Öffentlichkeit, Clariant-Mitarbeitende und Kunden aber auch die Leserschaft des Integrierten Berichts, den Clariant jährlich veröffentlicht.

##### Ein Baustein der Content-Mehrkanalstrategie von Clariant

Die meisten Themen im Blog sind direkt oder indirekt mit dem Thema Nachhaltigkeit verbunden und mit den so genannten Sustainable Development Goals (SDGs) der Vereinten Nationen, nach denen Clariant unter anderem berichtet. Somit ist „The Moleculist“ über die Funktion des Corporate Blogs hinaus ein wichtiger Themenspeicher für den Integrierten Bericht von Clariant. Dieser greift Best-of-Content aus dem Blog auf. Im Integrated Report verteilt, fungieren Blogposts als Storytelling-Elemente und ermöglichen eine vertiefte Auseinandersetzung mit Themen, die gesellschaftlich, wirtschaftlich und für das Unternehmen von Relevanz sind. „The Moleculist“ ist ein wichtiger Baustein in der Content-Mehrkanalstrategie von Clariant.

##### Launch des Blogs im Jahr 2020 mit historischem Bezug

Dass „The Moleculist“ 2020 gelaucht wurde, ist kein Zufall. Zum einen feierte der weltweite Chemiekonzern mit Hauptsitz in der Schweiz zu diesem Zeitpunkt seinen 25. Geburtstag. Zum anderen fiel der Start von „The Moleculist“ mit dem 100. Jahrestag eines Schlüsseldatums der Chemiegeschichte zusammen: Im Jahr 1920 begann der deutsche Chemiker Hermann Staudinger (1881-1965) mit der Veröffentlichung seiner bahnbrechenden Arbeiten über Polymere und makromolekulare Chemie, für die er später den Nobelpreis erhielt. Staudingers Arbeit der „großen Moleküle“ beeinflusste die Welt der Chemie nachhaltig und bildete das Geschäftsmodell für viele Unternehmen, darunter auch das von Clariant.

##### Blog-Beiträge sind tiefgründig und unterhaltsam

Die redaktionelle Themenherrschaft von „The Moleculist“ obliegt der Unternehmenskommunikation von Clariant. Die Aufgaben von Kammann Rossi bestehen in der redaktionellen Beratung des „The Moleculist“-Teams sowie der redaktionellen Umsetzung von Beiträgen in Teil- und Vollreaktion sowie der Zulieferung von Visuals und Fotos. Die redaktionellen Formate (Interviews, Features, Kurzreportagen, Portraits etc.) wechseln sich bewusst ab. Der Blog schafft es, auf tiefgründige, aber auch unterhaltsame Art und Weise über die verschiedenen Themen zu berichten. Eine Strategie, die aufgeht, denn die Performance des Blogs kann sich sehen lassen: 2021 verzeichnete „The Moleculist“ 24.000 Unique Pageviews, und die durchschnittliche Verweildauer pro Seite lag bei rund 2,5 Minuten.
> „Die Beiträge von „The Moleculist“ erzeugen einen neuen Blick auf unsere Produkte, Innovationen und unser Bemühen um Nachhaltigkeit. Und wir nutzen diesen tollen Content auch als Themenspeicher für unseren jährlichen Integrated Report."Luca LavinaManager Corporate Publishing bei Clariant
„Die Beiträge von „The Moleculist“ erzeugen einen neuen Blick auf unsere Produkte, Innovationen und unser Bemühen um Nachhaltigkeit. Und wir nutzen diesen tollen Content auch als Themenspeicher für unseren jährlichen Integrated Report."

# Projektablauf, Learnings und Checkliste


### Alls zum Mitnehmen fürs Team in einem PDF!

