---
url: https://www.kammannrossi.de/blog/content-engagement
scraped_at: 2026-01-08 18:39
title: Warum Content Engagement ein Kampf ist, den man gewinnen kann
---

# Warum Content Engagement ein Kampf ist, den man gewinnen kann


# Warum Content Engagement ein Kampf ist, den man gewinnen kann

vonCarsten Rossi| 09.07.2024 11:00:00 | 5 Minuten Lesezeit
Content Engagement ist kein Selbstläufer. Das wisst ihr selbst. Es ist ein Kampf, den ihr in der Internen Kommunikation jeden Morgen aufs Neue führen müsst. Und zwar gegen eine Vielzahl von Konkurrent:innen um die Aufmerksamkeit der Mitarbeiter:innen. Warum das so ist und wie man diesen Kampf gewinnen kann, darum geht es in diesem Blogpost.

#### Die Informationsflut macht es schwer

Der wichtigste Grund, warum es so schwierig ist, die Aufmerksamkeit der Mitarbeiter:innen zu gewinnen, ist die schiereMenge an Inhalten, mit denen wir alle tagtäglich konfrontiert werden. Morgens beim Frühstück, auf dem Weg zur Arbeit, im Büro, zu Hause – überall werden wir mit Informationen bombardiert. Waren es 1970 angeblich noch rund 1.000 Botschaften pro Tag, die verarbeitet werden mussten, sind es heute bereits 10.000.
DieseInformationsflutführt dazu, dass es uns immer schwerer fällt, uns auf einzelne Inhalte zu konzentrieren oder die wichtigen auszuwählen. Wir sind ständig abgelenkt und nehmen uns kaum noch Zeit, uns mit einem Thema ausführlich zu beschäftigen. Am Ende ist es in Unternehmen nicht anders als (leider) in vielen Familien: Egal ob beim Teammeeting in der Firma oder beim Familienfernsehabend zu Hause, jeder starrt nebenher auf seinen Bildschirm, sein Smartphone oder Tablet und scrollt durch irgendwelche Timelines. Echte Gespräche über das, was läuft, finden kaum noch statt, gemeinsame Erlebnisse sind selten, verbindende Botschaften bleiben aus. Stattdessen lebt jeder in seiner Blase. Die Folgen dieser Entwicklung sind fatal: Beziehungen kühlen ab, Empathie und Verständnis füreinander und für das „große Ganze“ gehen verloren.

#### Content-Schock: Zu viel Inhalt, zu wenig Zeit

Das Problem in unserem Leben ist aber nicht nur, dass wir mit einer Flut von Informationen konfrontiert sind, sondern auch, dass wirimmer weniger Zeithaben, uns mit diesen Informationen auseinanderzusetzen. Das führt zum berühmten „Content-Schock“. Wir haben einfach zu viel Content und zu wenig Zeit, ihn zu konsumieren.Das gilt selbstverständlich auch für die interne Kommunikation. Wir haben den Content in unserem Intranet, in unserer Mitarbeiterzeitung, von unseren Kolleg:innen und dann noch all die Informationen von außen. Das ist einfach viel mehr, als eine Person verarbeiten kann.

#### Relevanz ist nicht einfach Bauchgefühl

Was können wir also tun, um diesenKampf um die Aufmerksamkeitder Mitarbeiter:innenzu gewinnen? Die Antwort ist einfach: Wir müssen relevanten Content produzieren. Nur wenn der Content für die Mitarbeiter:innen relevant ist, werden sie sich damit auseinandersetzen.Doch woher weiß man, was relevant ist? Viele verlassen sich hier auf ihr Bauchgefühl – und manchmal mag das sogar funktionieren. Schließlich kennen wir „unsere Pappenheimer“. Und dieseKenntnis der Unternehmenskulturund auch derBedürfnisseist durchaus wichtig, wenn es darum geht, Botschaften auszuwählen und richtig zu formulieren.Aber strategische Kommunikation braucht mehr. Wir dürfen nicht raten, wir müssen wissen, was unsere Kolleg:innen wirklich interessiert, was sie wirklich brauchen. Und das nicht erst, wenn das Kind in den Brunnen gefallen ist, sondern im Idealfall kontinuierlich und jederzeit. Kurz: Wir brauchen Employee Listening. 👂

#### Datenbasiertes Employee Listening als Basis für relevanten Content

Employee Listening ist der Schlüssel zur Relevanz unserer Inhalte. Indem wir lernen, unseren Mitarbeiter:innen zuzuhören, können wir herausfinden, was sie wirklich interessiert und welche Inhalte sie sich wünschen, welche sie benötigen.Dabei kann es durchaus hilfreich sein, hin und wieder mit Kolleg:innen aus anderen Abteilungen zu sprechen, um ein Gefühl dafür zu bekommen, was sie bewegt und interessiert. Ein kurzer Plausch am Kaffeeautomaten, ein gemeinsames Mittagessen in der Kantine oder auch mal ein Schwätzchen zwischen Tür und Angel – all das kann wertvolle Einblicke liefern. Für die interne Kommunikation in großen Unternehmen reicht das aber definitiv nicht aus.Vielmehr braucht es einenstrategischen, datenbasierten Ansatz, um die Mitarbeiter wirklich zu verstehen.Echte Messungen und Analysen, um herauszufinden, was die Mitarbeiter wirklich bewegt. Nur so könnenrelevante Inhalte langfristig und zielgerichtet erstellt werden.

#### Immer zuhören, nicht nur gelegentlich

Deshalb empfehle ich generell,kontinuierlich zu „listenen“und die Ergebnisse ebenso kontinuierlich auszuwerten. Employee Listening ist nicht einfach „die Mitarbeiterbefragung“, kein einmaliges Projekt. Nur wenn es Teil unserer täglichen Arbeit ist, können wirTrends erkennen und Veränderungen in den Interessen und Bedürfnissen der Mitarbeiter feststellen.Nur so können wir schnell auf aktuelle Themen oder Herausforderungen reagieren, relevant werden und letztlich auch Kosten sparen: Wenn wir gezielt auf die Bedürfnisse der Mitarbeiter:innen eingehen, geben wir weniger Geld für irrelevante Inhalte aus.Es gibt verschiedene Methoden und Tools, um strategisches und datenbasiertes Employee Listening zu betreiben: KPI Tracker, Umfragetools, Feedbackformulare etc. In Haiilo-Umgebungenempfehlen wir von KammannRossizum BeispielHaiilos „Employee Listening Funktionalität“. Mit dieser Funktionalität fragen wir dann nicht, wie sich die Mitarbeiter fühlen, sondern wie zufrieden sie mit bestimmten Inhalten sind, ob sie Inhalte vermissen, was sie über strategische Initiativen oder das Management wissen und was nicht. Mit den kurzen Haiilo Umfragen können wir diese Fragen in Echtzeit und im Arbeitsumfeld stellen – mit einerRücklaufquote von bis zu 81 Prozent, mehrsprachig, zielgerichtet und vor allem regelmäßig und automatisiert.

#### Formate gezielt auswählen

Auf Basis dieser Daten können wir dann einenrelevanz-basierten Redaktionsplanerstellen und die passenden Inhalte und Formate auswählen. Hier einige Beispiele aus der Praxis:⭐️ Die Mitarbeiter:innen fühlen sich nicht genug über Produkte informiert? Dann gebt doch mal zwei Mitarbeiter:innen eine Kolumne, in der sie regelmäßig die neuen Killer-Produkte testen und darüber berichten. Oder führt (fiktive) Interviews mit diesen Produkten („Hey, Kühlschrank, bist du wirklich so smart, wie du denkst?“).⭐️ Euer neuer CEO ist nicht bekannt genug oder gilt als zu „distanziert“? Dann begleitet ihn doch einen Tag lang und berichtet darüber. Oder lasst ihn in einem Interview über seine größten Fehler sprechen. Das macht ihn menschlicher und näher.⭐️ Die Kolleg:innen haben genug von Change-Themen? Dann brauchen sie nicht das hundertste Projekt-Update, sondern vielleicht ein Quiz, das ihr Change-Wissen abfragt. Das macht mehr Spaß und vielleicht lernt der eine oder die andere dabei noch etwas dazu.
Content Hubs, deren Redaktionsplan auf Basis von Relevanzdaten erstellt wird, sind erfolgreicher.

#### Wer zuhört, gewinnt

Engagement für eure Inhalte ist kein Selbstläufer, #wisstihrselbst. Aber strategisches und idealerweise datenbasiertes Employee Listening kann die Geheimwaffe sein, die euch besser macht. Wenn ihr die Bedürfnisse, Interessen und Ansichten der Mitarbeiter:innen wirklich kennt und versteht, könnt ihr Inhalte und Formate entwickeln, die nicht nur dem Unternehmen helfen, sondern auch bei den Kolleg:innen auf echte Begeisterung stoßen. Ob ihr dabei so weit geht, einen „Content Relevance Score“ als KPI einzuführen – also eine aggregierte Kennzahl, die anzeigt, wie gut ihr den Puls der Mitarbeiter:innen getroffen habt -, bleibt euch überlassen. Aber auch wenn ihr nur themen- oder medienbezogen (aber kontinuierlich!) zuhört und misst, kann das schon ein Turbo für eure Relevanz sein. Probiert es einfach aus.
Dieser Blogbeitrag ist zuerst als Gastbeitrag vonCarsten RossiimHaiilo-Blogerschienen.
