---
url: https://www.kammannrossi.de/blog/content-impact-workshop
scraped_at: 2026-01-08 18:39
title: Content Impact. Ein Sonett.
---

# Content Impact. Ein Sonett.


# Content Impact. Ein Sonett.

vonCarsten Rossi| 30.01.2023 08:00:00 | 2 Minuten Lesezeit
Wer länger mit uns arbeitet, kennt sicherlich unseren Claim “Content Drives Action. Otherwise it's Poetry". Er betont, dass Inhalte dazu beitragen, Zielgruppen zu einer bestimmten Handlung zu bewegen.Er unterstreicht kurz und knapp die Notwendigkeit, dass Inhalte in der Unternehmenskommunikation und im Marketing nicht nur unterhaltsam oder informativ sein sollten, sondern dass sie immer einen konkreten Zweck haben – zum Beispiel, dass Zielgruppen einen Kauf tätigen, sich anmelden, Inhalte teilen, das eigene Verhalten ändern etc.
Zudem ist der Claim auch für uns selber ein Reminder, dass unsere kreativen Inhalte nicht nur dazu da sind, schön auszusehen, sondern dass sie für unsere Kunden wirken sollen. Wirkung schlägt im Zweifelsfall (manchmal leider) das eigene ästhetische Empfinden.
Die meisten, die diesen Claim lesen, verstehen das alles recht intuitiv.Er ist deshalb oft genug ein guter Einstieg in Gespräche mit potenziellen Kunden. Er funktioniert recht gut in seinem eigenen Sinne. Andererseits hatten wir aber schon immer das Gefühl, dass wirder Poesie hier ein wenig unrecht tun und sie schnöde auf dem Altar der besseren Verständlichkeit opfern. Denn Gedichte können durchaus revolutionäre Wirkung haben – man denke an Ferdinand Freiligraths Flugblattgedichte von 1848. Und es gibt auch Verse, oder zumindest Reime, die verkaufsfördernde Wirkung haben. Das beste Beispiel dafür ist und bleibt “Haribo macht Kinder froh und Erwachsene ebenso”, den es sogar in anderen Sprachen gibt:
Haribo c'est beau la vie pour les grands et les petits.Kids and grown-ups love it so. The happy world of Haribo.
Aus diesem Grund haben wir beschlossen – und hier geht der Pfeil endlich durch die Brust ins Auge –unseren neuesten Workshop ebenfalls mit Gereimtem zu bewerben. Der Workshop selber ist ein eher sachliches Produkt, nennt sich “Content Impact Workshop”, hat sich aber, wie wir finden, ein shakespeareskes Sonett zur Promotion redlich verdient.
Content Impact Reviews, a must to measure,To track the reach, the impact, and the gain,To know the audience, their likes and their pleasure,And tailor our message, to avoid any strain.
Without this review, our efforts may falter,Our message may miss, the target to be true,Our budget may suffer, and our results alter,With no way to know, what we should do.
We must measure the click, the views and the stay,To understand, what works and what's in vain,And adjust our strategy, in the right way,To reach our goal, and not live in disdain.
For in this world of constant change and shift,The only way to move forward, is to measure and lift.
Und wer sich jetzt fragt, wie wir zu diesen großartigen Zeilen gekommen, den klären wir gerne in einem anderen Workshop über dieVorteile generativer KIs wie ChatGPTauf. Dieser Workshop ist aber noch nicht fertig und wahrscheinlich werden wir sie mit einer eigenen Ballettaufführung promoten 😉
Bis wir mit den Proben dafür durch sind, können Sie aber gerne das Sonett auswendig lernen odergleich hier unseren Workshop buchen.
