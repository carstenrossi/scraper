---
url: https://www.kammannrossi.de/blog/definitionsfrage-was-ist-eigentlich-ein-magazin
scraped_at: 2026-01-08 18:39
title: Definitionsfrage: Was ist eigentlich ein Magazin? (Update)
---

# Definitionsfrage: Was ist eigentlich ein Magazin? (Update)


# Definitionsfrage: Was ist eigentlich ein Magazin? (Update)

vonCarsten Rossi| 03.08.2021 11:31:23 | 2 Minuten Lesezeit
Photo by Charisse Kenion on Unsplash
Wenn bei Kammann Rossi schon das zweiteJahr des Magazinsläuft, sollten wir uns doch eine wichtige Frage stellen:Was ist ein Magazin eigentlich?
Hier mal die "Big 7" Attribute, von denen wir glauben, dass sie ein Print- und ein Online-Magazin (das wir manchmal auch "Content Hub" nennen) ausmachen:
- Inhaltliche und thematische Fokussierung: Die Inhalte eines Magazins oder Content Hubs konzentrieren sich zum überwiegenden Teil auf ein Thema, ein Event oder ein Zielgruppen-Bedürfnis. Es mag andere Elemente geben, aber ein starker inhaltlicher Zusammenhalt ist immer gegeben.
- Individuelles und unabhängiges Branding: Magazine und Hubs sind eigene Marken, es ist eine Content Brand. Die Gestaltung mag von der Marke der publizierenden Organisation beeinflusst sein, grundsätzlich versucht das Design aber eine gewisse Unabhängigkeit zu bewahren.
- Design-Anspruch und -Qualität: Eines der wesentlichen Merkmale von Magazinen ist ihraufwändiges Design, insbesondere ein Print- und Online-Layout mit hohem kreativen Anspruch. Es mag Standardformate geben, die wichtigen "Strecken", z.B. Reportagen, besitzen aber eine hohe, auf den Inhalt abgestimmte Individualität. Auch das Cover des Print- bzw. die Homepage des Online-Magazins genießt eine besondere Aufmerksamkeit und reflektieren die Content Brand besonders stark.
- (Multi-) Medialität und hoher visueller Anteil: Im Gegensatz zu Zeitungen oder Sites mit hohem (Kurz-)Nachrichten-Anteil werden audiovisuelle Medien (Fotografie, Video, Audio, Illustration, Infografiken etc.) in erhöhtem Maße eingesetzte und stellen einen großen, wenn nicht sogar mehrheitlichen Anteil der Inhalte dar.
- Hohe Komplexität und bewusstes Storytelling: Magazine sind spezialisiert auf Longform-Inhalte. Sie bieten die Möglichkeit, komplexe Zusammenhänge über mehrere Seiten und durch die die geschickte Kombination verschiedener Formate darzustellen. Natürlich gibt es auch kurze Inhalte, dominiert werden sie jedoch von umfangreichen inhaltlichen Auseinandersetzungen mit einem Thema und intensivem Storytelling.
- Regelmäßige und zyklische Erscheinungsweise: Als Print-Medium sind sie geprägt von einer  zyklischen (wöchentlichen / monatlichen / quartalsweisen / jährlichen) Erscheinungsweise. AlsOnline- und damit Echtzeit-Medium haben sie dieses    Attribut weitestgehend eingebüßt, arbeiten im allgemeinen aber weiterhin mit sehr regelmäßigen kontinuierlichen Update-Zyklen. Beide kann man natürlich auch kombinieren.
- "Owned Media" des Absenders: In einer idealen Welt sind Magazine zu 100% in der Verfügungsgewalt des Publishers. Sie werden von ihm / ihr hergestellt und produziert und auch die technischen Plattformen sind im Besitz des Publizierenden. Sie sind "owned" und nicht "rented land". De facto ist es aber so, dass wir zur Erzielung der nötigen Reichweiten "Outlet-Magazine" benötigen. Magazine müssen Formeln und Formate finden, die ihre Content-Brand adäquat auf Plattformen wie Medium,  Instagram, Flipboard oder LinkedIn featuren.Sehen Sie das genauso? Fällt Ihnen noch etwas ein? Wir freuen uns über Feedback per Mail oder aufLinkedIn.
