---
url: https://www.kammannrossi.de/blog/der-kammann-rossi-guide-fuer-effektives-prompting-mit-chatgpt
scraped_at: 2026-01-08 18:39
title: Der Kammann Rossi Guide für effektives Prompting mit ChatGPT
---

# Der Kammann Rossi Guide für effektives Prompting mit ChatGPT


# Der Kammann Rossi Guide für effektives Prompting mit ChatGPT

vonCarsten Rossi| 30.10.2023 10:38:09 | 3 Minuten Lesezeit
Wie ChatGPT & Co. die Aufgaben der Internen Kommunikation verändern werden
Natürlich nutzen wir Künstliche Intelligenz in unserer Arbeit. Da sind wir nicht anders als Sie. Damit wir dabei aber auch besser werden, sammeln wir nicht nur Prompts, sondern versuchen auch Schritt für Schritt besser zu werden. Deshalb haben wir unsere Learnings der letzten Monate – ganz agenturtypisch 😎 – als Akronym zusammengefasst – und zwar alsC/h/a/t/G/P/T. Und da wir ja alle Zeit sparen wollen, gehen wir gleich in medias res 🚀
C wie Clear: Klarheit ist der Schlüssel
- Klares Briefing geben:Seien Sie präzise in Ihren Anweisungen. Je klarer Sie Ihre Erwartungen und Anforderungen formulieren, desto besser wird das Ergebnis.
- Kurze Sätze nutzen:Lange und verschachtelte Sätze können zu Missverständnissen führen. Halten Sie Ihre Prompts kurz und auf den Punkt.
- Einfache Sprache verwenden:Vermeiden Sie Fachjargon, es sei denn, er ist notwendig. Eine einfache und klare Sprache sorgt für bessere Ergebnisse.
- Links und Best Practices verwenden:Wenn Sie auf externe Quellen verweisen, geben Sie direkte Links an. Nutzen Sie bewährte Praktiken, um die Qualität der Antworten zu verbessern.
H wie Honest: Ehrlichkeit währt am längsten
- Positive und negative Anmerkungen geben:Geben Sie sowohl positives als auch negatives Feedback. Dies hilft der KI, besser zu verstehen, was Sie erwarten.
- Deutliches Feedback kommunizieren:Seien Sie in Ihrem Feedback klar und deutlich. Die KI versteht Nuancen nicht auf die gleiche Weise wie Menschen.
- Wie mit einem Menschen interagieren:Behandeln Sie die KI, als würden Sie mit einem Menschen sprechen. Dies fördert natürlichere und relevantere Antworten.
- Im Zweifelsfall neu machen:Wenn die Antwort nicht Ihren Erwartungen entspricht, zögern Sie nicht, die Frage neu zu formulieren und es noch einmal zu versuchen.
A wie Adaptive: Anpassungsfähigkeit ist alles
- Vorbilder angeben:Geben Sie Beispiele für den Stil an, den Sie erwarten. Dies hilft der KI, sich besser anzupassen.
- Personen / Entitäten simulieren:Wenn Sie möchten, dass die KI eine bestimmte Person oder Entität simuliert, geben Sie dies klar an.
- Tonalität bestimmen:Bestimmen Sie den Ton Ihrer Kommunikation. Soll es formal oder informell sein? Bestimmen Sie dies im Voraus.
- Dos und Don'ts definieren:Legen Sie klare Richtlinien fest, was die KI tun und lassen sollte.
T wie Tailored: Maßgeschneiderte Lösungen
- Zielgruppe beschreiben:Wer ist Ihre Zielgruppe? Stellen Sie sicher, dass Ihre Prompts auf Ihre Zielgruppe zugeschnitten sind.
- Kanal angeben:Über welchen Kanal kommunizieren Sie? Die Art der Kommunikation kann je nach Kanal variieren.
- Format angeben:In welchem Format soll die Antwort sein? Text, Audio, Video? Seien Sie spezifisch.
- Länge angeben:Wie lang soll die Antwort sein? Geben Sie eine klare Vorstellung von der gewünschten Länge.
G wie Gradual: Schritt für Schritt zum Erfolg
- In mehrere Teilschritte aufteilen:Zerlegen Sie komplexe Anfragen in kleinere Teilschritte.
- Ergebnisse zusammenfassen:Fassen Sie die Ergebnisse der einzelnen Schritte zusammen, um ein klares Gesamtbild zu erhalten.
- Wiederholen und nachfragen:Wenn etwas unklar ist, wiederholen Sie die Anfrage oder stellen Sie zusätzliche Fragen.
- Evtl. auf mehrere Chats aufteilen:Bei umfangreichen Anfragen kann es sinnvoll sein, die Kommunikation auf mehrere Chats aufzuteilen.
P wie Processual: Prozesse optimieren
- Plugins nutzen:Erweitern Sie die Funktionalität von ChatGPT mit Plugins wie KeyMate.AI.
- Automatisieren:Nutzen Sie Automatisierungstools wie Zapier oder IFTTT, um Prozesse zu vereinfachen.
- „Halbautomatisierungen“ entwerfen:Entwerfen Sie Prozesse, die sowohl automatisierte als auch manuelle Schritte beinhalten.
- Promptliste anlegen:Erstellen Sie eine Liste mit Standard-Prompts, die Sie regelmäßig verwenden.
- Formatierungsoptionen angeben:Geben Sie an, welche Formatierungsoptionen verwendet werden sollen (Markup, BBCode, HTML).
T wie Thorough: Gründlichkeit zahlt sich aus
- Fakten checken (lassen):Überprüfen Sie die von der KI gelieferten Informationen auf ihre Richtigkeit.
- Auto-/Stil-Korrektur:Nutzen Sie Tools zur automatischen Korrektur und Stilprüfung, um die Qualität der Texte zu sichern.
- „Brand-Fit“ beachten:Stellen Sie sicher, dass die Antworten der KI zu Ihrer Marke und Ihrem Kommunikationsstil passen.
- Übersetzungen evtl. an Natives:Wenn Sie Inhalte in anderen Sprachen benötigen, lassen Sie diese von Muttersprachlern überprüfen.
Wenn Sie sich also „ChatGPT“ merken können, können Sie in Zukunft auch ChatGPT effektiv nutzen 😉. Happy Prompting!
Interessieren Sie sich auch für unseren Impuls-Kurs „Prompting mit Chat GPT für die Unternehmenskommunikation“?Füllen Sie einfach das unten stehende kurze Formular aus – wir melden uns dann bei Ihnen.

# Impuls-Kurs: Prompting mit Chat GPT für die Unternehmens­kommunikation


### Unverbindliche Information

