---
url: https://www.kammannrossi.de/blog/die-ki-roadshow-fuer-kommunikationsteams-startet-in-koeln
scraped_at: 2026-01-08 18:39
title: #keineagentur: Die KI-Roadshow für Kommunikationsteams startet in Köln
---

# #keineagentur: Die KI-Roadshow für Kommunikationsteams startet in Köln


# #keineagentur: Die KI-Roadshow für Kommunikationsteams startet in Köln

vonCarsten Rossi| 08.01.2025 13:04:24 | 2 Minuten Lesezeit
Hilft KI in der Unternehmenskommunikation – ein Thema, das derzeit so heiß diskutiert wird wie die Frage, ob man Pizza Hawaii nun mag oder nicht (Spoiler: Die Antwort hängt davon ab, wie viel Restalkohol noch im Blut ist). Bei Kammann Rossi haben wir uns entschieden, statt endloser Debatten lieber zur Tat zu schreiten. Mit unserer#keineagentur KI-Roadshowmöchten wir Ihnen zeigen, wie Sie generative KI praktisch und effektiv in Ihrem Kommunikationsalltag einsetzen können. 🍍🍕
Aber Moment mal, #keineagentur? Von einer Agentur? Ja, Sie haben richtig gelesen. Wir bei Kammann Rossi – immerhin seit über 50 Jahren im Geschäft – sind davon überzeugt, dass sich unsere Rolle verändern wird. Die Zukunft der Content Creation liegt zunehmend in den Händen der Inhouse-Teams, unterstützt durch clevere KI-Tools. Man könnte es eine Art produktive Selbstabschaffung nennen (oder einen Rollenwechsel von Handwerker*innen zu Beratern und Creative Geniuses 😎).
In unserenfokussierten 2-Stunden-Workshopszeigen wir Ihnen, wie Sie generative KI – von Sprach- bis zu Bild- und Videomodellen – für Ihren Kommunikationsalltag nutzen können. Und nein, wir werden Sie nicht mit PowerPoint-Präsentationen in den Schlaf wiegen. Stattdessen gehen wir „hands-on“ in unsere eigens für den Workshop eingerichtete, gesicherte KI-Umgebung „AssistantOS“. Hier können Sie alles praktisch ausprobieren und erhalten Zugang zu ausgewählten kreativen KI-Tools.

## Was erwartet Sie?

- Sie lernen, wie Sie KI dazu bringen, in Ihrem persönlichen Stil zu schreiben (und nicht wie ein Praktikant auf Ecstasy).
- Sie erfahren, wie Sie Ihr Unternehmenswissen clever in Ihre KI-Prompts einbauen (ohne dabei wie ein wandelndes Unternehmenswiki zu klingen).
- Sie entdecken, welche KI-Tools sich für welche Kommunikationsaufgaben eignen (Nächster Spoiler: ChatGPT ist nicht der Heilige Gral der Content-Erstellung).
- Sie finden heraus, wie Sie KI in Ihren täglichen Workflow integrieren
Der nächste Termin findet am22. Januar 2025 von 09:00 bis 11:00 Uhrin denDesign Offices Köln Dominiumstatt. Die Teilnehmerzahl ist auf 10 begrenzt – nicht aus Snobismus, sondern weil wir wirklich ins Detail gehen möchten (und weil unser Kaffeevorrat begrenzt ist).

## Warum sollten Sie teilnehmen?

Nun, abgesehen von der Chance, Ihre KI-Skills auf das nächste Level zu bringen, bieten wir Ihnen:
- Einen Blick hinter die Kulissen unserer 50-jährigen Agenturerfahrung (jetzt mit 100% mehr KI und 50% weniger Bullshit-Bingo)
- Die Möglichkeit, Ihre Fragen zu stellen (auch die vermeintlich dummen – wir versprechen, nicht zu urteilen... zumindest nicht laut)
- Einen kleinen Networking-Imbiss nach dem Workshop (denn eines kann KI noch nicht: mit Ihnen Kaffee trinken und über das Wetter small talken)
Sind Sie interessiert? Dann melden Sie sich überdas Formular unten oder auf unserer Websitean, und wir schicken Ihnen alle weiteren Informationen. Und keine Sorge, dies ist kein verstecktes Verkaufsevent. Versprochen. Hand aufs Herz und Spucke drauf. 🤞
P.S.: Bringen Sie Ihre Neugier, Ihren Humor und Ihr Laptop mit. Für alles andere sorgen wir.
P.P.S.: Und ja, natürlich wurde dieser Blogpost mit Hilfe von KI geschrieben. Aber keine Sorge, er wurde von einem echten Menschen (mit fragwürdigem Humor) redigiert. Die KI wollte ursprünglich noch einen Witz über Schrödingers Katze einbauen, aber wir fanden, das wäre zu... naja, Sie wissen schon.

# Das interssiert mich!


### Ich möchte gerne teilnehmen:

