---
url: https://www.kammannrossi.de/blog/folgen-sie-uns-in-die-content-community
scraped_at: 2026-01-08 18:39
title: Folgen Sie uns in die Content Community
---

# Folgen Sie uns in die Content Community


# Folgen Sie uns in die Content Community

vonKR Redaktion| 20.02.2024 12:19:35 | 3 Minuten Lesezeit
Sie haben es vielleicht bereit mitbekommen: Wir verlagern unseren Content sukzessive in eine Community. Und würden Sie gerne dorthin mitnehmen.Wir haben dazu ja schon einenBlogpostgeschrieben, aber um Sie noch einmal in aller Kürze abzuholen: Wir bei KR beobachten, dasstraditionelles Content Marketingmit Hilfe von Content Hubs (Blogs, digitalen Magazinen etc.) zunehmendweniger effektivwird. Denn die digitale Landschaft verändert sich: angesichts sinkender Sichtbarkeit und Reichweite braucht es schon länger immer mehr Content und immer mehr Content Promotion, um überhaupt noch wahrgenommen zu werden.Hinzu kommt ganz frisch die Herausforderung durch KI-Tools, die direkte Antworten auf Nutzerfragen liefern und den Besuch von traditionellen Websites und Content-Hubs zusehends überflüssig machen.
Deshalb ist es an der Zeit, sich zurückzuziehen, oder besser: sich zurück zu besinnen auf den Wert von Beziehungen. Wir sehen die Zukunft des Content Marketings imAufbau echter, menschlicher Verbindungen und im Dialoginnerhalb einer Content Community, um gemeinsam Probleme zu lösen.
Deshalb gibt es jetzt unsere „Invite (by KR)“ Community zu der wir sie herzlich einladen möchten.
Sie finden dort natürlich das, was man von einem Content Hub erwartet: alsoNews, Event-Kalender, Aufzeichnungen von Webinaren, Whitepaper, Studien, Checklisten, Guidelineszu allen wichtigen Themen der Internen und Externen Kommunikation mit einem besonderen Fokus auf die Themen „Reach“ und „Engagement“. Alles, was wir bisher an Premium-Content veröffentlich haben, findet sich dort (und bald nur noch dort).
Sie finden in der Community vor allem abereinen Raum, in dem sich die Mitglieder in Diskussionsforen und Chats austauschenund direkt mit Kollegen aus anderen Unternehmen und uns als Agentur interagieren können. Das passiert zwanglos und garantiert ohne Sales-Druck in diversen digitalen Foren, aber auch durch Formate wie
- einer regelmäßigen„Ask-me-anything“ Veranstaltung mit Carsten Rossi;
- Live-Demos neuer Technologien und Best Practices;
- Offline-Veranstaltungenim Rahmen bekannter Branchen-Events (z.B. Stammtische zurVoicesKonferenz, zurCMCX, zumBCModer demInkometa-Award);
- die„Direct Line“, also die Möglichkeit unserer Geschäftsführung und anderen KR Kollegen direkt konkrete Fragen zu fachlichen Problemen zu stellen (ohne irgendeine Verpflichtung).
Kurz: wir meinen es ernst. Wir wollen eine Beziehung zu ihnen, die auf Kompetenz aufgebaut ist und auf Vertrauen. Deshalbbrennen wir darauf,die Community gemeinsam mit Ihnen auszubauenund zu einem der besten Räume für Wissen, Dialog und Gemeinschaft in der Unternehmenskommunikation zu machen.
Gerne laden wir Sie deshalb heute in unsere „Invite (by KR)“ Online-Community ein.Melden Sie sich gerne direktdirekt unter diesem Linkan oder nutzen Sie das Formular, falls Sie noch Fragen haben.

# FEEL INVITED

