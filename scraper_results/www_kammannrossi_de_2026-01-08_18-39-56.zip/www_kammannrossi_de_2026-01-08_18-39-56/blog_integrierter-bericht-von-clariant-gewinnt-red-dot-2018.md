---
url: https://www.kammannrossi.de/blog/integrierter-bericht-von-clariant-gewinnt-red-dot-2018
scraped_at: 2026-01-08 18:39
title: Integrierter Bericht von Clariant gewinnt Red Dot 2018
---

# Integrierter Bericht von Clariant gewinnt Red Dot 2018


# Integrierter Bericht von Clariant gewinnt Red Dot 2018

vonJürgen Jehle| 31.10.2018 09:53:45 | 1 Minute Lesezeit
Nach dem bisherigen Preisregen für den Integrierten Bericht 2017 von Clariant (Best of Content Markting BCM, Berliner Type, Galaxy Award, ICMA …) fehlte noch das i-Tüpfelchen. Und es kam: Mit dem Red Dot für Communication Design würdigte auch die Red-Dot-Jury den Bericht für seine konzeptionelle, gestalterische und inhaltliche Stärke.
Gemeinsam mit Sustainserv, Nexxar und Mutabor freut sich Kammann Rossi über diese Auszeichnung. Besonders freut uns neben dem gestalterischen Lob die Heraushebung des ganzheitlichen Storytelling-Ansatzes:
> „Das Gestaltungskonzept beschränkte sich nicht auf den Bericht, sondern verfolgte einen ganzheitlichen Ansatz. Dabei nahmen die handelnden Personen eine besondere Rolle ein. Sie verbinden das Reporting und die Story-Ebene, die Print- und Online-Berichte sowie den einjährigen Rollout der Kommunikationskampagne. Auf diese Weise vermittelt das Design die Inhalte und unterstreicht deren Bedeutung. Der reduzierte Layoutstil schafft zudem Transparenz und erleichtert die Navigation im Bericht.“
Lesen Sie hier die Begründung der Jury auf derRed Dot Website.
Und hier geht es direkt zumOnline Report.
