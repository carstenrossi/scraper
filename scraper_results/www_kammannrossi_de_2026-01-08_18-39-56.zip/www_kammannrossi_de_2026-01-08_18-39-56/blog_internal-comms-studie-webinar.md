---
url: https://www.kammannrossi.de/blog/internal-comms-studie-webinar
scraped_at: 2026-01-08 18:39
title: Internal Communications Monitor - Die Vorstellung der Ergebnisse als Aufzeichnung
---

# Internal Communications Monitor - Die Vorstellung der Ergebnisse als Aufzeichnung


# Internal Communications Monitor - Die Vorstellung der Ergebnisse als Aufzeichnung

vonCarsten Rossi| 04.06.2020 15:20:57 | 1 Minute Lesezeit
Nachdem wir 2019 bereits zum vierten Mal die Frage nach derZukunft der Mitarbeiterzeitung in der DACH-Regiongestellt haben, sind wir 2020 noch einen Schritt weitergegangen. Zusammen mit derSchool for Communication and Management (SCM)undStaffbasewollten wir wissen, wie es um die interne Kommunikation in Europa steht.
Der digitale Wandel prägt die interne Kommunikation in Europa wie kein anderes Thema – dies spiegelt sich auch in den Studienergebnissen des Internal Communications Monitor 2020. Die interne Kommunikation fungiert als treibende Kraft für Trends wiemobile Kommunikationund den Digital Workplace und stellt interne Kommunikator*innen vor immer neue Herausforderungen.Europaweit dient die interne Kommunikation nicht mehr nur als Sprachrohr der Unternehmensführung, sondern stellt zunehmend die Mitarbeitenden in den Fokus.

## Internal Communications Monitor 2020: Ausführliche Betrachtung

Grund genug, sich umfassend mit der Rolle der internen Kommunikation in europäischen Unternehmen auseinanderzusetzen und zu untersuchen, wie interne Kommunikation im europäischen Vergleich umgesetzt wird.
- Wie ist die interne Kommunikation in europäischen Unternehmen organisiert? Was sind Gemeinsamkeiten und Unterschiede?
- Welchen Herausforderungen und Zielen sieht sich die interne Kommunikation 2020 gegenüber und mit welchen Medien und Kanälen versucht sie diese zu erreichen?
- Wie verändert sich die Rolle der internen Kommunikation innerhalb des Unternehmens mit der fortschreitenden digitalen Transformation?
Rund 260 Kommunikationsexpert*innen aus ganz Europa haben diese und weitere Fragen des Internal Communications Monitor 2020 beantwortet. Ihre Antworten beschreiben den Status der internen Kommunikation auf europäischer Ebene und geben einen Überblick über relevante Kanäle, Inhalte und Formate.
Wenn Sie Interesse an der Aufzeichnung unserer Vorstellung und Diskussion der Studienergebnisse durch Kammann Rossi, die SCM und Staffbase haben, melden Sie sich gerne beiJule Sauter.
