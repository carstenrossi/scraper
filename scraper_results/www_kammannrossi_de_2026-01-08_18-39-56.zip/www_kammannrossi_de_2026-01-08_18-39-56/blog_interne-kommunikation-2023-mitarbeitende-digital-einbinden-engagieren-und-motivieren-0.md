---
url: https://www.kammannrossi.de/blog/interne-kommunikation-2023-mitarbeitende-digital-einbinden-engagieren-und-motivieren-0
scraped_at: 2026-01-08 18:39
title: Interne Kommunikation: Welche Formate für welchen Kanal?
---

# Interne Kommunikation: Welche Formate für welchen Kanal?


# Interne Kommunikation: Welche Formate für welchen Kanal?

vonCarsten Rossi| 13.12.2022 08:00:00 | 1 Minute Lesezeit
Kammann Rossi und die School for Communication and Management (SCM) stellen 2022 in einer gemeinsamen Studie – nach 2015, 2017 und 2019 bereits zum vierten Mal - wichtige Fragen zur Zukunft der Internen Kommunikation und insbesondere der Mitarbeiterzeitung. Teilgenommen haben 251 Kommunikationsprofis aus Unternehmen, Agenturen und Dienstleistern aus dem D/A/CH-Raum. Wir präsentieren im Blog Auszüge aus dieser Studie, dieses Mal zum Thema Kanalauswahl.
Wir haben in unserer Studie gefragt, welche Art von redaktionellen Formaten und journalistischen Stilformen die Befragten für welchen Kommunikationskanal für geeignet halten: für die gedruckte MItarbeiterzeitung, die digitale Version oder die Mitarbeiterapp. Wohin also gehören Aktuelles, Reportagen, Personalien oder Serviceinformationen? Die wichtigsten Ergebnisse:
- Aktuelles gehört in dieApp.
- Hintergrundberichte werdengedruckt.
- Personalien werden auch gerne imOnline-Magazinveröffentlicht.
Ob und inwiefern diese Auswahl der Befragten noch angemessen ist, müsste allerdings einmal diskutiert werden. Gerade Online-Medien bieten - mit Hilfe von Videos, Infografiken, Audio-Elementen oder sogar 3D-Renderings - großartige Möglichkeiten, Hintergründiges erlebbar zu machen. Aber anscheinend wird die "Ruhe" beim Lesen eines Print-Magazins zur Zeit von vielen noch als sehr hohes Gut bei der Lektüre umfangreicher Texte gesehen.
Hier die Ergebnisse im Detail.
