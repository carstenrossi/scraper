---
url: https://www.kammannrossi.de/blog/interne-kommunikation-2023-mitarbeitende-digital-einbinden-engagieren-und-motivieren
scraped_at: 2026-01-08 18:39
title: Interne Kommunikation 2023: Mitarbeitende digital einbinden, engagieren und motivieren
---

# Interne Kommunikation 2023: Mitarbeitende digital einbinden, engagieren und motivieren


# Interne Kommunikation 2023: Mitarbeitende digital einbinden, engagieren und motivieren

vonDorothee Thomsen| 07.12.2022 13:51:47 | 3 Minuten Lesezeit
Die letzten Jahre brachten viele Unternehmen an ihre Grenzen – vor allem diejenigen, für die Digitalisierung bislang kein wichtiger Agendapunkt war. Der Transformationsdruck ist groß, und zwar nicht nur, was das richtige Home-Office-Setup angeht, sondern vor allem, was die Struktur und das im Unternehmen vorherrschende digitale Mindset betrifft. Die Bereitschaft, digital zusammenzuarbeiten, ist für Organisationen heute die Voraussetzung, auch im Remote- oder Hybrid-Modell die Produktivität und das Engagement aufrechtzuerhalten. Mit welchen konkreten Maßnahmen lässt sich dies im Unternehmen umsetzen?

#### 1. Ein digitales Mindset schaffen – auf allen Ebenen

Change Management und das Schaffen neuer digitaler Strukturen fängt nicht in der HR-Abteilung an, sondern bei den Führungskräften.Laut dem New Work Report von Gründerszene gelingt nur einem von fünf Unternehmen dieser Wandel – der Rest scheitert. Warum? Weil sich meistens die Erwartungen an die Mitarbeiter*innen ändern, aber nur in den seltensten Fällen auch der Führungsstil.
Wie lassen sich die Weichen für digitale und moderne Kommunikation und Kollaboration stellen? Indem Hierarchien durchbrochen werden.Kollaboration ist flexible Zusammenarbeit. Das bedeutet auch, dass Führungskräfte die spezifischen Fähigkeiten ihrer Mitarbeiter*innen fördern müssen, damit das Unternehmen profitiert. Dabei müssen Vorgesetzte sich eher in die Rolle eines Coaches begeben. Die unterschiedlichen Skills in einem Team müssen erkannt, richtig eingesetzt und wertgeschätzt werden. Das bedeutet auch: Mitarbeiter*innen mit möglichen Vorbehalten gegenüber neuen digitalen Prozessen nicht zurückzulassen.

#### 2. Wirklich alle Mitarbeiter*innen einbinden

Beim Thema Inklusion dürfen wir einen wichtigen Punkt nicht vergessen. Die Realität in vielen Organisationen 2022 sieht so aus: Mitarbeiter*innen aus vier Generationen arbeiten zusammen. Und nicht jede dieser Generationen hat dieselbe Bereitschaft, digitale Formate und Tools zu nutzen. Gerade für ältere Arbeitnehmer*innen kann die Digitalisierung von Prozessen zu einer echten Herausforderung werden.Der immer schnellere Wandel der Arbeitswelt und der drastische Umbruch vertrauter Strukturen kann diese Kolleg*innen stark verunsichern und die Angst vor Fehlern schüren.Wie kann man diesem Teil der Belegschaft Angst vor der Nutzung neuer Tools nehmen?
- Praxisnahe Workshops mit der Möglichkeit, Fragen zu stellen, können helfen, die Hemmschwelle zu senken und die Nutzung neuer Technologien zu fördern.
- Die Sensibilisierung der Führungskräfte auf die unterschiedlichen Bedürfnisse verschiedener Teammitglieder erleichtert das Erwartungsmanagement – auf allen Seiten.
- Auch Gamification kann dabei helfen, digitale Prozesse besser zu verstehen: Durch spielerische Elemente können Kolleg*innen ohne Druck lernen, mit neuen Tools umzugehen und digitale Kompetenzen aufbauen – ohne Angst vor Fehlern.

#### 3. Das richtige technologische Set-up bereitstellen

Es gibt zahlreiche Tools und Software-Lösungen, die dabei helfen, die Kommunikation in Firmen nachhaltig zu optimieren.Ein Beispiel dafür sindSocial-Intranet-Plattformen wie Haiilo, die Kommunikationskanal, Wissensdatenbank und News-Channel vereinen.Wichtig dabei: die Lösung muss flexibel und individuell einsetzbar sein und die Employee Journey so intuitiv wie möglich halten - schließlich steht und fällt der Erfolg mit der Bereitschaft der Mitarbeiter*innen, diese auch zu nutzen. Die Möglichkeit einer einfachen Nutzung minimiert die „Hemmschwelle”, neue Technologien in den Arbeitsalltag zu integrieren.

#### 4. Die Bedürfnisse der Belegschaft erkennen

Bestimmt hatten auch Sie schon das ein- oder andere sehr anregende Gespräch mit einzelnen Kolleg*innen am Kaffeeautomaten, das Einblicke in die allgemeine Stimmung gab. Klar, diese kleinen Momente des Austauschs sind sehr wertvoll. Aber: Daraus lässt sich noch lange kein aussagekräftiges Gesamtbild ableiten.
Eine gute Methode, eine Datengrundlage mit Aufschluss auf die echte Stimmung und die konkreten Wünsche der Kolleg*innen zu erlangen, sind Mitarbeiter*innenbefragungen. Dies ist ein standardisiertes Werkzeug, mit dem Arbeitgeber*innen eine große Menge an Daten von der gesamten Belegschaft sammeln können, die sich mit ebenso standardisierten Methoden auswerten lassen. Regelmäßige Surveys liefern Ihnen wertvolle Erkenntnisse darüber, was Ihre Mitarbeiter*innen gerade bewegt und machen ihr Engagement messbar. So erhalten Sie eine valide Faktengrundlage, um Change-Prozesse anzustoßen und die richtigen Entscheidungen für Ihr Unternehmen zu treffen.
Tipp: Haiilo z.B. bietet bereitssmarte Tools mit intelligenten Umfragen, die nachweislich eine Antwortquote von bis zu 81 Prozent erreichen und Ergebnisse in Echtzeit liefern.
Alle, die sich jetzt noch fragen, ob sich eine Investition in Software-Lösungen für ein höheres Employee Engagement lohnt, sollten sich bewusst machen: Es ist 2023 unverzichtbar, allen Mitarbeiter*innen das richtige technologische Set-up für digitale Zusammenarbeit bereitzustellen, sie in neue Prozesse einzubinden und mögliche Probleme zu erkennen, bevor sie entstehen, denn:Zufriedene und engagierte Mitarbeiter*innen sind die Basis für wirtschaftlichen Erfolg.
Dieser Beitrag ist ein Gastbeitrag unseres Software Partners Haiilo.
