---
url: https://www.kammannrossi.de/blog/invite-by-kr-warum-wir-unseren-content-in-eine-community-verlagern
scraped_at: 2026-01-08 18:39
title: INVITE by KR: Warum wir unseren Content in eine Community verlagern
---

# INVITE by KR: Warum wir unseren Content in eine Community verlagern


# INVITE by KR: Warum wir unseren Content in eine Community verlagern

vonCarsten Rossi| 09.01.2024 12:53:55 | 5 Minuten Lesezeit
In den letzten Jahren habe ich, wie viele meiner Kolleginnen und Kollegen in der Branche, tiefgreifende Veränderungen im digitalen Content Marketing erlebt und manchmal auch erlitten.Wir habenneue Kanäle besetzt, neue Formate gelerntund insgesamt die Menge, die Qualität und oft auch die Geschwindigkeit unseres Outputs steigern müssen. Kurz:Es ist von Jahr zu Jahr schwieriger geworden, das Content Biest zu füttern.

## Klassisches Content Marketing lohnt sich immer weniger

Aber es ist dadurch nicht zutraulicher geworden, das Biest. Soll heißen: In dem Maße, in dem wir alle besser und schneller geworden sind,konzentrierten sich die guten CTRs bei Google auf wenige Top-Positionen der SERP(Snippets sei Dank) unddie organische Reichweite in den meisten sozialen Netzwerken nahm ab(ein Hoch auf den Algorithmus). Das hat einerseits handfeste ökonomische Gründe auf Seiten der Anbieter, die darum kämpfen müssen, Relevanz zu gewährleisten, um selbst relevant zu bleiben. Und es hat systemische Gründe, denn immer mehr Content reduziert natürlich die Sichtbarkeit des einzelnen Pieces. Mit anderen Worten: Das Verhältnis von Aufwand zu Ertrag im Content Marketing hat sich in den letzten Jahren zusehends verschlechtert.Die Formel „Content bringt Aufmerksamkeit bringt Umsatz“ ging immer weniger auf.

## Ist die KI der „Weiße Ritter“?

Vor etwa 12 Monaten sah es für einen Moment so aus, als könnte sich das Blatt wenden. Mithilfe von Tools wie ChatGPT, Jasper, Neuroflash etc. konnte der Aufwand der Contenterstellung drastisch reduziert werden. Gut geplant und kalibriert kann mit Hilfe von generativer KIin wesentlich kürzerer Zeit akzeptabler Contenterstellt werden. Ha, Content Biest, friss das!
Doch die Freude währte leider nicht lange. Denn nicht nur wir Kreativen erkannten die Vorteile der KI, sondern auch Konsumenten und Anbieter. Erstere begannen zusehends, ihre Antworten direkt aus der KI zu ziehen – ohne den Umweg über unsere Content Hubs, deren Inhalte das neue KI-Biest längst verdaut hatte. Und die Anbieter – im großen Stil Bing und in Ansätzen auch Google – sahen natürlich auch, dass der Einsatz von KI direkt auf ihrer Plattform ein großartiger Service ist.Die Nutzer bekommen die Antworten mundgerecht direkt im werberelevanten Umfeld geliefert– und müssen nur dann auf die mitgelieferten Links klicken, wenn die KI versagt hat.

## „Content“ braucht „Connections“.

Natürlich kann man auch jetzt noch viel tun, um gefunden und geklickt zu werden. Mit gutem Offpage-SEO, mit Native Advertising oder Paid Posts Newslettern kann man auch weiterhin potenzielle Kunden auf die eigenen Inhalte lenken.
Aber ich bezweifle ehrlich gesagt, dass wir dieses Spiel auf Dauer wirklich gewinnen können.Für viele (und ganz sicher auch für uns) wird das alles viel zu aufwändig und zu teuer. Wir können die eine oder andere Schlacht gewinnen, aber den Krieg werden wir sicher nicht gewinnen. Allein schon deshalb, weil jedes neue Piece gleichzeitig auch die KI nutzt und sich parallel dazu – davon bin ich überzeugt – das Nutzerverhalten nicht nur kurz-, sondern auch langfristig ändern wird: Wir werden nicht mehr nach Informationen suchen, sondern Antworten erwarten. Ob von ChatGPT oder Bard oder Perplexity ist dabei zweitrangig. Die werden es schon richten, uns braucht kein Mensch mehr. Zumindest nicht mehr so wie bisher.
Was also tun? Wie bekommen wir die Aufmerksamkeit von Zielgruppen für unseren Content? Und vor allem: Wie binden wir sie langfristig?
Kurze Antwort: Durch „Connections“!
Denn parallel zu den oben beschriebenen Veränderungen auf dem Content-Markt war eine weitere zu beobachten:die zunehmende Bedeutung von Beziehungen!
Der Aufstieg desSocial Selling und die wachsende Bedeutung von (Corporate) Influencernhaben gezeigt, wie entscheidend „menschliche Verbindungen“ sein können. Erfolg hat zusehends nur, wer echte Verbindungen schafft. Und genau das wollen wir ja: Vertrauen aufbauen, Verbindungen schaffen, Menschen zusammenbringen, um gemeinsam Probleme zu lösen.
Wir sind davon überzeugt, dass das Content-Marketing der Zukunft nicht mehr auf promotetetem Download-Content basieren wird, sondern community-basiert sein muss.Und werden deshalb  unseren Content Hub – die Website mit ihren Landing-Pages – zu einer Content Community um- und ausbauen.
Was das konkret bedeutet?
Wir haben bei „Mighty Networks“ (https://www.mightynetworks.com/) eine Community-Umgebung entwickelt, die wir heute launchen. Sie heisst

## „INVITE - Die KR Community“

Diese Community –invite-only, aber offen und kostenlos für alle Kunden sowie ausgewählte Leads und Partner– beschäftigt sich mit vielen Themen unserer Nische – also der Unternehmenskommunikation – hat dabei aber einen klaren thematischen Fokus, der den nach unserer Kenntnis größten Pain Point unserer Kunden adressiert: die Schaffung von Reichweite und Engagement für die eigenen Content Hubs.
Deshalb haben in dieser neuen Community alle Mitglieder vollen und exklusiven Zugriff auf das Wissen unserer Agentur zu Themen wie z.B.
- Content-Strategie,
- Storytelling-Formate,
- Content Promotion,
- Erfolgsmessung,
- Zielgruppenansprache,
- Community Aufbau,
- digitale Innovationen, z.B. KI und Metaverse.Zu diesen Themen bieten wir ihnen in eine (stetig wachsenden) Bibliothek von
- Whitepapers,
- Checklisten,
- aufgezeichneten Webinaren,
- Studien,
- Cheat Sheets und Quick Start Guides.Hinzu kommen noch
- Newsfeeds mit Links zu aktuellen Informationen, und
- Veranstaltungskalender (einer für interne Kommunikation, einer für Content Marketing).
Aber natürlich geht es um mehr als nur den Zugang zu Informationen. Wir wollen mit der Community einen Raum schaffen, in dem sich dieMitglieder in Diskussionsforen austauschenund direkt mit Kollegen aus anderen Unternehmen und unseren Agentur-Experten interagieren können. Wir wollen nicht nur Wissen teilen, sondern auch Erfahrungen und Perspektiven.
Deshalbstehen unsere Community Manager täglich zu den üblichen Bürozeiten für Fragen und Anregungen zur Verfügung,moderieren Diskussionen und vermitteln im Zweifelsfall Experten,die schnelle Antworten auf Fachfragen haben.
Hinzu kommenregelmäßige Live-Video-Events wie ein wöchentlicher AMA (Ask me anything) Call, Studienpräsentationen oder die Vorstellung von Best Practicesdurch unsere Kreativen.

## Langfristiges Denken

Unser Ziel ist es, in den nächsten 24 Monaten eine lebendige, interaktive Community für Unternehmenskommunikation aufzubauen, die über den reinen Austausch von Inhalten hinausgeht. Es sollein Netzwerk entstehen, in dem jeder Teilnehmer einen Mehrwert findet und bietet– sei es durch das Teilen von Expertise, das Einholen von Feedback oder das Knüpfen von Kontakten. Social Media – insbesondere LinkedIn und Threads – werden wir als Agentur natürlich weiterhin nutzen, um Kontakte zu pflegen und zu knüpfen, zu lernen und zu inspirieren. Aber der Großteil unserer Ressourcen wird von nun an in unsere INVITE Community fließen.
Wir betreten (für uns) Neuland und sind gespannt,welche Wege sich auftun und welche Fehler wir machen werden. Es ist ein spannender Schritt in die Zukunft des Content Marketings und ich freue mich darauf, diese Reise gemeinsam mit unserem Team anzutreten. Ich bin überzeugt, dass diese strategische Neuausrichtung nicht nur unser Content Marketing verändern, sondern auch die Beziehungen zu unseren Kunden, Interessenten und Partnern stärken wird.

# FEEL INVITED

