---
url: https://www.kammannrossi.de/blog/kammann-rossi-fuehrt-das-14-icma-ranking-an
scraped_at: 2026-01-08 18:39
title: Kammann Rossi führt das 14. ICMA-Ranking an!
---

# Kammann Rossi führt das 14. ICMA-Ranking an!


# Kammann Rossi führt das 14. ICMA-Ranking an!

vonCarsten Rossi| 29.02.2024 15:16:35 | 2 Minuten Lesezeit
Wir lieben es, wenn ein Plan funktioniert 🥰 Deshalb freuen wir uns sehr darüber, dass wir beim 14. ICMA Award 🏆 in unserer Kategorie (Custom Media) auf dem ersten Platz gelandet sind.
Der ICMA (International Creative Media Award) ist seit langem eine wichtige Plattform für den Wettstreit um kreative Ideen.
Angesichts von 423 Einreichungen aus 24 Ländern sind wir besonders stolz darauf, die Spitze anzuführen (vor exzellenten Mitbewerbern wie Axel Springer Corporate Solutions oder der Cope Content Performance Group).
Zu den eingereichten Projekten von Kammann Rossi zählen:Customer magazines B2B PrintMarkets International(Silber) für Germany Trade & InvestMarkets Germany(Bronze) für Germany Trade & Invest
Employee media printARAGInSight(Silber)BImAg(Silber) für die Bundesanstalt für ImmobilienaufgabenAnnual ReportsOLB AG Annual Report 2022 (Silber) für die Oldenburgische LandesbankFlix Nachhaltigkeitsbericht2022 (Bronze)Employee Media OnlineECHO!Rewe (Bronze)Corporate film/videoUnboxing the Future(Gold) für EvonikFilm-Triologie: „Ich bin das Klima!“, „Ich bin das Leben!“, „Ich bin die Veränderung!“ von Creavis (Bronze)
ConceptDIE HZ!Barmenia (Silber)Cover and cover storyMarkets International (Gold) für Germany Trade & InvestMarkets International (Bronze)Und besonders stolz sind wir darauf, dass wir über 10 Jahre konstant zu den guten zählten und dieses Jahr dann endlich Platz 1️⃣❤️ erobern konnten.
Detaillierte Ergebnisse und Jury-Bewertungen gibt esauf der Website des Awards.
Foto vonGiorgio TrovatoaufUnsplash
