---
url: https://www.kammannrossi.de/blog/kammann-rossi-und-ki
scraped_at: 2026-01-08 18:39
title: Kammann Rossi und KI: Das Manifest
---

# Kammann Rossi und KI: Das Manifest


# Kammann Rossi und KI: Das Manifest

vonCarsten Rossi| 07.06.2023 11:04:06 | 2 Minuten Lesezeit
Mittlerweile hat wohl jeder mitbekommen: „Künstliche Intelligenz“ ist keine Science-Fiction mehr. Nein, KI, für Agenturen wie uns also vor allem Large Language Models (LLMs) wie ChatGPT und generative grafische KIs wie Midjourney, haben unser Umfeld und  Kammann Rossi schon längst erreicht. Die Zugangsbarrieren sind so gering und die Ergebnisse so überzeugend, dass wir kaum daran vorbeikämen, selbst wenn wir wollten.
Zugegeben, wir haben eine kleine Armee von Redakteuren und Grafikern, die so kompetent sind, dass sie eine Tasse Kaffee in ein literarisches und visuelles Meisterwerk verwandeln können. Und Projektmanager und Berater, die dafür sorgen, dass die Welt das Ergebnis sieht – gedruckt, online oder im Metaverse. Aber seien wir doch ehrlich: Nichts und niemand ist jemals so gut, dass es, er oder sie nicht noch besser werden könnte.Mit Hilfe von KI können sich all diese begabten Menschen von sich ständig wiederholenden manuellen Aufgaben lösen und die gesamte kreative Energie auf die wirklich wichtigen, strategischen Dinge richten. Sie können mehr Ideen in kürzerer Zeit generieren und ausprobieren. Sie können schneller auf die hektischen Anforderungen des Tagesgeschäfts reagieren. Und damit letztlich Kunden glücklicher machen. Large Language Models (LLMs), generative grafische KIs und die gesamte Landschaft von kreativen und automatisieren Tools darum herum können das für uns möglich machen. Und das mit einer wirklich atemberaubenden Geschwindigkeit und Skalierbarkeit bei gleichzeitig beeindruckender Zugänglichkeit.Mit den neuen Werkzeugen können wir unsere Dienstleistungen optimieren, ausweiten und skalieren.
Aber hey, wir sind nicht naiv. So fantastisch diese Technologien auch sind, wir halten es mit Spiderman:Aus großer Kraft folgt große Verantwortung.
Deshalb stellen wir uns Fragen:
- Wie können wir KI ethisch einsetzen?
- Wie schützen wir die Daten unserer Kunden?
- Wie verhindern wir Vorurteile in unseren Algorithmen?
- Wie gewährleisten wir Transparenz?
Und suchen nach aktiven Antworten – jetzt und in Zukunft.
Wir wollen Regeln und Richtlinien schaffen, und sicherstellen, dass jeder in unseren Teams diese Technologien versteht und sie effektiv und verantwortungsbewusst einsetzt. Denn die erste Implementierung von KI-Tools ist schnell und einfach gemacht, aber letztlich doch etwas anderes als das Herunterladen einer App. Es ist ein kontinuierlicher Prozess, der ständiges Monitoring und Anpassungen erfordert. Ganz abgesehen davon, dass nicht nur wir die KI sondern die KI auch uns braucht: Wir müssen ihr richtige Impulse (und Regeln) geben, um die Ergebnisse zu erzielen, die wir uns wünschen. Unsere kreative und gleichzeitig verantwortungsvolle Leistung steht weiterhin im Zentrum.Kurz zusammengefasst: Wir bei Kammann Rossi sind bereit, die neuen Werkzeuge zu nutzen – aber wir tun dies bewusst, mit Verantwortung und einer klaren Vision.
Deshalb haben wir jetzt das5+5 Manifestaufgesetzt und die aus unserer Sicht aktuell wichtigsten Chancen und Verpflichtungen im Hinblick auf die Nutzung von Künstlicher Intelligenz für uns festgehalten.Mit diesem Manifest beginnt unser Weg – und wir freuen uns auf die Reise.
