---
url: https://www.kammannrossi.de/blog/kammann-rossi-und-pagestrip-gehen-neue-wege-im-digital-publishing
scraped_at: 2026-01-08 18:39
title: Kammann Rossi und pagestrip gehen neue Wege im Digital Publishing
---

# Kammann Rossi und pagestrip gehen neue Wege im Digital Publishing


# Kammann Rossi und pagestrip gehen neue Wege im Digital Publishing

vonFlorian Stürmer| 04.02.2024 14:19:00 | 3 Minuten Lesezeit
Dieser Beitrag ist ein Gastbeitrag unseres Software Partnerspagestrip.
Wenn sich eine der ältesten inhabergeführten Agenturen Deutschlands nach gründlicher Marktrecherche auf einen Technologie-Partner festlegt, dann hat das Substanz.
Das Team von pagestrip, Publishing-Software-Startup aus Wien, freut sich über eine solche Entscheidung seitens der Corporate Publishing-Profis von Kammann Rossi. Die Agentur setzt seit einigen Monaten bei ihren Digital Publishing-Aktivitäten aufpagestrip-Softwareund arbeitet daran, dass ihre Kunden von den vielen pagestrip-Vorteilen profitieren.
pagestrip erlaubt es den Kreativen bei Kammann Rossi, sich völlig auf die gestalterischen Aufgaben der digitalen Projekte zu konzentrieren. Dabei sind den Ideen (fast) keine Grenzen gesetzt, sämtliche Inhalte - Text, Grafiken, Fotos und Videos - können in die aktuellsten digitalen Designs dargestellt werden.

# Technisch am neuesten Stand – und trotzdem kein Techniker nötig

Trotz einer technischen “State of the Art”-Umsetzung des Contents ist kein Support eines Technik-Teams notwendig. Die pagestrip-Software hat den digitalen Workflow fest im Griff. “Das macht die Projekte viel schneller und flexibler und natürlich viel günstiger”, sagt Florian Stürmer, Digital Consultant bei KammannRossi. Content, der bereits als Print-Version existiert, kann beispielsweise einfach übernommen werden und mit Links, Videos oder Grafiken veredelt und “digital aufgemöbelt”. Die Corporate Identity des Unternehmens bleibt erhalten.

# Multi-Channel-Publishing mit nur einem Klick

“One-Click-Publishing” ist mit eines der stärksten Features von pagestrip. Content wird mit nur einem Klick auf jedem beliebigen digitalen Kanal veröffentlicht. Darüber hinaus integriert pagestrip problemlos die üblichen Online-Tools, etwa Tracking-Systemen oder Consent-Management-Plattformen. Performance-Messung, Conversion-Tracking oder Suchmaschinen-Optimierung sind mit pagestrip kein Problem.
“Wir waren auf der Suche nach einem Tool, mit dem unsere Designer selbstständig ein Magazin digital publizieren können, ohne dabei technischen Support zu benötigen. Bei unserer Recherche sind wir auf Pagestrip gestoßen. Digital Publishing sei damit so einfach wie ein Youtube-Video hochzuladen, wurde uns versprochen. Und ich muss sagen: diese selbstbewusste Aussage stimmt”, sagt Florian Stürmer, Digital Consultant bei Kammann Rossi. “Wir und unsere Kunden haben den Anspruch, Corporate Design und hervorragende grafische Gestaltung aus der analogen Welt in die digitale zu bringen. Dafür ist pagestrip das perfekte Werkzeug”. Man könne InDesign-Vorlage nutzen, IDML-Assets importieren und für Web gestalten. Schriften und Bilder werden automatisch in eine web-gerechte Form gebracht und konvertiert. Und der WYSIWIG-Editor bedeutet für die Kreativen Spaß bei der Arbeit.
Pagestrip wird von Kammann Rossi vielseitig eingesetzt. Kunden- und Mitarbeitermagazine, Geschäfts- und Nachhaltigkeitsberichte, Landing Pages und Content Hubs - sie alle werden mit dem pagestrip-Editor erstellt. In den vergangenen Monaten wurden bereits Kundenprojekte im zweistelligen Bereich umgesetzt. Eine vollständige Liste der Kunden, die bereits von pagestrip profitiert haben, finden Sie auf der Website vonKammann Rossi.

# Ab jetzt viel mehr pagestrip

Besonders angetan zeigt man sich bei Kammann Rossi vom guten Preis-Leistungs-Verhältnis, welches die pagestrip-Software bietet: “Das macht es uns als Agentur dann einfach, die Kunden von den Vorteilen des Digital Publishing zu überzeugen. Die Lizenzkosten von pagestrip sind moderat. Außerdem ersparen wir uns die Techniker. Dadurch sinken die Digital-Publishing-Grenzkosten für unsere Kunden auf ein Niveau, das Spaß macht”, so Stürmer weiter. Die Summe der Vorteile von pagestrip sei so umfassend, dass man künftig noch stärker die die Technologie des Wiener Unternehmens forcieren werde.
pagestrip verbindet Grafikdesign mit digitalen Medien, ermöglicht die einfache Übertragung von Adobe InDesign-Layouts und optimiert sie für Online-Plattformen. Nutzer von InDesign finden sich schnell zurecht, da pagestrip Layouts und Designs eigenständig und technikfrei für digitale Kanäle anpasst.

# Lassen Sie sich die Vorteile von pagestrip zeigen!


### Jetzt Demo vereinbaren.

- Frau
- Herr
- Neutral/Divers
Die Kammann Rossi GmbH verpflichtet sich, Ihre Privatsphäre zu schützen und zu respektieren. Von Zeit zu Zeit möchten wir Sie über neuen Content oder unsere Service-Angebote informieren. Wenn Sie damit einverstanden sind, dass wir Sie zu diesem Zweck kontaktieren, aktivieren Sie bitte das folgende Kontrollkästchen. Diese Einwilligung kann jederzeit widerrufen werden.
- Ich stimme zu, E-Mail-Mitteilungen von der Kammann Rossi GmbH  zu erhalten.*
Um Ihnen die gewünschten Inhalte bereitzustellen, müssen wir Ihre persönlichen Daten speichern und verarbeiten. Wenn Sie damit einverstanden sind, dass wir Ihre persönlichen Daten für diesen Zweck speichern, aktivieren Sie bitte das folgende Kontrollkästchen.
- Ich habe die Datenschutzerklärung gelesen und stimme der Speicherung und Verarbeitung meiner persönlichen Daten durch die Kammann Rossi GmbH zu.*
Die Speicherung und Verarbeitung Ihrer Daten können Sie jederzeit widerrufen. Weitere Informationen zu unseren Datenschutzverfahren und dazu, wie wir Ihre Privatsphäre schützen und respektieren, finden Sie in unsererDatenschutzerklärung.
