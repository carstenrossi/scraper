---
url: https://www.kammannrossi.de/blog/kammannrossi-pagestrip-cmcx-2024
scraped_at: 2026-01-08 18:39
title: Kammann Rossi und pagestrip auf der CMCX: Agentur-KI trifft Content Management
---

# Kammann Rossi und pagestrip auf der CMCX: Agentur-KI trifft Content Management


# Kammann Rossi und pagestrip auf der CMCX: Agentur-KI trifft Content Management

vonCarsten Rossi| 21.05.2024 17:07:23 | 3 Minuten Lesezeit
Nach einigen Jahren der Abwesenheit sind wir von Kammann Rossi stolz, in diesem Jahr endlich wieder als Aussteller auf der CMCX vertreten zu sein! Gemeinsam mit unseremSoftware-Partner pagestripfreuen wir uns, am 11. und 12. Juni 2024 im Mülheimer Hafen in Köln dabei zu sein.Die CMCX ist für uns nicht nur eine großartige Gelegenheit, unsere Expertise im Content Marketing zu präsentieren, sondern auch eine Plattform, um alte Bekannte zu treffen und neue Kontakte zu knüpfen.

# Warum wir uns auf die CMCX 2024 freuen

Die CMCX ist das beste Content Marketing Event, um sich zwei Tage lang sowohl mit Kreativität als auch mit Technologie zu beschäftigen. Es ist die perfekte Gelegenheit, um voneinander zu lernen, zu netzwerken und die neuesten Trends in einer inspirierenden Umgebung zu entdecken. Mit über 60 Expert:innen auf vier Bühnen bietet die CMCX strategische Einblicke und konkrete Handlungsempfehlungen zu den wichtigsten Themen unserer Branche: Content-Marketing, MarTech und KI, B2B-Marketing, Social Media und Influencer Marketing sowie Marketing Operations.
Wir freuen uns darauf, nicht nur unsere eigene Expertise zu teilen, sondern auch von den neuesten Entwicklungen zu lernen, die auf der CMCX vorgestellt werden. Besonders spannend ist für uns die Möglichkeit, viele bekannte Gesichter wiederzusehen und gleichzeitig neue, interessante Kontakte zu knüpfen.

# Unsere Partnerschaft mit pagestrip

Ein besonderes Highlight in diesem Jahr ist unsere Zusammenarbeit mit pagestrip. Pagestrip ist eine innovative Content-Management-Plattform, die es uns ermöglicht, über traditionelle Formate hinauszugehen und maßgeschneiderte Lösungen zu entwickeln, die genau auf die Bedürfnisse der Zielgruppen unserer Kunden zugeschnitten sind. Mit pagestrip können wir Inhalte mit außergewöhnlicher Kreativität und Präzision inszenieren, um den größtmöglichen Impact für unsere Kunden zu erzielen.
Im Rahmen unserer Partnerschaft werden wir gemeinsam unsere Stärken in den Bereichen Content Marketing und digitales Storytelling präsentieren. Pagestrip gibt uns die Freiheit, jenseits von Standard-Templates und schematischen Landing-Pages zu arbeiten und stattdessen einzigartige, ansprechende Formate zu erstellen, die überzeugen und begeistern.

# Unser Vortrag: Effizienz trifft Exzellenz

Ein weiteres Highlight unseres Auftritts auf der CMCX ist unser gemeinsamer Vortrag mit pagestrip. Unter dem Titel "Effizienz trifft Exzellenz: Wie Du mit KI, pagestrip und einer guten Agentur in 15 Minuten einen Lead-Magneten online bringst" geben wir Einblicke in die effiziente Nutzung von KI im Content Marketing.
In unserer Live-Demo zeigen wir, wie man mit Hilfe der KR-eigenen KI-Plattform „AssistantOS“ in kürzester Zeit aus einem einfachen Sachtext ein zielgruppengerechtes Format für eine Landing-Page generiert. Anschließend demonstrieren wir, wie diese Landing-Page mit pagestrip in wenigen Minuten „on brand“ in eine bestehende Website integriert wird. Das Ziel: Inhalte, die nicht nur überzeugen und begeistern, sondern auch verkaufen.
Unsere Sprecher sind keine Unbekannten in der Branche:

# Wir sehen uns auf der CMCX!

Die CMCX 2024 wird ein aufregendes Event, und wir freuen uns, endlich wieder Teil dieser dynamischen und inspirierenden Community zu sein. Besuchen Sie unseren Stand, nehmen Sie an unserem Vortrag teil und lassen Sie uns gemeinsam die Zukunft des Content Marketings gestalten. Wir können es kaum erwarten, Sie dort zu sehen! Rest-Tickets gibt es nochhier.
