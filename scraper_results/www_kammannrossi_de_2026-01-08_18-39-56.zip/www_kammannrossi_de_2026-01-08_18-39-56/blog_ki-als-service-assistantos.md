---
url: https://www.kammannrossi.de/blog/ki-als-service-assistantos
scraped_at: 2026-01-08 18:39
title: KI als Service: Wie AssistantOS unsere Kunden (und uns) stärkt
---

# KI als Service: Wie AssistantOS unsere Kunden (und uns) stärkt


# KI als Service: Wie AssistantOS unsere Kunden (und uns) stärkt

vonCarsten Rossi| 22.08.2024 14:07:30 | 4 Minuten Lesezeit
Seit 25 Jahren leite ich Agenturen. In dieser Zeit habe ich viele Krisen miterlebt – von der New Economy zur Pandemie. Doch KI toppt alles. Sie verändert unsere Arbeit und die der Kunden fundamental.Deshalb reagieren wir proaktiv und präsentieren ein neues Dienstleistungsmodell..
Es begann mit einer Selbsterkenntnis: Uns wurde schnell klar, dass unser traditionelles Wertschöpfungsmodell, das größtenteils auf manueller Kreation und Produktion basiert, durch inabsehbarer Zeitineffizient wird. Viele unserer bisherigen Dienstleistungen – sei es das Texten, Gestalten oder Produzieren – müssen künftig nicht nurschneller und kostengünstigererbracht werden, sondern können mit Hilfe von KI sogar direkt bei unseren Kunden inhouse  umgesetzt werden. Um es auf den Punkt zu bringen:Unser bisheriges Geschäftsmodell wird nicht mehr lange funktionieren. Es wird bald schwer sein, mit „business as usual“ Geld zu verdienen.

#### Herausforderungen auch für Unternehmen

Aber auch viele unserer Kunden aus der Kommunikation stehen vor Herausforderungen: Sie wissen, dass sie KI nutzen müssen, um agil zu bleiben (und manchmal zu werden). Aberes fehlt an Orientierung. Das liegt sicher am Markt. Die Entwicklungen überschlagen sich förmlich.Jeder Tag bringt ein neues Modell,bringt 20 neue Tools und 50 angebliche Best Practices. Dazu kommen noch fehlendes technisches oderPrompt-Engineering-Know-howim Team, die nötigen Anpassungen der Prozesse und dieFrage nach derrichtigen Balancezwischen KI und menschlicher Kreativität und Authentizität.Unternehmen brauchen einerseits die richtige Technologie, andererseits aber auchOrientierung und „Enabling“.
Und an genau dieser Schnittstelle liegt dieChance für beideSeitender Dienstleistungsmedaille.

#### „Service as a Software“: Die KR Vision für den Weg mit KI

Denn natürlich haben wir uns – anders als die meisten unserer Kunden – aus purem Selbsterhaltungstrieb sehr früh, intensiv und mehtodisch mit KI und LLMs beschäftigt – und tun das bis heute jeden Tag. Wir mussten den „Feind“ ja kennen, um ihn uns zum Freund zu machen. Wir sind Prompt Engineers geworden, Betatester, Plattformnutzer, KI Trainer und vieles mehr. Und das nehmen wir nun mit zu unseren Kunden, auf Basis einer einfachen Idee:wir befähigen sie, die Vorteile von KI professionell zu nutzen – auf Basis unserer eigenen KI Plattform. Unsere Plattform heisstAssistantOSund das neue Dienstleistungsmodell nennt sichService as a Software. Und sieht konkret so aus:
- Eine Plattform als Basis:An unsere Kunden lizenzieren wir spezialisierte KI-Assistenten auf einer von uns bereitgestellten technischen Plattform. In diesen Assistenten stecken unser gesamtes Know How und unsere Erfahrung als Dienstleister. Sie bilden nahezu alle Use Cases der Unternehmenskommunikation ab. Von der Erstellung von Content-Kampagnen über Podcast-Skripte oder Intranet-News bis hin zu Strategieberatung oder virtuellen Fokusgruppen.
- Anpassung & Training:Wir passen diese KI-Assistenten an die spezifischen Bedürfnisse und CI-Richtlinien jedes Kunden an. So entstehen keine generischen Inhalte, sondern markenkonformer, hochwertiger Content.
- Beratung & Schulung:Wir bilden die Teams unserer Kunden im Umgang mit KI aus und entwickeln gemeinsam neue Use Cases und Assistenten.
- Kontinuierliche Optimierung:Wir behalten den KI-Markt im Blick und integrieren stets die neuesten Modelle und Technologien in AssistantOS.
- Hybrides Arbeitsmodell:In Projekten nutzen wir AssistantOS gemeinsam mit unseren Kunden. Mal liefern wir den kreativen Input, den der Kunde selbst umsetzt, mal setzen wir komplexere Aufgaben um. Und wenn das Projekt vorbei ist, integrieren wir das neue Wissen in neue Assistenten.
- Menschliche Kreativität:Wir sagen klar, wenn KI an ihre Grenzen stößt und klassische Kreation gefragt ist - die wir natürlich weiterhin anbieten.
Unser AssistantOS Pitch als Video.

#### Vorteile für beide Seiten

Das neue Modell bietet unserer Meinung nach große Chancen für alle Beteiligen.
Unseren Kunden ermöglichen wir
- Effizienzsteigerung und mehr Kreativitätin der Tagesarbeit
- Zugang zuState-of-the-Art KI-Technologieohne eigene Entwicklungskosten
- Nutzung unseresAgentur-Know-howson demand
- Flexibilitätzwischen Selbstständigkeit und Full-Service
Dieser Ansatz erweist sich für Kunden übrigens auch in "klassischen" Projekten als sehr vorteilhaft. Häufig starten diese Projekte ja mit handwerklicher Kampagnen-Kreativität und/oder  einer Strategie und das soll auch so bleiben. Aber bisher endete das Projekt dann oft mit der Übergabe eines Konzepts, einiger Beispielmaterialien oder eines Strategie-Dokuments. Jetzt können diese Ergebnisse aber vielkonsequenter und kontinuierlicher als bisher operationalisiertwerden. Denn wir übersetzen die Ergebnisse unserer Konzeptphase direkt in maßgeschneiderte KI-Assistenten (z.B. für Text- oder Bildformate), die das Team des Kunden dann bei der täglichen Umsetzung unterstützen. So ist sichergestellt, dass die sorgfältig entwickeltenKonzepte nicht in der Schublade verschwinden, wenn wir es tun.
Und für uns als Agentur?
Besteht die Möglichkeit, unser einzigartiges Wissen und unsere Kreativität zum Produkt zu machen, das lizenzierbar und damit auch skalierbar ist. Dies eröffnet uns völligneue Geschäftsmodelle und Einnahmequellen, die uns unabhängiger von der reinen manuellen Produktion machen und es uns ermöglichen, die anstehenden Einnahmeverluste auszugleichen.
Assistants für jeden Use Case.
Ich bin davon überzeugt, dass „Service by a Software“ ein echtes Win-Win-Modell ist.Es ermöglicht unseren Kunden, die Effizienz und Qualität ihrer Kommunikationsprozesse zu steigern, während wir als Agentur neue Umsätze erschließen und unser Geschäftsmodell zukunftssicher machen.Wenn das klappt, können wir die Zukunft der Kommunikation weiterhin gemeinsam gestalten – als Agenturen und Kunden im Verbund, wenn auch nach veränderten Regeln.
Einfach klicken und einen Demo-Termin mit mir vereinbaren.
