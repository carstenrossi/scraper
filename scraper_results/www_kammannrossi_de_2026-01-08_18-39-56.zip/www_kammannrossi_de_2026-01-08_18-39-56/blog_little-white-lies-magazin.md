---
url: https://www.kammannrossi.de/blog/little-white-lies-magazin
scraped_at: 2026-01-08 18:39
title: Lieblings-Magazine #1: Little White Lies
---

# Lieblings-Magazine #1: Little White Lies


# Lieblings-Magazine #1: Little White Lies

vonVerena Matl| 06.11.2019 14:39:16 | 2 Minuten Lesezeit
In loser Folge verraten die Kollegen von Kammann Rossi welche Magazine ihnen besonders gut gefallen. Diesmal:Verena Matl, Design
Little White Lies – Truth & Movies:Vor ungefähr zehn Jahren ist mir dieses Magazin zum ersten Mal begegnet. Ich hatte gerade mein Studium beendet und arbeitete als Freelancerin, als ich überissuu.comauf Little White Lies gestoßen bin. Es war eine der ersten Ausgaben, an dessen Cover ich mich noch gut erinnern kann (Little White Lies 05 – The Romance & Cigarettes Issue).
Gestaltet und herausgegeben wird das Kultur- und Filmmagazin vonThe Church of London (TCOLondon),einem britischen Medienunternehmen und Kreativstudio. In jeder Ausgabe geht es um Filme und Filmkritiken und es gibt Interviews mit Regisseuren und Hauptdarstellern. Es erscheint alle zwei Monate.
Das Besondere an dem Magazin ist, dass das Design jeder Ausgabe anders ist. Inspiriert jeweils von einem aktuellen Kinofilm, von welchem meist dessen Hauptdarsteller oder Hauptdarstellerin in einem immer anderen illustrativen Stil auf dem Cover abgebildet ist. Ob Zeichnung, Linolschnitt, Collage oder Comic, Retro, modern, grafisch oder künstlerisch, bunt oder schwarz-weiß – der Stil ist immer anders, immer neu, und damit auch immer wieder aufs Neue spannend.
Und: Das Design des ganzen Magazins wird vom Hauptfilm beeinflusst. Farbgebung, Schriftart, Kapitelüberschriften, redaktionelle Symbole und Icons variieren in Abhängigkeit von der Thematik des Films. Der grundlegende Aufbau der Zeitschrift ist hingegen immer konstant. Der vordere Teil des Magazins widmet sich ganz dem Hauptfilm, seiner Rezension und greift von ihm inspirierte Themen auf.
Im hinteren Bereich findet man zahlreiche Rezensionen der neuesten Filmveröffentlichungen, Interviews und Ausblicke auf Filmneustarts. Für die Filmrezensionen nutzt Little White Lies ein dreiteiliges Bewertungssystem: Die Kategorien „Anticipation“ (Erwartung), „Enjoyment“ (Genuss) und „In Retrospect“ (rückblickend) werden jeweils mit bis zu fünf Punkten versehen und durch einen kurzen Fließtext ergänzt. So werden verschiedenste Aspekte des Filmerlebnisses erfasst. „Truth and Movies“ – Wahrheit und Filme, lautet der Coverclaim. Der gleichnamige wöchentliche Podcast soll dem Filmfan helfen, weitere großartige Filme zu entdecken.
Bis heute sind81 Issueserschienen. Little White Lies kombiniert auf 108 Seiten modernes redaktionelles und grafisches Design mit Illustration und Journalismus auf abwechslungsreiche Art und Weise. Es informiert und unterhält den Leser rund um das Thema Film. Gleichzeitig inspiriert jede Ausgabe dazu, die Dinge einfach mal wieder ganz anders zu machen. Denn die Wahrheit ist doch, dass wir nicht immer das Gleiche sehen wollen. Wir mögen die Abwechslung, das Andere, das Neue. Wir müssen uns von Zeit zu Zeit einfach mal wieder neu erfinden. Das ist die Wahrheit. Und Design.
