---
url: https://www.kammannrossi.de/blog/magazin-vom-lagerhaus-zum-lesestoff
scraped_at: 2026-01-08 18:39
title: Magazin: Vom Lagerhaus zum Lesestoff
---

# Magazin: Vom Lagerhaus zum Lesestoff


# Magazin: Vom Lagerhaus zum Lesestoff

vonDr. Christian Fill| 14.05.2025 10:58:33 | 3 Minuten Lesezeit
Ein Knirps, das war ich, vielleicht acht oder neun Jahre alt, des Lesens schon mächtig, das Verstehen hinkte hinterher. Jeden Sonntag freute ich mich auf ein besonderes Vergnügen, den Besuch bei meinen Großeltern, weniger, weil dort Süßigkeiten bereitstanden. Vielmehr freute ich mich auf einen hohen Stapel, der auf mich wartete. Heft auf Heft lagen sie da: Stern, Spiegel und Bunte, die schillernde Quick oder die verruchte Neue Revue, eingehüllt im kartonstarken, grünen Schutzcover. Lesestoff, den meine Großeltern über den Lesezirkel bezogen.Was mich damals packte, ließ mich mein Leben lang nicht mehr los: eine Faszination für Zeitschriften, Illustrierte und – Magazine.

## Aus Arabien um die Welt

Doch was bedeutet eigentlich das Wort Magazin, das wir so selbstverständlich in der Medienlandschaft nutzen? Woher kommt es? Welche Bedeutung hat es? Schließlich gilt schon lange nicht mehr, dass ein Magazin ausschließlich ein Printprodukt ist – viele digitale Magazine haben sich im Internet durchgesetzt, sind zum Maßstab für ihre gedruckten Vorgänger geworden.
Der geläufige Ausdruck hat weit zurückreichende Wurzeln: Er leitet sich vom arabischen Wort„makhazin“ab, das „Lager“ oder „Lagerhaus“ bedeutet. Im späten 16. Jahrhundert fand dieser Begriff Eingang ins Französische als „magasin“ und behielt seine ursprüngliche Bedeutung als Lager- oder Warenhaus bei.Die Verbindung zur heutigen Bedeutung entstand erst im 18. Jahrhundert, mit einer europaweit erstarkenden Buch- und Druckkultur, als Verleger begannen, periodische Sammlungen verschiedener Texte, Nachrichten, Geschichten und Illustrationen zu veröffentlichen – quasi ein „Lager“ des Wissens und der Unterhaltung, bald in bewusster Abgrenzung zu Büchern.Die erste dokumentierte Veröffentlichung, die sich selbst als Magazin bezeichnete, war das„Gentleman's Magazine“, das 1731 in London ins Leben gerufen wurde. Diese Publikation enthielt eine bunte Mischung an Essays, Gedichten, Satiren, Berichten und Nachrichten. Ein Konzept, das die Grundlage für die moderne Magazinkultur legte, und – Magazinmacher, Hand aufs Herz! – sich bis heute gehalten hat.

## Technik macht Medien

Gut hundert Jahre später ermöglichten die nächsten Technologieschübe einschneidende Entwicklungen in der Medienlandschaft. Die Fortschritte der Drucktechnik, etwa durch die Schnellpresse, oder die Erfindung der Autotypie, eines chemischen Reproduktionsverfahrens, ermöglichten es, Bilder in größeren Mengen und zu geringeren Kosten zu drucken.Eine Magazin-Variante wurde geboren: die„Illustrierte“, die mit vielen Bildern ihre Leser informierte und unterhielt. Ab 1842 erschien ein weiterer Meilenstein der Mediengeschichte, wieder in Großbritannien: die „Illustrated London News“. Diese diente als Vorbild, etwa für die Leipziger „Illustrirte Zeitung“ und die Pariser „L’Illustration“, deren Erstausgaben nur ein Jahr später erschienen.

## Der Umbruch ist nicht vorbei

Machen wir einen Zeitsprung – über den Massenmarkt hinweg, der sich rasend schnell rund um Magazine und Illustrierte entwickelte; überspringen wir Aufstieg und Fall großer Verlagshäuser; lassen wir Radio und Fernsehen außer Acht, weil sie entgegen allen dunklen Prophezeiungen nicht den Printmedien den Tod brachten.Allerdings, wer heute als Redakteur oder Designer arbeitet, erlebt den größten und immer noch andauernden Umbruch einer Mediengattung. Mit dem weltweiten Siegeszug des Internets ab Mitte der 1990er-Jahre erlebten Magazine und Illustrierte ihre bis dato tiefgreifendste Transformation.Und sie erleben sie immer noch: Online-Magazine und digitale Ausgaben traditioneller Printtitel haben längst die Jahrhunderte alte Hierarchie gekippt und geben den Ton an. Vor allem dann, wenn sie geschickt die digitalen Möglichkeiten zur Darstellung und Interaktion nutzen. So bereichern multimediale Inhalte wie Videos und interaktive Grafiken, ja ganze Podcasts, längst das Leseerlebnis.Verbunden damit sind, natürlich, große Herausforderungen – etwa die Monetarisierung der digitalen Magazinwelten, die Transformation tradierter Geschäftsmodelle, und der verantwortungsvolle Umgang mit der Aufmerksamkeitsspanne der Leser.Apropos Verantwortung: Spätestens mit Donald Trumps zweiter Präsidentschaft und dank der schillernden Möglichkeiten von Künstlicher Intelligenz, zeigt sich, wie wichtig hochwertige und gut recherchierte Inhalte sind, die, auf ihre Authentizität und ihre Richtigkeit geprüft, Einordnung und Halt geben können – ja sogar geben müssen.

## Blick zurück

Vier Jahrzehnte oder mehr bin ich entfernt von dem magazinbegeisterten Pimpf, der ich damals war. Ich habe für Magazine am Kiosk gearbeitet, ich habe die Anfänge digitaler Magazine erlebt und mitgestaltet, ich durfte Magazine für zahlreiche Kunden aus einer bunten Vielzahl an Branchen entwickeln.Ich kann nicht sagen, dass dieser Job auch nur irgendetwas von seiner Faszination eingebüßt hat. Folgerichtig, dass ich heute bei jener Agentur arbeiten darf, die sich dies hier auf die Fahnen geschrieben hat: #WeLoveMags.
