---
url: https://www.kammannrossi.de/blog/more-reality-das-metaverse-bei-kammann-rossi
scraped_at: 2026-01-08 18:39
title: More Reality - Kammann Rossi launcht 2023 neues Metaverse Portfolio
---

# More Reality - Kammann Rossi launcht 2023 neues Metaverse Portfolio


# More Reality - Kammann Rossi launcht 2023 neues Metaverse Portfolio

vonCarsten Rossi| 29.11.2022 16:50:57 | 3 Minuten Lesezeit
Das Jahr 2022 war für alle, die sich mit dem "Metaverse" beschäftigen, ein besonderes. In kürzester Zeit wurde "das Metaversum" zum Trendthema, Hype-Verdächtigen und Stolperstein zugleich. Kammann Rossi war mittendrin - und wird 2023 ein vollständiges Metaverse-Portfolio launchen.
Was für ein aufregendes Metaverse-Jahr das für uns bei KR war, merkt man eigentlich erst beim Blick zurück. Aus einer alten Leidenschaft für VR und AR wurde in wenigen Monaten ein ernsthaftes Geschäftsfeld.
- Januar 22:Kammann Rossi nutzt zum ersten Mal dreidimensionale und immersive Technologien, um einen neuen Markenauftritt für einen B2B Kunden zu entwickeln.
- Februar 2022:Kammann Rossi ist Gründungsmitglied des neugeschaffenenRessorts Metaverse im Bundesverband der Digitalen Wirtschaft(BVDW).Weitere Unternehmen, die zur Gründung mit dabei sind, sind u.a. Google, Meta, Telekom, Ströer, Digitas Pixelpark.
- April 2022:Unser Geschäftsführer Carsten Rossi wird Leiter des Labs "Society" im Ressort Metaverse des BVDW.
- Juni 2022:Kammann Rossi wird Mitglied imMetaverse Standards Forum.
- Juli 22022:Carsten Rossi wird von Thomas Riedel in seinemMetaverse Podcastinterviewt
- August 2022:Carsten Rossi veröffentlicht einen Kommentar in der Internetworld. Die wenig dezente Überschrift 😉: "Das Metaverse ist ein Knaller"
- September 2022:Carsten Rossi spricht im Podcast "Social Media Schnack" etwas dezenter zum Thema "Aufbruch in eine neue Welt ... oder doch nicht?"
- September:Carsten Rossi tritt mit Kolleg*innen auf der dmexco auf unter dem Titel "Welcome to the Metaverse 2022: Navigating the unknown"
- September 2022:Kammann Rossi präsentiert auf den Inkometa Days zum Thema "Metaverse in der IK – Was können wir damit anfangen und wie?"
- Oktober 2022:Carsten Rossi startet seinen Podcast "Das Metaverse in drei Minuten".
- November 2022:Kammann Rossi entwickelt einen immersiven Showroom für einen Technologiekunden
- November 2022:Kammann Rossi startet eine "Lernreise Metaverse" zusammen mit Kongress Media
- November 2022:Die Kammann Rossi Metaverse Academy aufSpatialgeht live.
- Dezember 2022:Kammann Rossi unterstützt Deutschland größten Metaverse SummitNTR.land. Carsten Rossi ist dort als Keynote Speaker und Moderator vertreten.

#### "MORE REALITY" - Unsere Services für die Metaverse Economy

Was wir 2022 - im Jahr unseres 50. Jubiläums - angeschoben haben, wollen wir 2023 nun endlich für all unsere Kund*innen produktiv nutzbar machen. Deshalb werden wir eine neue Produktlinie launchen, mit standardisierten, aber natürlich adaptierbaren, Lösungen für dieInterne Kommunikationund dasContent Marketing.
Unter dem Label "More Reality" bieten wir ab Q1 2023 folgende Services an.
1) "More RealityIC" - Das Metaverse in der Internen Kommunikation
- "Metaverse Editorials", Erweiterung von gedruckten und digitalen Mitarbeitermagazinen per Augmented Reality und Virtual Reality
- Immersive Meetings und VR-Events, z.B. für Change Kommunikation, Townhalls, Q&As, Workshops etc
- Immersives Recruitingund Onboarding
- Immersiv gestaltete Foyers, Ausstellungen, Messen und Jubiläen per VR und AR
2) "More RealityCM" - Das Metaverse im Content Marketing
- "Metaverse Editorials",Erweiterung von gedruckten und digitalen Content Hubsper Augmented Reality und Virtual Reality
- ImmersiveProdukt-, Marken- und Servicepräsentationen(Showrooms, Virtuelle Touren, Demos, Insides, Experiences, Walkabouts)
- Storytelling-Beratungund Konzeption für redaktionelle Metaverse-Produktionen
- NFT-Servicesfür PR und Marketing (ETH- bzw. PoS-Blockchains only)
Was genau sich hinter den einzelnen Angeboten verbirgt, werden wir während einer Launch-Veranstaltung im 1. Quartal noch genauer erläutern. Auch diese werden wir hie im Blog ankündigen und natürlich all unsere Kund*innen und Abonnent*innen noch einmal gesondert einladen. Bis dahin können Sie sich gernehieroder mit Hilfe unseres60-Minuten Workshopsgerne einmal einen Überblick über das Thema verschaffen
