---
url: https://www.kammannrossi.de/blog/pitch-kodex
scraped_at: 2026-01-08 18:39
title: Pitch-Kodex für Reporting-Agenturen setzt neue Ausschreibungs-Standards
---

# Pitch-Kodex für Reporting-Agenturen setzt neue Ausschreibungs-Standards


# Pitch-Kodex für Reporting-Agenturen setzt neue Ausschreibungs-Standards

vonAnn Bönsch| 14.06.2018 15:10:07 | 1 Minute Lesezeit
Gemeinsam mit anderen führenden Reporting-Agenturen hat Kammann Rossi die „Pitch Kodex Initiative“ erarbeitet und unterzeichnet. Ziel der Initiative ist die Einhaltung bestimmter Standards bei Ausschreibungen, sogenannten „Pitches“.
Schon lange gibt es Redebedarf im Hinblick auf die gängigen Praktiken beiAgentur-Pitches. Natürlich steht bei einer Ausschreibung immer ein spezifisches Projekt im Vordergrund – aber für die teilnehmenden Agenturen geht es nicht nur darum, ein einzigartiges, kreatives Konzept zu entwickeln, sondern vor allem, sich als geeigneten Partner zu präsentieren, der Strategie, reibungslose Umsetzung und vertrauensvolle Zusammenarbeit bieten kann.Das geht natürlich nur, wenn ein paar Grundvoraussetzungen gegeben sind.
Und genau aus diesem Grund kam es im September 2017 bei einem Roundtable mehrerer Reporting-Agenturen zu der Idee, eine Art „Pitch-Knigge“ aufzusetzen mit dem Ziel, den Ausschreibungs-Prozess sowohl für Unternehmen, als auch für Agenturen reibungsloser zu gestalten. Aus diesem Grund werden im Pitch-Kodex die Aspekte Briefing, Umfang, Ansprechpartner, Transparenz und Fairness, Zeitfenster, Präsentation und Geistiges Eigentum aufgeführt und dargelegt, wie diese am besten ausgestaltet werden sollten.
> Was uns antreibt ist die Überzeugung, dass ein fairer, transparenter Wettbewerb der Agenturen bessere Konzepte und Lösungen erzeugt.

### Was uns antreibt ist die Überzeugung, dass ein fairer, transparenter Wettbewerb der Agenturen bessere Konzepte und Lösungen erzeugt.

Ziel der Initiative ist es, weitere Agenturen für diese Idee zu gewinnen und den Kodex gemeinsam weiter zu entwickeln. Am Ende soll eine Art Checkliste entstehen, die den Ausschreibungs-Prozess für Unternehmen und Agenturen optimiert, so dass die Voraussetzungen gegeben sind, gemeinsam einzigartige Projekte zu entwickeln.
Weitere Informationen zu den teilnehmenden Agenturen und den genauen Inhalten des Pitch-Kodex finden Siehier.Außerdem haben wir einen kleinenBlogbeitragmit den meistbegangenen Fehlern bei Ausschreibungen verfasst und wie man diese verhindern kann.
Selbstverständlich bleibt ein Pitch immer eine Herausforderung. Kammann Rossi hat darum noch einen Schritt weiter gedacht – herausgekommen ist das „360-Grad-Test-Abo“. Unternehmen haben so die Möglichkeit, die Agentur unverbindlich zu testen und kennenzulernen, ohne den langwierigen Ausschreibungsprozess auf sich zu nehmen. Wie das Ganze funktioniert, können Sie aufdieser Seitenachlesen.
