---
url: https://www.kammannrossi.de/blog/schuelerpraktikantinnen-als-magazinmacherinnen
scraped_at: 2026-01-08 18:39
title: Schülerpraktikantinnen als Magazinmacherinnen bei Kammann Rossi
---

# Schülerpraktikantinnen als Magazinmacherinnen bei Kammann Rossi


# Schülerpraktikantinnen als Magazinmacherinnen bei Kammann Rossi

vonJürgen Jehle| 17.02.2025 09:22:35 | 2 Minuten Lesezeit
Bei Kammann Rossi erleben Schülerpraktikant:innen die Welt des Magazinmachens hautnah. Mit einem eigenen Minimagazin-Projekt, der Teilnahme an Redaktionsmeetings und kreativer Freiheit darf sich der Nachwuchs von morgen alljährlich bei uns ausprobieren.

#### Print ist tot? Von wegen!

Zumindest ist Print eine hervorragende Möglichkeit, sich bei KR während der Schülerpraktikumswochen in NRW zu Beginn jedes Jahres auszuprobieren und kreativ zu werden. Wir nehmen Nachwuchsförderung ernst – sehr ernst sogar. Und statt Kaffee zu kochen oder das Magazinarchiv aufzuräumen, bekommen unsere Schülerpraktikant:innen die Chance, von Tag eins an in die Welt des Publishings einzutauchen. Denn auch das bedeutet für uns#welovemags: Nachwuchskräften die Kunst des Magazinmachens näherzubringen:
„Am Anfang war ich überrascht, wie viel Verantwortung ich gleich bekommen habe“, erinnert sich Elli Ehlert. Sie absolvierte im Januar 2024 ein 14-tägiges Schülerpraktikum bei uns. „Ich dachte, ich würde hauptsächlich zusehen, aber stattdessen durfte ich direkt mitmachen.“
Unser Ansatz? Wir geben den jungen Talenten ein eigenes „Minimagazin“-Projekt an die Hand. Von der Konzeption über das Layout bis hin zum fertigen Minimagazin – im Schnelldurchlauf erkunden sie die Stationen der Magazinproduktion. Dabei stehen ihnen Kolleginnen und Kollegen bei KR mit Rat und Tat zur Seite.

#### Magazin machen statt Archiv aufräumen

Vom 27. Januar bis 7. Februar war auch die 16-jährige Prisca Knipping in der Agentur für ein zweiwöchiges Schülerpraktikum. „Es war manchmal ganz schön herausfordernd“, gibt Prisca zu. „Aber genau das hat es so spannend gemacht. Ich hätte nie gedacht, dass ich in zwei Wochen so viel über Magazingestaltung lernen kann.“
Doch nicht nur das eigene Projekt steht auf dem Programm. Unsere Praktikant:innen nehmen auch an Teamsitzungen und Redaktionskonferenzen teil – manchmal sogar bei unseren Kunden. Dafür sind wir besonders dankbar, denn diese Einblicke sind unbezahlbar für den Nachwuchs.
„Die Teilnahme an einer echten Redaktionssitzung war für mich ein echtes Highlight", sagt Elli. „Zu sehen, wie Profis an einem Magazin arbeiten, hat mir geholfen, mein eigenes Projekt besser zu verstehen.“
Dass unser Ansatz nicht alltäglich ist, zeigen die oft überraschten Reaktionen der Klassenlehrer:innen: Sie sind erstaunt, wie selbstständig die Schüler hier arbeiten dürfen. Aber genau das ist es, was wir erreichen wollen: echte Praxiserfahrung.

#### Praktikum mit Goldrand

Und manchmal zahlt sich diese Erfahrung sogar in Gold aus – im wahrsten Sinne des Wortes. Ellis Praktikumsmagazin „Elli-Plus" wurde bei denFOX AWARDSmit Gold und bei denICMA Awardsmit Silber ausgezeichnet. Eine Leistung, die zeigt, dass Nachwuchsförderung und Qualität Hand in Hand gehen können. „Als ich von den Auszeichnungen erfuhr, konnte ich es kaum glauben", erinnert sich Elli. „Es war eine tolle Bestätigung für die harte Arbeit und hat mir gezeigt, dass ich auf dem richtigen Weg bin.“
Ein besonderes Highlight für Prisca war, dass sie Elli für ihr eigenes Magazin interviewen durfte. Diese Aufgabe war Teil ihres Praktikumsprojekts und bot nicht nur einen spannenden Einblick in Ellis Erfahrungen, sondern auch die Möglichkeit, journalistische Fähigkeiten in der Praxis zu erproben. Doch bei allem Erfolg – was bleibt am Ende eines solchen Praktikums? Für Prisca ist es klar: „Ich habe nicht nur gelernt, wie man ein Magazin macht. Ich habe auch viel über mich selbst und meine Fähigkeiten gelernt.“Erfahren Sie einen tieferen Einblick in den Alltag der Schülerpraktikant:innen bei Kammann Rossi.Das ganze Interview, das Prisca mit Elli geführt hat, lesen Sie hier.
