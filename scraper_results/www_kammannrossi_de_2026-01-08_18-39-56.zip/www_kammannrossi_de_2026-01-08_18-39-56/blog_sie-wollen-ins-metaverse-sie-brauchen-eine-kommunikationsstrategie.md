---
url: https://www.kammannrossi.de/blog/sie-wollen-ins-metaverse-sie-brauchen-eine-kommunikationsstrategie
scraped_at: 2026-01-08 18:39
title: Auch Metaverse-Projekte brauchen eine Kommunikationsstrategie!
---

# Auch Metaverse-Projekte brauchen eine Kommunikationsstrategie!


# Auch Metaverse-Projekte brauchen eine Kommunikationsstrategie!

vonCarsten Rossi| 14.03.2023 12:00:00 | 4 Minuten Lesezeit
Viele Unternehmen arbeiten zur Zeit an „Metaverse“-Pilotprojekten (*). Wenn diese Erfolg haben sollen, müssen sie wie jedes andere Unternehmensprojekt von strategisch geplanter Unternehmenskommunikation begleitet werden.Egal, was sie zur Zeit planen -einen immersiven Showroom, eine NFT-Kampagne, ein virtuelles Kunden-oder Mitarbeiter-Event oder eine Social-VR-basierte Markenwelt- eines ist sicher: in den meisten Fällen sind diese Projekte keine Selbstläufer. Die Zielgruppen sind im allgemeinen klein, die technischen Hürden für Mitarbeiter und Nutzer vergleichsweise hoch und das Misstrauen bzw. die Veränderungsresistenz vieler Menschen ist groß. Die Chancen stehen also gut, dass das Projekt - wenn sie nicht gerade eine Lovebrand oder ein Technologie-Unternehmen im Fokus des Marktes sind - floppt bzw. seineZiele nichterreicht.
// English version of this blogpost //
Häufig wird das dann aufs „Metaverse“, die fehlende Reife der Technologie oder des Marktes geschoben. In vielen Fällen jedoch ist es einfach nurdas Ergebnis mangelnder oder schlechter Kommunikation. Denn häufig werden die Projekte von kleinen isolierten Gruppen von "Aficionados" durchgeführt, die zwar guten Willens aber ohne jedes Kommunikations-KnowHow arbeiten. Oder der Unternehmenskommunikation fehlt das Wissen um den Kontext und die Bedingungen solcher Projekte. Das Ergebnis:niemand weiß davon, niemand kommt, niemand kauft, die Zahl der Kritiker ist größer als die der Fans.

### Gute Kommunikation ist unerlässlich

Um das zu vermeiden ist es unserer Erfahrung nach aus mehreren Gründen wichtig, den Start eines neuen Metaverse- oder Web3-Projekts mit Maßnahmen der Unternehmenskommunikation zu begleiten.(Für die Ungeduldigen gibt es hier eine schnelle Checkliste zum Download.)
- Awareness fördern: Eine offizielle und wiederholte Bekanntmachung des neuen Projekts ist entscheidend, um potenzielle Nutzer und das Buy-In von Partnern, Mitarbeitern und Investoren zu gewinnen. Erfolgreiche Unternehmenskommunikation kann dazu beitragen, die Sichtbarkeit des Projekts zu erhöhen und die Aufmerksamkeit potenzieller Interessenten zu gewinnen.
- Vertrauen aufbauen: Eine klare und transparente Kommunikation kann dazu beitragen, das Vertrauen aller Beteiligten in das Projekt zu stärken. Durch die Kommunikation von Projektzielen, Roadmaps und Fortschritten können sich Interessierte ein Bild davon machen, was sie von dem Projekt erwarten können und wie es sich in Zukunft entwickeln wird.
- Marke stärken: Eine gezielte Unternehmenskommunikation kann dazu beitragen, das Bewusstsein für die Marke des Projektes oder das Projekt als Teil der Marke aufzubauen und zu stärken. Eine starke Marke kann dazu beitragen, das Projekt von ähnlichen Projekten zu unterscheiden und es für Nutzer attraktiver zu machen.
- Krisen managen: Bei innovativen und Pilot-Projekten kann es jedezeit zu unvorhergesehenen Ereignissen kommen, die die Initative beeinträchtigen können. Eine gut vorbereitete Unternehmenskommunikation kann dazu beitragen, das Vertrauen in das Projekt zu erhalten und schnell auf Probleme zu reagieren.

### Die wichtigsten ToDos und Taktiken

Wenn wir diese Anforderungen einmal auf die wichtigstemMaßnahmenherunterbrechen, haben sich in den letzten Monaten und Jahren diese  ToDos als Best-Practices etabliert.
- Arbeiten sie mit Pressemitteilungen: Offizielle Pressemitteilungen auf der Unternehmenswebsite und im PR-Verteiler sind ein wirksames und vertrauensförderndes Mittel, um die Aufmerksamkeit von Medien und Journalisten auf ein neues Projekt zu lenken. Eine gut geschriebene Pressemitteilung kann dazu beitragen, den Bekanntheitsgrad des Projekts zu erhöhen und das Interesse aller Beteiligten zu wecken.
- Kümmern sie sich ums Social Media Marketing: Social Media Plattformen wie Twitter, Discord und Reddit sind wichtige Kanäle, um die Zielgruppe des Projekts zu erreichen. Durch regelmäßige Beiträge und Updates auf diesen Plattformen können Unternehmen die Bekanntheit ihres Projekts steigern und das Interesse der Nutzer aufrechterhalten.
- Nutzen sie Influencer Marketing: Die Einbindung von Influencern, gerade im Web3-Bereich, kann dazu beitragen, das Projekt einer breiteren Öffentlichkeit vorzustellen und die Glaubwürdigkeit des Projekts zu erhöhen. Unternehmen können Influencer aus der Web3-Community, aber auch aus anderen Branchen wie Gaming, Entertainment, Marketing oder Bildung suchen.
- Kommunizieren sie die Roadmap – oft: Eine klare, transparente und wiederholte Kommunikation der Ziele und Meilensteine des Projekts kann dazu beitragen, das Vertrauen von Nutzern und Partnern zu stärken. Die Roadmap sollte regelmäßig aktualisiert und über verschiedene Kanäle kommuniziert werden, um die Nutzer auf dem Laufenden zu halten.
- Etablieren sie Community Management: Eine engagierte und aktive Community kann dazu beitragen, das Projekt voranzutreiben und das Interesse der Nutzer aufrechtzuerhalten. Unternehmen sollten sich bemühen, eine Community aufzubauen und zu pflegen, indem sie regelmäßig mit ihren Nutzern interagieren und deren Feedback berücksichtigen.
- Bereiten sie die Krise vor: Unternehmen sollten eine Krisenkommunikationsstrategie „in place“ haben, um schnell auf unvorhergesehene Ereignisse oder Probleme reagieren zu können. Eine effektive Krisenkommunikation kann im Eintrittsfall dazu beitragen, das Vertrauen von Nutzern und Investoren zu erhalten und das Projekt vor längerfristigem Schaden zu bewahren.
- Binden sie die Mitarbeiter ein: So offensiv wie sie extern kommunizieren, sollten sie das auch intern tun. Mitarbeiter können wichtige Verstärker, sollten vor allem aber auch auskunftsfähig sein. Erklären sie ihnen was sie tun, warum und wie das alles funktioniert.
Kurz gesagt kann eine erfolgreiche Unternehmenskommunikation – wie in jedem anderen Projekt – maßgeblich dazu beitragen, dasInteresse an einem neuen Metaverse- oder Web3-Projekt zu steigern, Vertrauen aufzubauen, die Marke zu stärken und in Krisenzeiten zu helfen. Daher ist es wichtig, dass Unternehmen ihre Kommunikationsstrategie von Anfang an sorgfältig planen und umsetzen.
Sollten Sie Interesse an Beratung zu diesem Thema haben, laden Sie sich gerne unsere Checkliste herunter und/oder schreiben eine Email anCarsten Rossi.
(*) Ja, wir wissen, dass es das Metaverse noch nicht gibt. Aber schon diverse Techniken und Plattformen, die ahnen lassen, was es werden könnte.

### Hier können Sie unsere Checkliste „Kommunikation für Metaverse und Web3-Projekte“ herunterladen

