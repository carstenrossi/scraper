---
url: https://www.kammannrossi.de/blog/topic/geschäftsberichte/page/2
scraped_at: 2026-01-08 18:39
title: Kammann Rossi - Content Action Blog  | Geschäftsberichte (2)
---

# Kammann Rossi - Content Action Blog  | Geschäftsberichte (2)


## FOX FINANCE 2016: Silber und Gold für Clariant Geschäftsbericht


##### vonJürgen Jehle| 02.11.2016 13:20:44 | 3 Minuten Lesezeit


## Zwei Galaxy Awards für MANN+HUMMEL


##### vonJürgen Jehle| 17.10.2016 13:11:45 | 2 Minuten Lesezeit


## KR Best Practice: Geschäftsbericht, Print- und Web-Magazin für MANN+HUMMEL


##### vonJürgen Jehle| 23.08.2016 09:26:25 | 3 Minuten Lesezeit


## Gut gemacht: Clariant Geschäftsbericht gewinnt DDC-Silber


##### vonJürgen Jehle| 22.12.2015 09:11:51 | 1 Minute Lesezeit


## Die besten Geschäftsberichte des letzten Jahres. Diesmal: Migros!


##### vonCarsten Rossi| 24.08.2015 13:59:18 | 2 Minuten Lesezeit


# „Die Zukunft des Mitarbeitermagazins 2022“


### Ausführliche Ergebnisse


## Die besten Geschäftsberichte des letzten Jahres. Diesmal: Bosch!


##### vonCarsten Rossi| 16.07.2015 16:48:22 | 2 Minuten Lesezeit


## Die besten Geschäftsberichte des letzten Jahres. Diesmal: Bayer!


##### vonCarsten Rossi| 06.07.2015 09:03:01 | 2 Minuten Lesezeit


## Vorstandsfotografie im Geschäftsbericht: Ohne Vertrauen geht es nicht!


##### vonMarc Ribbrock| 23.06.2015 08:26:36 | 3 Minuten Lesezeit


## Der Geschäftsbericht muss endlich zurück zu seinen Wurzeln


##### vonCarsten Rossi| 11.06.2015 09:13:52 | 4 Minuten Lesezeit


### Erfahren Sie mehr!


### Aktuellste Beiträge

- Black Weeks bei KR – echt jetzt?
- Magazin: Vom Lagerhaus zum Lesestoff
- CRSD: Mehr Chance als Nachteil!
- Praktikum mit Goldrand: Wie eine Herausforderung zum Erfolg wurde
- Schülerpraktikantinnen als Magazinmacherinnen bei Kammann Rossi

### Beliebteste Beiträge

- Die besten Mitarbeiterzeitungen - und was wir von ihnen lernen können
- 12 kreative Formate für die digitale Interne Kommunikation
- Redaktionskonzepte für die Mitarbeiterzeitung: Spannende Themen finden und passend aufbereiten
- Technologieakzeptanzmodelle als Basis der Change Kommunikation
- Die Top-Mitarbeiterzeitungen & Medien der Internen Kommunikation 2020

### Newsletter-Anmeldung

Die Kammann Rossi GmbH verpflichtet sich, Ihre Privatsphäre zu schützen und zu respektieren. Wir möchten Sie regelmäßig über neue Blogposts im Content Action Blog informieren. Wenn Sie damit einverstanden sind, dass wir Sie zu diesem Zweck kontaktieren, aktivieren Sie bitte das folgende Kontrollkästchen. Diese Einwilligung kann jederzeit widerrufen werden.
- Ich stimme zu, E-Mail-Mitteilungen von der Kammann Rossi GmbH  zu erhalten.
Um Ihnen die gewünschten Inhalte bereitzustellen, müssen wir Ihre persönlichen Daten speichern und verarbeiten. Wenn Sie damit einverstanden sind, dass wir Ihre persönlichen Daten für diesen Zweck speichern, aktivieren Sie bitte das folgende Kontrollkästchen.
- Ich habe die Datenschutzerklärung gelesen und stimme der Speicherung und Verarbeitung meiner persönlichen Daten durch die Kammann Rossi GmbH zu.*
Die Speicherung und Verarbeitung Ihrer Daten können Sie jederzeit widerrufen. Weitere Informationen zu unseren Datenschutzverfahren und dazu, wie wir Ihre Privatsphäre schützen und respektieren, finden Sie in unsererDatenschutzerklärung.
