---
url: https://www.kammannrossi.de/blog/unsere-projekte-in-der-externen-kommunikation
scraped_at: 2026-01-08 18:39
title: Unsere Projekte in der externen Kommunikation
---

# Unsere Projekte in der externen Kommunikation


# Unsere Projekte in der externen Kommunikation

vonCarsten Rossi| 25.05.2023 08:45:00 | 6 Minuten Lesezeit
Könnt ihr auch Kundenkommunikation?Überraschenderweise begegnet uns diese Frage im Arbeitsalltag immer mal wieder. Die eindeutige Antwort darauf lautet: Ja! Zugegeben, wir haben in letzter Zeit nicht viel darüber gesprochen. Aber dafür haben wir umso fleißiger an vielen großartigen (Kunden-)Projekten gewerkelt.Welche das sind? Und was die Projekte für uns besonders macht? Ein Überblick.

#### Magazin „Markets“ von Germany Trade & Invest (GTAI)

Wirtschaftsmagazin mal andersMit „Markets International“, „Markets Germany“ und „Markets Online“ möchte die GTAI den deutschen Mittelstand über Investitionschancen im Ausland informieren und Deutschland als Investitionsstandort bekannt machen.Arbeit mit internationalem NetzwerkMit über 40 Korrespondenten weltweit verfügt die GTAI über ein einzigartiges Netzwerk an Experten und Informationen – und Markets spiegelt dieses Expertenwissen wider. Der ausgewogene Mix aus nutzwertigen, aber auch überraschenden Themen und einem stark visuellen Storytelling sorgt dafür, dass Markets in der Masse der Wirtschaftsmagazine erfrischend anders ist.Weitere Informationen zu den Projekten der GTAI finden Sie hier:Projekt: Die Markets MedienfamilieProjekt: GTAI, Markets GermanyProjekt: GTAI, Markets International

#### Mitgliedermagazin „IHKplus“ der Industrie- und Handelskammer zu Köln

Publikation mit langer TraditionMit ihrem Mitgliedermagazin „IHKplus" informiert die Industrie- und Handelskammer zu Köln ihre Mitglieder seit über 70 Jahren direkt und zuverlässig über die wirtschaftlichen Entwicklungen im Kammerbezirk Köln.Ehrlich, menschlich, relevantIn enger Zusammenarbeit ist im Zuge des Relaunchs aus „IHKplus" ein aktives Kammermagazin geworden. Es rückt die Mitglieder der IHK in den Fokus, bietet mehr Service und Informationen und scheut sich zudem nicht vor einem kritischen Dialog und Stellungnahmen gegenüber Stadt und Politik.Weitere Informationen zum Projekt finden Sie hier:Projekt: IHK, Mitgliedermagazin

#### Info-Broschüre und Website für den Wasserverband Eifel-Rur (WVER)

Hochwasserschutz im FokusFür die Kommunikation rund um den neuen Maßnahmenkatalog zur Verbesserung der Hochwasserresilienz entschied sich der WVER für eine Info-Broschüre und die Gestaltung einer neuen Website:hochwassergefahrenvorbeugen.deTransparente und bürgernahe KommunikationHochwasserschutz geht alle an. Deshalb setzt der WVER bei seiner Kommunikation vor allem auf eines: Transparenz. Die Maßnahmen zum Hochwasserschutz werden verständlich und anhand von Bildern erläutert. Auf der dynamisch wachsenden Website lassen sich neben neu hinzukommende Schutzmaßnahmen, auch Tipps für die Bürger*innen sowie wichtige Info-Veranstaltung ergänzen.Weitere Informationen zum Projekt finden Sie hier:Projekt: Wasserverband Eifel-Rur

#### Corporate Blog von Clariant

Chemie mal andersMit dem Corporate Blog „The Moleculist“ bietet das Spezialchemieunternehmen Clariant im B2B-Bereich einen Deep-dive in die Welt der „großen Moleküle“.Komplexe Inhalte, leicht verständlich aufbereitet„The Moleculist“ erweckt die Innovationen, Produkte, Dienstleistungen und Kooperationen von Clariant zum Leben, macht Wissenschaft und Chemie verständlich und zeigt die leidenschaftlichen Menschen hinter den Kulissen. So kann Clariant nicht nur werbewirksam auftreten, sondern auch das Bewusstsein für die Marke des Unternehmens stärken.Weitere Informationen zum Projekt finden Sie hier:Projekt: Clariant, The Moleculist

#### Social-Media-Präsenz und Website „2025 AD“ von Continental

Startschuss für das automatisierte FahrenMit der Social-Media-Präsenz und der Website „2025 AD“ wollte Continental den Dialog zwischen allen Stakeholdern zum Thema „Automatisiertes Fahren“ ermöglichen und fördern.Zum Dialog anregenIm Dialog mit den ganz unterschiedlichen Zielgruppen wurden über Social Media neue Erkenntnisse für die Forschung und Entwicklung gewonnen. Nach sieben Jahren wurde das Projekt eingestellt – lebt aber über die WebsiteBest of 2025ADbis heute weiter.Weitere Informationen zur Social-Media-Präsenz finden Sie hier:Projekt: Continental, 2025AD

#### Ratgeber-Seite der EUROPA Versicherungen

Inhalte mit MehrwertMit ihrer Ratgeber-Seite reichert die EUROPA die eigene Homepage mit relevantem Content und einer Mehrwertkommunikation für (potenzielle) Kunden an.Traffic steigern und neue Zielgruppen erreichenErklär-Beiträge, How-to-Formate und Ratgeber-Artikel zahlen auf erklärungsbedürftige Produkte ebenso ein wie auf spezielle Lebenssituationen oder -phasen von Kunden und Interessenten. Auf diese Weise sorgt das nutzerfreundliche Ratgeber-Portal mit SEO-optimierten Texten und zahlreichen Call-to-Action-Elementen für mehr Traffic auf der Website.Weitere Informationen zum Projekt finden Sie hier:Projekt: Europa Versicherungen, Ratgeber-Seite

#### Website zur Betriebserweiterung bei Storck

Baupläne offenlegenAm Standort Halle (Westfalen) realisiert der Süßwarenhersteller Storck eine Betriebserweiterung. Da die Erweiterungsmaßnahmen von öffentlichem Interesse sind, informiert Storck proaktiv und transparent aufeiner eigenen Seite.Sorgen nehmen durch transparente KommunikationDie Website informiert stets aktuell über die Betriebserweiterung. Fortschritt, Planungen und Hintergründe finden sich hier genauso wie zahlreichen Fotos und interaktive Karten. So wissen Bürger*innen und Interessierte ganz genau, welche Maßnahmen zukünftig geplant sind und welche aktuell umgesetzt werden.Weitere Informationen zum Projekt finden Sie hier:Projekt: Storck Betriebserweiterung

#### Konzernmagazin „ARAG InSight“ der ARAG

Informationsquelle für StakeholderMit ihrem Konzernmagazin ARAG InSight informiert die ARAG dreimal jährlich ihre Mitarbeiter*innen und Stakeholder über alle wichtigen Entwicklungen in Konzern und Versicherungsbranche.In Print und Online – auf Deutsch und EnglischARAG InSight erscheint nicht nur als modernes Printmagazin mit frischen Formaten und zweisprachigem Wendecover, sondern auch als responsives Onlinemagazin. Dieses bietet der ARAG Konzernkommunikation ohne großen Mehraufwand die Möglichkeit, an passender Stelle ergänzende Informationen auszuspielen – so etwa zusätzliche Artikel, Bildergalerien, Links sowie Videos.Das Onlinemagazin von ARAG InSight finden Sie hier:www.arag-insight.comGanz gleich, ob Sie Kund*innen, Partner*innen oder andere Stakeholder erreichen möchten – wirkungsvoll wird Kommunikation am Ende erst mit schlüssigen Konzepten, spannenden Geschichten und einer gehörigen Prise Kreativität. Bei all dem unterstützen wir Sie gerne. Melden Sie sich doch einfach überunser Kontaktformular.
