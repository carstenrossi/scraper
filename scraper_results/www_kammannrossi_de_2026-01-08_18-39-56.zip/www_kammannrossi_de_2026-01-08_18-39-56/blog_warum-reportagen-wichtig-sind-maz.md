---
url: https://www.kammannrossi.de/blog/warum-reportagen-wichtig-sind-maz
scraped_at: 2026-01-08 18:39
title: Warum Reportagen so wichtig für Kunden- und Mitarbeitermagazine sind
---

# Warum Reportagen so wichtig für Kunden- und Mitarbeitermagazine sind


# Warum Reportagen so wichtig für Kunden- und Mitarbeitermagazine sind

vonCarsten Rossi| 03.01.2020 10:00:00 | 3 Minuten Lesezeit
Reportagen in Magazinen gelten als die Königsdisziplin des Journalismus. Warum eigentlich?
In Magazinen steht der Begriff Reportage lautWikipedia„für einen dramaturgisch aufbereiteten ... Hintergrundbericht, der einen Sachverhalt anhand von konkreten Beispielen, Personen oder deren Schicksalen anschaulich macht.“
Anders gesagt: für eine Reportagebegleiten wir einen Menschen, sehr nah und so authentisch wie möglichauf dem Weg durch sein Leben, seinen Beruf oder eine Aufgabe. Das gilt einerseits zurecht als sehr aufwändig, denn im Gegensatz zur berichtstypischen „Desk-Research“ müssen die Redakteure ihren Arbeitsplatz für eine Reportage verlassen und engen Kontakt zu einem Menschen aufbauen. Dafür braucht es mehr Zeit und Ressourcen als jedes andere journalistische Format. Und beide sind bekanntermaßen knapp. Andererseits gilt sie aber auch alsKönigsdisziplin des Journalismus, als unerlässliches Element jedes Kundenmagazins oderMitarbeitermagazins. Auch wir versuchen jede von uns gestaltete Ausgabe, vor allemOnline-Magazine, mit einer Reportage zu krönen. Aber warum eigentlich?

### Reportagen schaffen Verbindungen

Es gibt mittlerweile viele wissenschaftliche Belege dafür, dass es mehr als vorteilhaft ist, dieeigenen Botschaftennicht nur durch Behauptungen oder Fakten, sondern mit Hilfe einesauthentischen, menschlichen Protagonisten zu vermitteln.Einer der für mich wichtigsten Stichwortgeber in diesem Zusammenhang ist Daniel Kahneman, ein israelisch-amerikanischer Psychologe, Wirtschaftswissenschaftler und Nobelpreisträger. Kahneman hat in seinem Buch„Schnelles Denken. Langsames Denken“an vielen Beispielen belegt, dass unser Gehirn auf manche Dinge sehr schnell und instinktiv reagiert, auf andere wiederum nur sehr langsam und durch bewusste Anstrengungen.
Der Grund dafür ist, dass unser Gehirn mit zwei Systemen, dem sogenannten„System 1“und dem„System 2“, ausgestattet ist.System 1kann man nicht abschalten, es ist immer aktiv und ist für vieles von dem verantwortlich,was wir „Intuition“ nennen,insbesondere für schnelle Eindrücke und spontane Gefühle.System 2hingegen muss man in gewisser Weise erst aktivieren, bevor es nützlich wird. Dafür kann es dann allerdingslogische Schlüsse ziehen oder Statistiken interpretieren.
Für das ThemaMagazinist in diesem Zusammenhang wichtig, dass das „automatische“System 1neben vielen anderen Dingenbesonders gut in der Einschätzung menschlicher Emotionenist. Wir erkennen z.B. sofort, wenn jemand wütend auf uns ist und können entsprechend reagieren. Viel mühsamer ist es für unser Gehirn hingegen, mit Hilfe von System 2 eine Tabelle oder eine statistische Grafik zu interpretieren und daraus die richtigen Schlussfolgerungen zu ziehen.

### Reportagen helfen zu verstehen - und zu mögen

Wir haben also dank eines stets wachen Systems 1 und eines recht trägen Systems 2 einen sehrinstinktiven Zugang zu Menschenund ein eher angestrengtes Verhältnis zu Fakten. Wenn wir also eine Reportage nutzen, die von einem echten menschlichen Protagonisten berichtet, haben wir schon durch die Wahl des Formats die halbe Miete in der Tasche. Dennunsere Leser verstehen Botschaften, die von und durch Menschen vermittelt werden, mühelos.Berichten wir hingegen auf Basis von Zahlen, selbst wenn es im Rahmen einer aufwändig gestalteten Infografik geschieht, müssen sich unsere Leser erst einmal anstrengen, bevor sie begreifen. Und wie wir alle wissen, ist Anstrengung Gift für Aufmerksamkeit, Verständlichkeit und die Bereitschaft sich mit einem Thema überhaupt auseinanderzusetzen.

### Der Halo Effekt macht Marken sympathisch

Dabei kommt es sogar noch besser: wenn der Protagonist unserer Reportage sympathisch ist, wirken Sie bzw. Ihr Unternehmen es auch. Denn dank des sogenannten„Halo-Effekts“werden die Menschen dieSympathie,die sie für den Protagonisten empfinden,auf Sie oder Ihre Marke übertragen.System 1 neigt nämlich dazu, einespontane emotionale Kohärenzherzustellen. Jeder, der Ihren Protagonisten mag und Sie als Absender identifiziert, wird Sie zunächst mal ebenfalls sympathisch finden – selbst wenn Sie es eigentlich nicht sind.

### Auch die Spiegelneuronen helfen

Unterstützt werden Kahnemans psychologische Forschungen übrigens auch aufneurowissenschaftlicher Ebene,und zwar durch den Nachweis der sogenannten„Spiegelneuronen“.Spiegelneuronen sind spezielle Nervenzellen im Gehirn, eine Art Resonanzsystem, das es uns ermöglicht, mit unseren Mitmenschen zu fühlen. Wenn sich ein Mensch in unserer Nähe freut oder wenn er Schmerz empfindet,erleben wir ganz unwillkürlichdie gleichen Emotionen, wir spiegeln sie.Diese Nervenzellen machen uns erst zu den mitfühlenden Wesen, die wir in der Regel sind.Wir sind sozusagen prädisponiert dafür, uns mit Geschichten von und über Menschen zu identifizieren.Deshalb sind Reportagen so wichtig

### In Kürze: Warum lohnt sich der Aufwand für Reportagen?

- Menschen verstehen Reportagen intuitiv,weil sie Menschen intuitiv verstehen.
- Sympathische Protagonisteneiner Reportagefärben positivauf das Image Ihres Unternehmensab.
- Reportagen unterstützendas Verhältnis vonUnternehmens- und Markenbotschaften besserals jedes andere journalistische Format.
