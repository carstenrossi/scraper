---
url: https://www.kammannrossi.de/blog/webinar-zur-zukunft-des-mitarbeitermagazins-am-18.oktober-2022
scraped_at: 2026-01-08 18:39
title: Webinar zur Zukunft des Mitarbeitermagazins am 18.Oktober 2022
---

# Webinar zur Zukunft des Mitarbeitermagazins am 18.Oktober 2022


# Webinar zur Zukunft des Mitarbeitermagazins am 18.Oktober 2022

vonKR Redaktion| 29.09.2022 08:30:00 | 2 Minuten Lesezeit
In unserer kostenlosen Web-Session am18. Oktoberstellen wir Ihnen die Ergebnisse unserer Studie zurZukunft der Mitarbeiterzeitungvor. Begleitet wird die Studienpräsentation von einer Gesprächsrunde mit Experteneinschätzungen.Melden Sie sich gerne hier an.
Der digitale Wandel bringt große Veränderungen für die interne Kommunikation mit sich: Mit ihrer Rolle im Unternehmenwandeln sich auch Inhalteund eingesetzte Medien. Moderne interne Kommunikationsmanager*innen müssenverschiedene Medien undFormateorchestrieren und zu einem stimmigen Gesamtkonzept zusammenfügen. Besonders die gedruckte Mitarbeiterzeitung (MAZ) steht vor Herausforderungen, die darüber entscheiden werden, ob sie sich als wichtiges Medium der internen Kommunikation behaupten kann:
- Welche Rolle spielt die MAZ in Zeiten derdigitalen Transformationund wie wird sie sich zukünftig entwickeln?
- Welche Veränderungen haben sich in den letzten Jahren ergeben, technisch, organisatorisch und inhaltlich, und was macht eine moderne gedruckte oder digitale MAZ aus?
- Wie steht es heute um die Mitarbeiterkommunikation in den Unternehmen und welche Bedeutung haben hierbeimobile Kanäle?
Diesen und weiteren Fragen gingen SCM und Kammann Rossi in der Studie„Die Zukunft des Mitarbeitermagazins 2022“bereits zum sechsten Mal nach. Teilgenommen haben rund250 Kommunikationsprofisaus dem D/A/CH-Raum. Ziel war es, aus den Beantwortungen Schlüsse für die moderne Mitarbeiterkommunikation zu ziehen.
Mit dabei sind u.a.:
- Kristina Kix, Leiterin Interne Kommunikation beiRewe
- Arne Büdts, Creative Director bei Kammann Rossi
- Dr. Christian Fill, Geschäftsführer bei Kammann Rossi
- Philipp Bahrt, Chefredakteur BEYOND bei der SCM – School for Communication and Management.
Wir freuen uns, wenn Sie unser Webinar besuchen.Melden Sie sich gerne hier an.
