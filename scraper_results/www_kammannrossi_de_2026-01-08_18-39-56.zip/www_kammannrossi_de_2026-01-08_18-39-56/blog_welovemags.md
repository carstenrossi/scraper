---
url: https://www.kammannrossi.de/blog/welovemags?hsLang=de-de
scraped_at: 2026-01-08 18:39
title: #welovemags - Warum bei uns das Jahr des Magazins beginnt
---

# #welovemags - Warum bei uns das Jahr des Magazins beginnt


# #welovemags - Warum bei uns das Jahr des Magazins beginnt

vonCarsten Rossi| 05.11.2019 10:00:00 | 2 Minuten Lesezeit
Update vom August 2021: Im Jahr 2019 haben wir für bei Kammann Rossi das Jahr des Magazins ausgerufen - und sind jetzt schon im zweiten? Warum? Weil alles, was wir dazu geschrieben haben, weiter gilt und weil wir so erfolgreich waren, dass dieser Fokus uns auch in Zukunft tragen kann - genauso wie unsere Magazin-KundenRewe,GTAI,Frauscher, Continental,ARAGoder Symrise.
Wir möchten euch dazu bringen, wieder mehr Geld in Magazine und Content Hubs zu investieren und weniger in Social Media. Wie wir das hinkriegen wollen?

## Wir rufen das Jahr des Magazins aus!

Unter dem Hashtag #welovemags wollen wir ein Jahr langhilfreiche Informationenpublizieren, die euch zeigen, wie aufregend, spannend und vor allen Dingen nützlich es sein kann, Owned Media zu produzieren, die eure User, Leser oder Mitarbeiter wirklich begeistern. Mit Owned Media beziehungsweise Magazinen meinen wir in diesem Fall alle möglichen Formen von Inhalten, die euch selber gehören und die nicht auf sogenanntem „rented land“ - das heißt auf anderen Plattformen - publiziert werden. Das können Corporate Blogs sein, Mitarbeitermagazine, Kundenmagazine, in Print undOnline. Aber was wir alles damit meinen, das werdet ihr im Laufe des Jahres noch sehen.

#### Wir haben drei Gründe dafür, warum wir das tun wollen: Kalkül, Kreativität und Komplexität.

BeiKalkülgeht vor allen Dingen um wirtschaftliches Kalkül. Bei Engagement Rates auf sozialen Netzwerken von unter einem Prozent scheint uns vieles von dem Geld, das wir dort ausgeben schlicht und einfach rausgeschmissen. Und selbst wenn es nicht rausgeschmissen ist, dann ist vieles an Reichweite für unsere Kunden so teuer erkauft, dass man lieber ein Asset hat, das man selber besitzt und dazu nutzen kann, einen eigenen, völlig unvermittelten Dialog aufzubauen.
Kreativitäthat etwas mit unserem eigenen und dem Anspruch unserer Kunden an Gestaltung zu tun. Wir sind es ehrlich gesagt leid, uns von sozialen Netzwerken vorschreiben zu lassen, wie wir Inhalte gestalten. Es ist ein bisschen wie mit einer Mietwohnung im Vergleich zum eigenen Haus. In einer Mietwohnung habe ich kaum Möglichkeiten, die Wände mal zu verrücken. Aber in einem schönen Online-Magazin kann ich wie in den eigenen vier Wänden meiner Kreativität freien Lauf lassen, solange die Statik stimmt.
Und auch der dritte GrundKomplexitäthat etwas mit einem Anspruch zu tun, nämlich dem Anspruch daran, komplexe Zusammenhänge vermitteln zu können. Wenn immer nur Post auf Post folgt, wird es wahnsinnig schwierig, Dinge zu zeigen, die zusammengehören und die vielleicht etwas schwieriger zu erklären sind. In einem Online-Magazin oder in einem Print-Magazin haben wir dafür die Zeit, die Fläche und den Raum, um Dinge zusammenhängend darzustellen. Vielleicht lieben wir deshalb den Begriff und das Medium Magazin auch so. Denn ein Magazin hat den Anspruch, genau das zu tun: Zusammenhänge zu vermitteln und Transparenz zu schaffen und gleichzeitig durch Bilder und Texte in einer schönen Dramaturgie Engagement zu erzeugen - egal in welchem Medium, obOnlineoder Print.
Aber keine Angst, wir werden die nächsten Monate nicht nur über das klassische Magazin reden. Wie schon am Anfang gesagt, geht es uns um Content Hubs, egal in welchem Medium. Wobei wir uns auf jeden Fall auch bemühen werden, eine Lanze für das Print-Magazin zu brechen. Denn ganz ehrlich: In welchem digitalen Medium bekomme ich je nach Zählung Lese- oder Kontaktzeiten von sieben bis siebzig Minuten am Stück?
Achtet in den nächsten Monaten bei unseren Accounts einfach auf den Hashtag#welovemags.Wir freuen uns auf einen guten Dialog mit euch!
