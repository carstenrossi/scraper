---
url: https://www.kammannrossi.de/blog/wie-chatgpt-co-die-interne-kommunikation-verändern-könnten
scraped_at: 2026-01-08 18:39
title: Wie ChatGPT & Co. die Interne Kommunikation verändern könnten
---

# Wie ChatGPT & Co. die Interne Kommunikation verändern könnten


# Wie ChatGPT & Co. die Interne Kommunikation verändern könnten

vonCarsten Rossi| 07.11.2023 10:48:00 | 3 Minuten Lesezeit
Von Content Hubs zu Content Communitys
Künstliche Intelligenz, insbesondere in Form von Large Language Models (LLMs) wie GPT-4, hat die Möglichkeiten der Unternehmenskommunikation, auch der internen, erheblich erweitert. Sie ermöglicht es uns, effizienter zu arbeiten und vielleicht sogar früher den Feierabend zu genießen. Doch wird zusehends deutlich, dass uns diese neuen Möglichkeiten auch vor Herausforderungen stellen werden: Unsere internen Kommunikationskanäle könnten an Bedeutung – und vor allem an Reichweite – verlieren.
Die Herausforderung: Zu viele Inhalte und jetzt auch noch KI
Wir sind als Mitarbeitende schon jetzt von einer Flut an Informationen umgeben. Mit der Entwicklung von KI und LLMs und der damit verbundenen Effizienzsteigerung wird diese Informationsflut höchstwahrscheinlich weiter zunehmen. Plötzlich kann jeder „gut kommunizieren“. Schon allein dies sollte uns dazu bringen, darüber nachzudenken, wie unsere strategischen Medien in Zukunft nicht nur relevant, sondern auch sichtbar bleiben, kurz: wie es uns gelingt, die Aufmerksamkeit der Mitarbeiter nicht zu verlieren.
Perspektivisch viel dramatischer jedoch könnten LLMs wie ChatGPT die Art und Weise, wie unsere Kolleginnen und Kollegen Informationen suchen und konsumieren, verändern. Wenn Unternehmen wie dm und Bosch schon heute daran arbeiten, die gesamte Belegschaft mit digitalen KI-Assistenten auszustatten – ganz zu schweigen von Microsoft –, werden Mitarbeitende höchstwahrscheinlich immer häufiger direkte Fragen an diese stellen. Die internen Kommunikationskanäle wie Mitarbeitermagazine, Intranets oder Mitarbeiter-Apps werden immer weniger genutzt werden (müssen). Unserer Meinung nach erfordert dies schon heute eine Anpassung unserer Kommunikationsstrategien: Wir müssen Beziehungen höher gewichten als Content.
Die Lösung: Der Aufbau von Content Communities
Wir glauben, dass der Umbau unserer Content Hubs zu Content Communitys der nächste Schritt sein muss. Im Gegensatz zu informationsgesteuerten Content Hubs sind Content Communitys dynamische Ökosysteme, die auf der aktiven Teilnahme und dem Engagement der Mitarbeitenden basieren. Sie können Orte werden, an denen sich die Mitarbeitenden aktiv einbringen und die sie freiwillig aufsuchen.
Wege zum Community-Building
Um aus dem Hub – also der Intranet-Startseite, der App oder dem gedruckten oder digitalen Mitarbeitermagazin – sukzessive eine starke Content Community aufzubauen, bieten sich verschiedene Taktiken an, die nicht unbedingt neu sind, die aber sehr viel stärker in den Fokus rücken müssen, als dies aktuell der Fall ist:
- Sichtbarkeit steigern:Bieten Sie vor allem Abonnements Ihrer Medien an, egal ob digital oder gedruckt, um sicherzustellen, dass Sie die Mitarbeitenden jederzeit erreichen. So bleibt Ihr Content jederzeit in deren Blickfeld. Content Marketer wissen das: nichts garantiert Erreichbarkeit besser als E-Mail- oder Messenger-basierte Abonnements. (Eine zusätzliche Distribution wichtiger Inhalte über andere interne Kanäle schadet natürlich auch nie.)
- Loyalty-Programme starten:Belohnen Sie wiederkehrendes Lesen und Engagement durch Loyalty-Programme. Diese können beispielsweise Punktesysteme oder Auszeichnungen beinhalten, die die Mitarbeitenden motivieren, regelmäßig Ihre Inhalte zu konsumieren und sich aktiv zu beteiligen.
- Dialogoptionen bieten:Stellen Sie sicher, dass es viele Möglichkeiten für die Mitarbeitenden gibt, sich auszutauschen und Feedback zu geben. Dies kann durch Kommentarfunktionen, Diskussionsforen oder direkte Nachrichten geschehen. Ein offener Dialog fördert das Gemeinschaftsgefühl und erhöht die Bindung der Mitarbeitenden. Community-Managerinnen und -Manager müssen mindestens so wichtig sein wie Redakteurinnen und Redakteure.
- Crowdsourcing nutzen:Bieten Sie den Mitarbeitenden die Möglichkeit, ihre eigenen Ideen und Inhalte beizusteuern. Dies kann die Vielfalt und Relevanz Ihrer Inhalte erhöhen und die Mitarbeitenden stärker einbinden. So entsteht ein Gefühl der Mitgestaltung und Zugehörigkeit.
- Content Brand pflegen:Sorgen Sie dafür, dass Ihre Kommunikation eine starke Content-Brand hat. Ihre Medien müssen einen klaren Purpose haben und eine eindeutige visuelle und redaktionelle Identität aufweisen. Idealerweise stellen Sie authentische Formate, persönliches Storytelling und Mitarbeitergeschichten in den Mittelpunkt.
Wir glauben nicht, dass der Aufbau und die Pflege von Content Hubs wie Mitarbeitermagazinen oder Intranets gänzlich an Relevanz verlieren wird. Aber die oben skizzierte Evolution des Kontextes der IK erfordert einen nächsten Schritt, wenn wir weiterhin unseren Auftrag erfüllen wollen. Das Aufsetzen von Community-Bemühungen auf existierenden Content Hubs ist aus unserer Sicht der Königsweg, um die Aufmerksamkeit und Loyalität aller Zielgruppen auch in Zukunft effizient und ressourcenschonend zu gewinnen und zu halten.
