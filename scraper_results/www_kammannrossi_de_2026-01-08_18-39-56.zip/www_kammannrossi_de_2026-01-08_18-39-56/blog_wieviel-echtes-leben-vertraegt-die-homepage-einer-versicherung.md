---
url: https://www.kammannrossi.de/blog/wieviel-echtes-leben-vertraegt-die-homepage-einer-versicherung
scraped_at: 2026-01-08 18:39
title: Wieviel echtes Leben verträgt die Homepage einer Versicherung?
---

# Wieviel echtes Leben verträgt die Homepage einer Versicherung?


# Wieviel echtes Leben verträgt die Homepage einer Versicherung?

vonDr. Christian Fill| 08.08.2022 13:59:23 | 2 Minuten Lesezeit
Trocken, öde und unverständlich? So will die EUROPA Versicherungen nicht rüberkommen. Ein modernes, datengestützte Content-Marketing-Konzept holt Kunden und Interessenten deshalb in den zu ihnen passenden Lebenssituationen ab.
Die EUROPA Versicherungen wollte Kunden näher an ihren Bedürfnissen abholen und deshalb ihreHomepagelangfristig mit relevantem Content und echtem Mehrwert anreichern. Dafür entwickelte Kamann Rossi eine Content-Marketing-Strategie mit Fokus auf den unterschiedlichen Lebensphasen der Kunden. Im extra auf der Seite eingerichtetenRatgeber-Bereich finden sie nun einen stetig wachsenden Pool an Geschichten, die erklärungsbedürftige Produkte verständlich machen. Dabei holen sie die Leser*innen in den für sie relevanten Lebensphasen ab. So liegt der Fokus nicht länger allein auf den angebotenen Produkten.

##### Bedürfnisse statt Zielgruppen

Die EUROPA Versicherungen ist ein Direktversicherer mit Sitz in Köln. Zum direkten Wettbewerb gehören CosmosDirekt, HUK24, die Verti Versicherung AG, DA Direkt Versicherung sowie Allianz Direct Versicherung. Das Unternehmen bietet Produkte in den Bereichen Leben-, Altersvorsorge, Berufsunfähigkeit-, Unfall-, Haftpflicht-, Hausrat- Gebäude- und Kfz-Versicherungen an. Bereits zu Beginn der Konzeptionsphase war klar: typische Zielgruppen- und Persona-Definition führt nicht weit, schließlich befasst sich fast jeder irgendwann einmal mit dem Thema Versicherung. Darum werden Familien wie Alleinerziehende, Paare wie Singles und Senioren wie Studenten angesprochen. Anstelle von Personas setzt das Konzept von Kammann Rossi auf die Motivation von Kunde*innen und Interessierten: Welcher Bedarf motiviert sie dazu, sich über Versicherungen zu informieren? Alle Beiträge der sich sukzessive füllenden Ratgeber-Seiten haben deshalb immer einen Aufhänger aus lebensnahen Situationen wie Hochzeit, Scheidung, eigene Wohnung oder Haus, Ausziehen oder Zusammenziehen. So gelingt es der EUROPA Versicherungen Interessierte und Kund*innen mit journalistischen Inhalten die relevanten Informationen an die Hand zu geben, um eine fundierte Entscheidung für eine Versicherung zu ermöglichen.
> „Das Content-Marketing-Konzept für die EUROPA Versicherungen liefert Antworten auf reelle Fragestellungen aus dem Leben der Kunden. Damit bietet das Unternehmen ihnen ganz im Sinne der Customer Centricity einen echten Mehrwert.“Christian FillGeschäftsführer, Kammann Rossi GmbH
„Das Content-Marketing-Konzept für die EUROPA Versicherungen liefert Antworten auf reelle Fragestellungen aus dem Leben der Kunden. Damit bietet das Unternehmen ihnen ganz im Sinne der Customer Centricity einen echten Mehrwert.“

##### Transparenz statt Versicherungsblabla

Passend zur Positionierung der EUROPA Versicherungen mit dem Slogan „Versicherungen pur“ sind die verfassten Beiträge in lebhafter und verständlicher Sprache geschrieben. Dennoch haben sie einen hohen Informationsgehalt und werden mit Statistiken, Studien,
Grafiken und Hinweisen auf Testsiege untermauert. Auch werden Themen aufgegriffen, die vielleicht noch nicht bedacht wurden. Zum Beispiel, dass auch fürKinder eine Unfallversicherung sinnvollsein kann. Einen praktischen Mehrwert bieten auch Checklisten, zum Beispiel, wenn es darum geht,mit dem Auto in den Urlaub zu fahren. Querverweise zu anderen Beiträgen, Verlinkungen auf Beitragsrechner und Produktseiten machen es den Leser*innen zudem einfach, sich umfassend zu informieren.

##### Content-Erstellung mit messbaren Ergebnissen

Wie kommen Fahranfänger an eine bezahlbare Kfz-Versicherung? Welche Vorteile bringt eine Zahnzusatzversicherung für Kinder? Können auch verheiratete Homosexuelle und Diverse eine Risikolebensversicherung abschließen?
Die Bandbreite auf der Ratgeberseite und der Themenmix ist groß. Nach und nach entsteht ein Portal mit SEO-optimierten Texten, die untereinander verlinkt sind und durch zahlreiche Call-to-Action-Elemente für messbar mehr Traffic auf der Website sorgen. Das Konzept geht mit einer Verweildauer von knapp unter einer Minute und einer Bounce-Rate von unter 50% bislang gut auf.

##### Projektverlauf, Learnings und Checkliste

Wir haben denzeitlichen Verlaufdes Projektes, unsere (übertragbaren)Learningsund eineChecklistefür das ideale Content Marketing Projekt in einem PDF für Sie zusammengefasst. Das Projekt können Sie nach Ausfüllen des Formulars herunterladen. Es lohnt sich wirklich.

### Hier geht's zum Download

