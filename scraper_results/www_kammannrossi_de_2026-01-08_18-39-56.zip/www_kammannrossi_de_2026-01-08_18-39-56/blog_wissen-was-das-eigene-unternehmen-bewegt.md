---
url: https://www.kammannrossi.de/blog/wissen-was-das-eigene-unternehmen-bewegt
scraped_at: 2026-01-08 18:39
title: Wissen, was das eigene Unternehmen bewegt
---

# Wissen, was das eigene Unternehmen bewegt


# Wissen, was das eigene Unternehmen bewegt

vonRebecca Lorenz| 04.05.2023 10:30:10 | 3 Minuten Lesezeit
81.396 Stunden – so viel Zeit verbringen die meisten von uns im Laufe ihres Lebens mit Arbeit. Ist das jetzt schön? Oder schrecklich? Laut der Gallup-Studie „State of the Global Workplace“ offenbar eher letzteres. Laut ihr fühlten sich im Jahr 2022 rund 60 Prozent der Mitarbeitenden weltweit emotional von ihrer Arbeit distanziert. Ganze 19 Prozent gaben sogar an schlichtweg unglücklich zu sein. Wirklich engagiert und begeistert bei der Arbeit? Waren lediglich 21 Prozent der Befragten.
Nicht nur für Mitarbeitende, sondern auch für Unternehmen ist das eine schwierige Situation. Denn eine geringe Zufriedenheit und ein niedriges Engagement in der Belegschaft hat auch für sie drastische Folgen. So würden laut einer EY-Jobstudie rund 81 Prozent der Beschäftigten den aktuellen Arbeitsplatz für das richtige Angebot verlassen – und das sogar dann, wenn sie eigentlich nicht auf Jobsuche sind. Kombiniert mit geringeren Produktivitätsraten und höheren Fehlzeitenkostet ein geringes Mitarbeiterengagement so allein deutsche Unternehmen rund 6 Millionen Euro pro Jahr.

#### Engagement mit interner Kommunikation nachhaltig steigern

Doch wie lässt sich das ändern? Ein wichtiger Hebel, um das Engagement von Mitarbeitenden nachhaltig zu steigern ist die interne Kommunikation. Sie sorgt dafür, dass Beschäftigte über alle wichtigen Vorgänge informiert bleiben, ermöglicht die Wertschätzung von Leistung und kann so das Teamgefühl und Engagement in Unternehmen nachhaltig stärken. Zumindest, wenn sie gut gemacht ist – und den tatsächlichen Anforderungen und Wünschen der Belegschaft entspricht.Viele Kommunikatoren verlassen sich dabei auch heute immer noch sehr stark auf das eigene Bauchgefühl. Dabei lässt sich dieWirksamkeit von Kommunikation– auch intern – inzwischeneinfach messen. Zum Beispiel mitHaiilo Insights.Ursprünglich für Führungskräfte und Personaler konzipiert, eignet sich das Engagement-Umfrage-Tool von Haiilo auch für die objektive Beurteilung von kommunikativer Wirksamkeit. Denn schon mit wenigen Klicks lässt sich mit seiner Hilfe kontinuierlich und unkompliziert herausfinden, welcheVorlieben, Meinungen, Stimmungen und Wissenslückendie Mitarbeitenden im Unternehmen aktuell bewegen – und in der Redaktionsplanung entsprechend schnell darauf reagieren.

#### Content Impact messen und sichtbar machen

Ein Beispiel: Ein neuer CEO fängt im Unternehmen an. Um ihn gleich zu Beginn als nahbar und offen zu positionieren, werden verschiedene Inhalte zu seiner Person gespielt – wie etwa ein Gruß zum Start, ein persönliches Kurzporträt, ein Interview oder ein AMA (Ask me anything). Damit wissen nun alle Mitarbeitenden, wer der CEO ist und was sie von ihm zu erwarten haben. Oder? Mithilfe von Haiilo Insights lässt sich diese Annahme einfach und objektiv überprüfen. Etwa indem man die Mitarbeitenden die folgende Aussage bewerten lässt: „Ich empfinde unseren neuen CEO als offen und nahbar.“ Ist die Zustimmung zur Aussage hoch, hat die Kommunikation ihr Ziel erfüllt. Ist die Zustimmung niedrig, können wir als Kommunikatorengezielt neue Inhalte und Formate entwickeln und so die Redaktionsplanung optimieren.All das sorgt dafür, dassMitarbeitende sich gehört fühlen– und das Engagement im Unternehmen nachhaltig steigt. Denn das Messen des sogenannten Content Impact, also der Wirkung von Kommunikation auf Zielgruppen, ist am Ende nichts anderes als Zuhören in quantifizierbarer Form. Das belegt auch das Feedback verschiedener Unternehmen an Haiilo. Laut ihm sorgt der Einsatz von Haiilo Insights für eine rund 30 Prozent höhere Mitarbeiterzufriedenheit, eine 23 Prozent geringere Kündigungsrate und ein 15 Prozent besseres Strategieverständnis im Unternehmen. In Anbetracht der anfangs genannten Zahlen ist diese Wirkung kaum zu überschätzen.Doch Haiilo Insights bietet noch weitere Vorteile: So erleichtert es Kommunikatoren zum Beispiel, diegetroffene Themenauswahl innerhalb des Unternehmens zu begründen. Denn anhand der Umfrage-Ergebnisse lässt sich recht einfach nachweisen, weshalb das eine Thema für die interne Kommunikation relevant ist, das andere aber nicht. Hinzu kommt, dass sich auch derWert der eigenen Redaktionsarbeitanhand der erhobenen Zahlen schnell belegen und dokumentieren lässt.

#### Online-Umfrage zur Messung des Content Impacts

Starke Argumente, die allesamt für die Messung des Content Impact in der internen Kommunikation sprechen. Doch wie konsequent wird das in deutschsprachigen Unternehmen bereits gemacht? Und konzentriert sich die Messung dort eher auf die externe oder interne Kommunikation? Auf die Performance von Inhalten? Oder auch auf die tatsächliche Wirkung des Contents?
Diesen und anderen Frage gehen wir zusammen mit der Berliner School for Communication and Management (SCM) auf den Grund.Dafür haben wir gemeinsam eineOnline-Umfrage mit insgesamt 10 Fragenerarbeitet, an der Sie sich schon bald beteiligen können. Wir sind gespannt auf Ihre Rückmeldungen – und informieren Sie selbstverständlich an dieser Stelle, sobald die Umfrage veröffentlich wird. Deshalb:Stay tuned!
