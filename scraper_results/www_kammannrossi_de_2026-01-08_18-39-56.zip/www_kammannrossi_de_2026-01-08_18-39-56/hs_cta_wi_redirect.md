---
url: https://www.kammannrossi.de/hs/cta/wi/redirect?encryptedPayload=AVxigLKiWh8X2jq9aIHvT5kSCzxlu2zbEjxi6Ab7bP6UmLR0iZTzPPAiOvwnWhri0qnn9HPlDWC%2B%2BWTsuKeyG%2F7wKVkaeSHLAQZfZNwBJKK5Pq51d4qzA%2FBaqV%2F1OqduencoolIA9S%2Fxls%2BRQhEIrqwSqFWWRFoybVi6EG0wKIO1WoG53ZPFUGo2WIbj8X%2FwZ898%2FRFkDM3fPbA%3D&webInteractiveContentId=105705854414&portalId=371798
scraped_at: 2026-01-08 18:39
title: AssistantOS Demo mit Carsten Rossi
---

# AssistantOS Demo mit Carsten Rossi

Choose time
Your info
Choose time

## AssistantOS Demo mit Carsten Rossi


### January 2026

Sun

###### Sun

Mon

###### Mon

Tue

###### Tue

Wed

###### Wed

Thu

###### Thu

Fri

###### Fri

Sat

###### Sat

28
29
30
31
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
1
2
3
4
5
6
7

##### How long do you need?


##### What time works best?

Showing times forJanuary 9, 2026
- UTC +01:00 (Europe) Central European Time
