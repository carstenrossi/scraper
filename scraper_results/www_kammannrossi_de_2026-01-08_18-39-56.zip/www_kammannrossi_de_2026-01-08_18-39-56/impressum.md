---
url: https://www.kammannrossi.de/impressum
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Impressum
---

# Kammann Rossi – Impressum


# Impressum


#### Kammann Rossi

Niehler Straße 10450733 KölnDeutschland
+49-221-976541-0info@kammannrossi.de
GeschäftsführungDr.-Ing. Christian Fill, Viola Kirchhoefer, Carsten Rossi
HandelsregisterHRB 69226 Köln
Umsatzsteuer­identifikationsnummerDE 122 800 970
DisclaimerKammann Rossi ist nicht verantwortlich für die Inhalte externer Internetseiten.
Carsten Rossi ist persönlich Verantwortlicher für diese Internetseite im Sinne des DDG.
Dieses Impressum gilt sowohl für den Internetauftritt www.kammannrossi.de, als auch für die Social-Media-Präsenzen von Kammann Rossi auf Facebook, Instagram, Twitter, YoutTube, Instagram, Vimeo, Xing und Linkedin.
Urheber- und KennzeichenrechtKammann Rossi ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Fotos, Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihr selbst erstellte Fotos, Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Fotos, Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen. Alle innerhalb des Internetangebotes genannten und ggf. durch Dritte geschützten Marken- und Warenzeichen unterliegen uneingeschränkt den Bestimmungen des jeweils gültigen Kennzeichenrechts und mithin den Besitzrechten der jeweiligen eingetragenen Eigentümer. Allein aufgrund der bloßen Nennung ist nicht der Schluss zu ziehen, dass Markenzeichen nicht durch Rechte Dritter geschützt sind. Das Copyright für veröffentlichte, von Kammann Rossi selbst erstellte Objekte bleibt allein bei Kammann Rossi. Eine Vervielfältigung oder Verwendung solcher Fotos, Grafiken, Tondokumente, Videosequenzen und Texte in anderen elektronischen oder gedruckten Publikationen ist ohne ausdrückliche Zustimmung von Kammann Rossi nicht gestattet
