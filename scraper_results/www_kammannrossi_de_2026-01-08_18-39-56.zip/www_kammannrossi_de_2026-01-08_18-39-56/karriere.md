---
url: https://www.kammannrossi.de/karriere
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Karriere
---

# Kammann Rossi – Karriere

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

# KARRIERE@KR


## /Wir suchen Dich!

Offenheit, Klarheit, Mut und kritisches Denken – all das zeichnet Dich aus. Mit diesen Eigenschaften, Deiner ausgeprägten Neugier und Deinem Willen, Ideen in die Tat umzusetzen, erwarten Dich bei Kammann Rossi viele Chancen, Deine Begabungen unter Beweis zu stellen. Sei es in der Redaktion, im Design oder im Projektmanagement.

### Initiativbewerbung

Meinst du, du passt zu uns, aber es gibt gerade keine passende Stelle? Schreib uns trotzdem! Frischen Wind im Team können wir immer gebrauchen – und wer weiß, schon manch eine Stelle bei uns wurde explizit für ein Teammitglied erschaffen. Warum nicht auch für Dich? Wir freuen uns in jedem Fall, von dir zu hören.

### Wir bieten Dir kreativen Raum für Deine Talente. Bewirb Dich jetzt!

Dass Du Deinen Job verstehst, setzen wir voraus. Darum keine lange „Was-Sie-bei-uns-erwartet-und-was-wir-von-Ihnen erwarten-Litanei. Schluss. Wir suchen Kolleg*innen, die etwas können, einfach sehr nett sind und keine Streber mit tausend Zertifikaten. Was wir sonst noch bieten außer wirklich tollen Projekten, netten Kunden und Kolleg*innen? Das hier zum Beispiel:

#### Du bist Dein Chef!

KR sucht keine Stundenabsitzer, sondern Kolleg*innen, die es schätzen, ihre Arbeitszeit selbst einzuteilen, denn die Projektteams von KR organisieren sich selbstständig. Das heißt: Deine Wochenarbeitszeit beträgt 38 Stunden und die Kernarbeitszeit ist von 10 bis 16 Uhr, daran wird nicht gerüttelt. Wenn es Tage gibt, an denen wenig zu tun ist, mach‘ früher Feierabend. Wenn ein Projekt länger dauert, häng‘ eine Stunde dran oder fang früher an. Aber um spätestens 18 Uhr ist Schicht!

#### Dein Büro? Auf Wunsch daheim!

Kammann Rossi predigt nicht nur digital first, sondern arbeitet auch so, nämlich via Microsoft Teams. Mit anderen Worten: Digital ist alles möglich, denn Du entscheidest, ob Du daheim arbeitest, im Workspace oder – solltest Du aus Köln und Umgebung kommen – auch im Office in Köln. Das hat viele Vorteile, denn wenn Du Dich um Deine Familie, Deinen Partner oder Deine Eltern kümmern musst, kannst Du trotzdem mit netten Kolleg*innen an tollen Projekten zusammenarbeiten.

#### Von A nach B? Ganz grün!

Kammann Rossi macht nicht nur viele Nachhaltigkeitsberichte für Unternehmen, sondern gibt auch selbst einen solchen heraus. Darin erklären wir, was für uns Nachhaltigkeit bedeutet. Das ist nicht nur clever, sondern auch ganz weit vorne. Genauso wie unser Angebot, dass Du zum Beispiel kostenlos mit einem Job-Ticket von A nach B fahren kannst (gilt für den Hauptsitz in Köln).

#### Wir suchen keine Einzelkämpfer. Weil wir ein Team sind!

Und weil wir ein Team sind, lassen wir Dich nicht im Regen stehen, sondern nehmen Dich von Anfang an mit. Damit das einfacher ist, bekommst Du einen Paten oder eine Patin, die Dir in den ersten Wochen mit Rat und Tat zur Verfügung steht und all Deine Fragen beantwortet, damit Du ohne Stress durchstarten kannst.

#### Et Trömmelche? Wenn Du magst mit dreifach Kölle alaaf!

Kammann Rossi gibt es seit 50 Jahren und die Agentur hat die kölsche DNA. Das bedeutet aber nicht, dass wir hier den ganzen Tag mit der Pappnase herumlaufen. Aber die meisten von uns mögen den Karneval. Rosenmontag ist Feiertag für alle – egal, ob Du feiern magst oder nicht. Und als weltoffene Kölner*innen nehmen wir Dich so, wie Du bist – Hauptsache nett und kompetent.
P.S.: Sogar Münchner oder andere Außerirdische fühlen sich bei uns wohl (solange sie nicht über Fußball reden).
„Über Kammann Rossi
Wir sind eine der ältesten inhabergeführten Agenturen Deutschlands. Seit 1972 betreuen wir von Köln und Berlin und München aus mit 25 Mitarbeitern internationale Konzerne und mittelständische Unternehmen aus der DACH-Region. Zu unseren Kunden gehören zurzeit u. a. ARAG, Clariant, Continental, Daiichi Sankyo, Deutsche Bahn, Faber-Castell, GTAI, Lidl Schweiz, Liebherr, NRW.Bank, OLB, REWE, Storck, Telefónica und Thalia. Mit begeisternden Inhalten in Magazinen, Content Hubs und auf Social Media helfen wir diesen Unternehmen, ihre Ziele zu erreichen.
Unsere Agentur bietet alle Dienstleistungen, die nötig sind für die erfolgreicheUnternehmenskommunikation. Unsere Spezialgebiete sindInterne Kommunikation,Content MarketingundReporting. Wir beraten, konzipieren, schreiben, gestalten, filmen, zeichnen auf, organisieren, produzieren und promoten. Unsere besondere Leidenschaft gilt unter dem Motto#welovemagsdigitalen und analogen Magazinen und Content Hubs– egal auf welcher Plattform.
Unser Motto ist:Content drives action. Otherwise it's poetry.
