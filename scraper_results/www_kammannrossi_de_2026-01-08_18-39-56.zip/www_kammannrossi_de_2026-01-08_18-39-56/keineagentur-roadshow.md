---
url: https://www.kammannrossi.de/keineagentur-roadshow
scraped_at: 2026-01-08 18:39
title: Die KI-Roadshow für Kommunikator*innen
---

# Die KI-Roadshow für Kommunikator*innen

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### KI@kr


# #keineagentur


## /Die KI-Roadshow für Kommunikator*innen

In intensiven 2-Stunden-Workshops zeigen wir Ihnen, wie Sie generativen KI - von Sprach- bis zu Bild- und Videomodellen - für Ihren Alltag in der Kommunikation nutzen können. Nicht mit PowerPoint, sondern hands-on. Nicht mit Standard-Prompts, sondern mit echtem Kommunikations-Know-how. Nicht theoretisch, sondern ganz praktisch in unserer eigenen KI-Umgebung "AssistantOS" - mit Zugang zu den besten kreativen KI-Tools. Melden Sie sich unten im Formular an und wir schicken Ihnen alle weiteren Infos. Als nächstes treffen wir uns in Berlin am 1. April 2025.

### Das interessiert mich sehr und ich bin gerne dabei!


### Was Sie u.a. lernen:

- Wie Sie KI dazu bringen, nicht mehr peinlich zu klingen sondern in Ihrem persönlichen Stil zu schreiben
- Wie Sie Ihr Unternehmenswissen clever in Ihre KI-Prompts einbauen.
- Welche KI-Tools sich für welche Kommunikationsaufgaben eignen
- Wie Sie KI in Ihren täglichen Workflow integrieren

### Aktuelle Termine:

Die nächsten Termine sind der1.4. in Berlinund der29.4. in München.

### Warum #keineagentur?

Weil wir zwar eine Agentur sind - Kammann Rossi gibt es seit mehr als 50 Jahren - aber auch davon überzeugt, dass sich unsere Rolle verändern wird. Die Zukunft der Content Creation liegt bei den Inhouse-Teams, die KI clever für sich arbeiten lassen. Agenturen werden immer weniger produzieren, sondern ihre Kunden mit der richtigen Technologie und kreativen Beratung dabei unterstützen, selber die besten Ergebnisse zu kreieren. Wir nennen das "Service as a Software".
Der Workshop ist auf 10 Teilnehmer begrenzt, damit wir wirklich ins Detail gehen können. Er richtet sich vor allem Anfänger und "Ersttäter*innen", die bisher öffentliche Tools wie ChatGPT genutzt haben. Die Teilnahme ist kostenfrei, aber nicht umsonst - Sie werden danachauf jeden Fall bessere Ergebnisse erzielen.
PS: Und ja, natürlich nutzen wir für die Workshops unsere eigene KI-Umgebung AssistantOS. Aber keine Sorge: Dies ist kein Verkaufsevent. Versprochen. 🤞
PPS: Nach dem Workshop laden wir Sie zu einem kleinen Networking-Imbiss ein. Denn eines kann KI (noch) nicht: gemeinsam mit Ihnen Kaffee trinken ☕️"
