---
url: https://www.kammannrossi.de/pagestrip-agentur
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Know-How – Kammann Rossi nutzt pagestrip
---

# Kammann Rossi – Know-How – Kammann Rossi nutzt pagestrip

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### KNOW-HOW@KR


# Technologie


## /pagestrip

vonFlorian Stürmer| 29.08.2022 |
Schnelleinstieg
- Pagestrip und Kammann Rossi
- Warum pagestrip?
- Wofür kann ich pagestrip nutzen?
- Was macht pagestrip besonders?
- Projekte
- Die wichtigsten Features
- Unsere Leistungen für Sie
- Kontaktformular
Schnelleinstieg
- Pagestrip und Kammann Rossi
- Warum pagestrip?
- Wofür kann ich pagestrip nutzen?
- Was macht pagestrip besonders?
- Projekte
- Die wichtigsten Features
- Unsere Leistungen für Sie
- Kontaktformular

#### pagestrip und Kammann Rossi

Seit 2021 nutzt Kammann Rossi die Publishing-Lösung pagestrip. Warum? Weil wird mit pagestrip völlig frei gestalten, die Inhalte modern aufbereiten und direkt veröffentlichen können. Wir können in pagestrip Ihre vorhandenen Print-Inhalte importieren und mit Links, Videos, animierten Grafiken oder externem Content anreichern. Die Seiten können sowohl Eigenständig als auch eingebettet werden. Das Einbetten in eine bestehende Seite funktioniert"so leicht wie der Upload eines YouTube-Videos", verspricht pagestrip-GründerGeorg Kaindl. Auch externe Tools wie z.B. Tracking oder Consent-Management-Plattformen können eingebunden werden.
Die Software wurde von unserem Partner der Wiener Agentur Alice Interactive entwickelt um Magazine, Berichte, Präsentationen oder Microsites zu veröffentlichen.

#### Warum pagestrip?

Die Software pagestrip hilft uns, sämtliche Inhalte unkompliziert digital zu publishen. Jederzeit – auf Knopfdruck. Wir als Agentur haben somit absolute Designfreiheit, wir gestalten nach dem Prinzip:What you see is what you get!Sobald die Inhalte bereit sind, veröffentlichen wir diese direkt aus pagestrip heraus ins Web. Und mit dem Direct Embedding können wir Inhalte nahtlos in bestehende Unternehmenswebsites integrieren.

#### Wofür kann ich pagestrip nutzen?

- Kundenmagazine voller Multimedia und Calls-to-action
- Mitarbeitermagazine, die wirklich alle erreichen
- Geschäftsberichte mit großartigem Storytelling
- Nachhaltigkeitsberichte, die glaubwürdig und übersichtlich sind
- Landing Pages, die wirklich konvertieren
- Content Hubs, die am Desktop und mobil funktionieren

#### Was macht pagestrip besonders?

- InDesign Vorlage nutzen, IDML Assets importieren und für Web gestalten
- Automatische Konvertierung aller Schriften und Bilder auf ein webgerechtes Format
- Erstellen von eigenen oder Einsatz von vorhandenen Templates
- Ohne Probleme Corporate Identity des Unternehmens erhalten
- Nahtloses Integrieren von Videos, Slideshows, Animationen, Eventbrite Widgets uvm
- WYSIWYG arbeiten für mehr Spaß beim Gestalten

#### Projekte

Bereits erfolgreich umgesetzte Projekte mit der Software pagestrip.
- ARAG Konzern – Konzernmagazin "ARAG InSight"
- Telefónica Deutschland Holding AG – Mitarbeitermagazin "CSS Aktuell"
- August Stork KG – Mitarbeitermagazin "Wir von Storck"
- Bundesanstalt für Immobilienaufgaben – Mitarbeitermagazin "BImAg"
- Jungheinrich AG – Mitarbeitermagazin "YELLOW PRESS"
- Handelsunternehmen – Nachhaltigskeitbericht 2021
- Oldenburgische Landesbank AG –Online Geschäftsbericht 2021
- Oldenburgische Landesbank AG –Online Geschäftsbericht 2022
- Continental AG –Flashback 2025AD
- August Stork KG –Informationsplattform zur Betriebserweiterung Halle
- ARAG Konzern – Plattform zur neuen ARAG Nachhaltigkeisstrategie

#### Die wichtigsten Features

- Datenschutzkonform
- einzigartige native Embed Möglichkeit
- geringer Aufwand auf Seiten der Kunden IT
- individuelle Gestaltungsmöglichkeiten
- Funktionen wie Slideshows, Animationen, Videos, und vieles mehr
- Einbettung von externem Content möglich
- Content kann antizyklisch veröffentlicht werden
- Import von InDesign-Dateien

#### Unsere Leistungen für Sie

Wir sorgen für den digitalen Erfolg Ihres Print-Produktes, durch:
- Beratung
- Konzeption
- Content-Erstellung
- Umsetzung
Melden Sie sich gerne über das untenstehende Formular.

### Kontaktformular

