---
url: https://www.kammannrossi.de/projekt_arag-geschäfts-und-sfcr-berichte-2017
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – ARAG / Geschäfts- und SFCR-Berichte 2017
---

# Kammann Rossi – Projekt – ARAG / Geschäfts- und SFCR-Berichte 2017

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# ARAG


## /Geschäfts- und SFCR-Berichte 2017

Der ARAG Konzern ist das größte Familienunternehmen in der deutschen Assekuranz und zählt zu den drei weltweit führenden Rechtsschutzanbietern. Der Konzern sichert Risiken ab und wappnet seine Versicherungsnehmer so für das Abenteuer Leben. Für die ARAG konzipiert und realisiert Kammann Rossi bereits seit 18 Jahren die Geschäftsberichte der Gesellschaften.

### Beschreibung

Der Geschäftsbericht der ARAG erscheint jedes Jahr in sieben deutschen und in drei englischen Sprachversionen für die unterschiedlichen Gesellschaften. Zusätzlich realisiert Kammann Rossi die fünf deutschen und drei englischen SFCR-Berichte des Konzerns. Die Berichte erscheinen als Blätter-PDFs und stehen als PDF-Download zur Verfügung. Gedruckt werden der deutsche und englische Geschäftsbericht des Konzerns sowie die Einzelabschlüsse der ARAG Holding SE und AFI Verwaltungs-Gesellschaft mbH.

### Erfolg

Um die Anzahl der Berichte in stetig knapper werdenden Zeiträumen effizient realisieren zu können, entwickelte Kammann Rossi gemeinsam mit der ARAG einen Workflow, der den Verantwortlichen die redaktionelle Erstellung im Redaktionssystem Woodwing ermöglicht und damit den Prozess deutlich vereinfacht. Durch den Workflow und die enge Zusammenarbeit bei der Erstellung der Berichte werden für die unterschiedlichen Gesellschaften die 13 deutschen Berichte und etwas zeitlich versetzt die 6 englischen Berichte parallel produziert. Außerdem wurden die Geschäftsberichte der ARAG mehrfach mit internationalen Awards, darunter dem LACP Vision Award für internationale Finanzberichterstattung, ausgezeichnet.
