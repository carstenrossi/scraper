---
url: https://www.kammannrossi.de/projekt_arag-insight
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – ARAG / Konzernmagazin
---

# Kammann Rossi – Projekt – ARAG / Konzernmagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# ARAG


## /Konzernmagazin


### Der Kunde und das Projekt

Die ARAG wurde 1935 als reine Rechtsschutzversicherung gegründet. Heute gilt sie als größter deutscher Versicherungskonzern in Familienbesitz und als größter Rechtsschutzversicherer weltweit. Das Unternehmen ist in 19 Ländern aktiv und setzt bei seiner Kommunikation auf ein zweisprachiges Konzernmagazin. Dreimal jährlich informiert die ARAG so ihre Mitarbeiter:innen und Stakeholder über alle wichtigen Entwicklungen in Konzern und Versicherungsbranche.

### Das zugrundeliegende Konzept

2022 konzipierte Kammann Rossi das ARAG Konzernmagazin im Zuge eines Relaunchs neu. Das Ergebnis ist ein hochwertiges Printmagazin mit Wendecover, das auf frische Formate, klare Rubriken und ein modernes Layout setzt. Um den veränderten Lesegewohnheiten seiner Leserschaft gerecht zu werden, erscheint ARAG InSight seit dem Relaunch erstmals auch als responsives Onlinemagazin (Made in pagestrip). Dieses bietet der ARAG Konzernkommunikation ohne großen Mehraufwand die Möglichkeit, an passender Stelle ergänzende Informationen auszuspielen – so etwa zusätzliche Artikel, Bildergalerien, Links sowie Videos.Das digitale ARAG Konzernmagazin finden Sie hier:www.arag-insight.com

### Die Zusammenarbeit

Kammann Rossi und ARAG arbeiten im Bereich der Pflichtberichterstattung bereits seit vielen Jahren gut zusammen. Bei der Entstehung des Konzernmagazins unterstützt Kammann Rossi nicht nur bei der Heftkonzeption und -gestaltung, sondern auch bei Projektmanagement und Produktion.

### Der gemeinsame Erfolg

Das Konzernmagazin der ARAG wurde durch den Relaunch fit für die Zukunft gemacht. Das moderne Konzept von Print- und Onlinemagazin unterstützt die ARAG Konzernkommunikation dabei, relevante Themen informativ, unterhaltsam und übersichtlich aufzubereiten. Dafür kommt ein individueller visueller und redaktioneller Formate-Baukasten zum Einsatz, der dafür sorgt, dass ARAG InSight einen hohen Wiedererkennungswert hat und so in der internationalen Kommunikation mit Mitarbeiter:innen und Stakeholdern auf die Marke ARAG einzahlt.
