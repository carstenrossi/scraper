---
url: https://www.kammannrossi.de/projekt_arag-nachhaltigkeitsbericht-2017
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – ARAG / Nachhaltigkeitsbericht 2017
---

# Kammann Rossi – Projekt – ARAG / Nachhaltigkeitsbericht 2017

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# ARAG


## /Nachhaltigkeitsbericht 2017

Seit 2016 veröffentlicht die ARAG einen Nachhaltigkeitsbericht und dokumentiert damit, dass Unternehmergeist und soziales Bewusstsein stark miteinander verbunden sind.

### Beschreibung

Im unternehmenseigenen Nachhaltigkeitsbericht 2017 widmet sich die ARAG insbesondere dem Thema Chancengleichheit. Redaktionell bettet der Bericht die verschiedenen Aspekte von Chancengleichheit in den verschiedenen Kapiteln ein, lässt Experten sowie Mitarbeiter bei ARAG zum Thema zu Wort kommen und schlägt so die Brücke von der Chancengleichheit im Unternehmen über die Chancengleichheit bei Rechtsangelegenheiten für Kunden bis hin zum gesellschaftlichen Engagement der ARAG, bei der Chancengleichheit (z.B. kostenlose Rechtsberatung für gemeinnützige Organisationen durch ARAG-Mitarbeiter) einen hohen Stellenwert einnimmt.

### Erfolg

Der Nachhaltigkeitsbericht schärft extern das Profil der ARAG als nachhaltig orientiertes Familienunternehmen und informiert intern eine prioritäre Zielgruppe: die Mitarbeiter. Gleichzeitig dient die Nachhaltigkeitsberichterstattung der Reputation der Marke ARAG und evoziert die Attraktivität, die für die Rekrutierung von Talenten notwendig ist. Eine solch fundierte Nachhaltigkeitsberichterstattung steigert das Bewusstsein und die unternehmensinterne Aufmerksamkeit für Nachhaltigkeitsthemen, stößt Innovations- und Lernprozesse an und hilft, Nachhaltigkeitsthemen in die Strategie und Corporate Governance zu integrieren.
