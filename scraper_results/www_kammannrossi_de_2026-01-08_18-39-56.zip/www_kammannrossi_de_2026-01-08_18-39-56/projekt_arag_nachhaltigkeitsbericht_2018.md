---
url: https://www.kammannrossi.de/projekt_arag_nachhaltigkeitsbericht_2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – ARAG / Nachhaltigkeitsbericht 2018
---

# Kammann Rossi – Projekt – ARAG / Nachhaltigkeitsbericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# ARAG


## /Nachhaltigkeitsbericht 2018

Seit 2016 veröffentlicht die ARAG einen Nachhaltigkeitsbericht und dokumentiert damit, dass Unternehmergeist und soziales Bewusstsein stark miteinander verbunden sind. 2018 wurde der Nachhaltigkeitsbericht um ein separates Magazin rund um das Thema Cybermobbing erweitert.
Bei der Konzeption des Berichts 2018 wurde eine Contentstrategie entwickelt, die den Nachhaltigkeitsbericht zum Kommunikationsinstrument ausbaut: ARAG nutzt die Inhalte im Rahmen eines Content-Hubs für verschiedene Kanäle und schöpft so das Content-Potenzial maximal aus, um unterschiedliche Zielgruppen zu erreichen.
Insgesamt stehen gleich vier Medien im Fokus: Neben dem gedruckten Nachhaltigkeitsbericht entstand unter dem Titel „ARAG Spezial“ein separates Printmagazin. Es beleuchtet Cybermobbing aus unterschiedlichen Perspektiven in verschiedenen redaktionellen Formaten. Neben Erläuterungen und Standpunkten von Rechtsexperten enthält das Magazin Reportagen über den Mobbingalltag an deutschen Schulen und Interviews mit jungen Anti-Cybermobbing-Aktivisten. Mit dem Schwerpunktthema „Gegen Hass" dient das Magazin gleichzeitig als Informationsmaterial für Lehrer, Schulen und Medienvertreter.
Parallel wurden die Inhalte auf dem Portalaufgegriffen und fortgeführt. Gleiches gilt für die Inhalte aus dem Nachhaltigkeitsbericht, die auf dem Nachhaltigkeitsportalfortgeführt werden. So zahlen alle Inhalte aufeinander ein und die Chance wächst, dass sie von unterschiedlichen Zielgruppen gefunden werden.
Die ARAG realisiert ihren Nachhaltigkeitsbericht seit 2016 mit Kammann Rossi und dem internationalen Management-Beratungsexperten von Sustainserv auf Basis der Berichtstandards der Global Reporting Initiative (GRI).

### Erfolg

ARAG wollte einen Nachhaltigkeitsbericht mit viel Praxisbezug, denn Nachhaltigkeitsberichte fürs Archiv zu produzieren bringt weder den Stakeholdern noch dem Unternehmen selbst etwas. Die Nachhaltigkeitsleistung eines Unternehmens durch das Kerngeschäft muss klar herausgearbeitet und gezielt an die verschiedenen Zielgruppen kommuniziert werden. Die ARAG zeigt exemplarisch auf, wie dies durch die geschickte Verzahnung von Nachhaltigkeitsinformationen und passenden Geschichten gelingt.
