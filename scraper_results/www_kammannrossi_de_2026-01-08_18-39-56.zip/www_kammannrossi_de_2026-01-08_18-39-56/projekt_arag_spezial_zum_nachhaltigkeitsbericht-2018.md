---
url: https://www.kammannrossi.de/projekt_arag_spezial_zum_nachhaltigkeitsbericht-2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – ARAG / ARAG Spezial Nachhaltigkeitsbericht 2018
---

# Kammann Rossi – Projekt – ARAG / ARAG Spezial Nachhaltigkeitsbericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# ARAG


## /ARAG Spezial 2018

An deutschen Schulen erleben fast zwei Drittel aller Kinder und Jugendlichen Formen von Mobbing und Gewalt. Doch während Hänseleien früher offen auf dem Pausenhof und in der Klasse stattfanden, haben sich Streitereien und Beleidigungen im digitalen Zeitalter in die sozialen Medien verlagert. Eine Entwicklung, die weit über die Schulen hinaus zum gesamtgesellschaftlichen Problem geworden ist. Wie wehrt man sich gegen verbale Angriffe auf Facebook? Wie hält man sich den aggressiven Twitter-Kommentator vom Leib? Helfen juristische Schritte? Und braucht Deutschland vielmehr ein Persönlichkeitsrechtsschutzgesetz als ein umstrittenes Netzwerkdurchsetzungsgesetz (NetzDG)?
Der ARAG Nachhaltigkeitsbericht 2018 und das flankierende Magazin „ARAG Spezial“ setzt sich genau damit auseinander. Die Inhalte des Magazins beleuchten Cybermobbing aus unterschiedlichen Perspektiven in verschiedenen redaktionellen Formaten. Neben Erläuterungen und Standpunkten zum Beispiel von Rechtsexperten wie dem Leiter der Forschungsstelle IT-Recht und Netzpolitik an der Uni Passau, Prof. Dr. Dirk Heckmann, enthält das Magazin auch Reportagen über den Mobbing-Alltag an deutschen Schulen und Interviews mit jungen Anti-Cybermobbing-Aktivisten. Die Inhalte nutzte ARAG als Content-Hub für verschiedene Kanäle. Durch die Mehrfachverwertung schöpft das Versicherungsunternehmen das Potenzial von Content maximal aus und spricht damit verschiedene Zielgruppen an.

### Erfolg

ARAG wollte einen Nachhaltigkeitsbericht mit viel Praxisbezug, denn Nachhaltigkeitsberichte fürs Archiv zu produzieren bringt weder den Stakeholdern noch dem Unternehmen selbst etwas. Die Nachhaltigkeitsleistung eines Unternehmens durch das Kerngeschäft muss klar herausgearbeitet und gezielt an die verschiedenen Zielgruppen kommuniziert werden. Die ARAG zeigt exemplarisch auf, wie dies durch die geschickte Verzahnung von Nachhaltigkeitsinformationen und passenden Geschichten gelingt.
