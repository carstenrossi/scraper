---
url: https://www.kammannrossi.de/projekt_barmenia
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Barmenia / DIE HZ!
---

# Kammann Rossi – Projekt – Barmenia / DIE HZ!

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Barmenia


## /DIE HZ!


### Die Ausgangslage

Pünktlich zum 60-jährigen Jubiläum erschien 2022 das Mitarbeitermagazin „DIE HZ!“ der Barmenia in frischem Look, mit neuen Formaten und einem völlig neuen Storytelling-Ansatz. Realisiert wurde der Relaunch von Kammann Rossi in enger Zusammenarbeit mit der Kommunikationsabteilung der Barmenia. Die Barmenia ist eine eigenständige Versicherungsgruppe mit Sitz in Wuppertal. Zur Gruppe gehören die Barmenia Allgemeine Versicherungs-AG, die Barmenia Lebensversicherung a. G. und die Barmenia Krankenversicherung AG. Bundesweit beschäftigen die drei Unternehmen rund 4.300 Mitarbeiterinnen und Mitarbeiter.

### Herausforderung und Kommunikationsziel

Dem Auftrag ging ein mehrstufiger Pitch voraus, bei dem die Kölner IK- und HR-Spezialisten mit ihrem Konzept zur Neuausrichtung der Hauszeitung der Barmenia (darum „DIE HZ!“) überzeugen konnten. Durch den Relaunch wurde „DIE HZ!“ fit gemacht für die Zukunft: mit einem ganz neuen Themenmix und frischen redaktionellen Formaten. Zudem setzt das Konzept auf konsequentes Storytelling und orientiert sich somit nicht nur am Markenclaim des Wuppertaler Versicherers: „Einfach.Menschlich.", sondern auch an seinem Leistungsversprechen #MachenWirGern. Das Mitarbeitermagazin erscheint künftig dreimal pro Jahr mit einer Auflage von rund 4.000 Exemplaren.

### Realisierung und Zusammenarbeit

Für den Relaunch arbeitete bei der Barmenia und Kammann Rossi ein Kernteam zusammen – vom Kick-off im November bis zur ersten Ausgabe im Mai 2022. Nach einer umfassenden SWOT- und Wettbewerber-Analyse wurden in regelmäßigen Sprints die Entwicklungsphasen realisiert. Im neuen Konzept stehen die Mitarbeitenden klar im Fokus. Sie berichten in „DIE HZ!“ über ihre vielfältigen Aufgaben, Herausforderungen sowie ihr soziales und gesellschaftliches Engagement.
Auffallend ist, dass die Barmenia nach wie vor auf eine gedruckte Ausgabe setzt. Aus gutem Grund: „Unsere Leserumfrage hat gezeigt, dass der Großteil unserer Kolleginnen und Kollegen eine gedruckte Ausgabe als eine Wertschätzung sieht", betont Ingo Eiberg, Pressereferent und Chefredakteur „DIE HZ!". Hinzu kommt, dass „DIE HZ!“ auch an ehemalige Mitarbeitende verschickt wird, die Print ebenfalls schätzen.

### Zusammenarbeit und Erfolge

Mit dem Ergebnis des Relaunchs ist die Barmenia sehr zufrieden: „Auf das Ergebnis sind wir alle sehr stolz. Das Magazin ist frisch und kurzweilig. Das Durchblättern und Lesen macht Spaß“, betont Martina Cohrs, Abteilungsleiterin Presse und Vorstandsstab bei der Barmenia. Viola Kirchhhoefer, Geschäftsführerin bei Kammann Rossi ergänzt: „Die Zusammenarbeit mit den Kolleginnen und Kollegen bei der Barmenia war von Anfang an sehr konstruktiv und kollegial. Sehr hilfreich war dabei, dass wir auf Unternehmensseite mit versierten Kommunikationsprofis zusammenarbeiten dürfen, die offen für eine kritische, aber auch konstruktive Bestandsaufnahme sind.“
Apropos Bestandsaufnahme: Kammann Rossi bietet Unternehmen und Verantwortlichen für interne Kommunikation die Analyse interner Medien als Service an. Interessierte können zum Beispiel eine detaillierte Heftanalyse ihres Mitarbeitermagazins einfach bei Kammann Rossi anfordern unterwww.kammannrossi.de/review-mitarbeitermedien
