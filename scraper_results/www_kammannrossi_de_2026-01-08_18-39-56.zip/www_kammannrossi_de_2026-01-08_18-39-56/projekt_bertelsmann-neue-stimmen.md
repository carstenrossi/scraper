---
url: https://www.kammannrossi.de/projekt_bertelsmann-neue-stimmen
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Bertelsmann / Neue Stimmen
---

# Kammann Rossi – Projekt – Bertelsmann / Neue Stimmen

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Bertelsmann Stiftung


## /Neue Stimmen

Mit „Neue Stimmen“ eröffnet die Bertelsmann Stiftung jungen Gesangstalenten aus der ganzen Welt eine große Chance, ihren Traum von einer Zukunft im Opernbereich zu verwirklichen. Dabei sind der Wettbewerb und die Meisterkurse auf nachhaltige Karriereentwicklung ausgerichtet.

### Beschreibung

Kammann Rossi entwickelte zum Gesangswettbewerb 2015 das Onlinemagazin „Change Story“. Das Magazin sollte die Vielschichtigkeit von „Neue Stimmen“ vorstellen. Dafür wurde die Förderung der Mezzosopranistin Nadezhda Karyazina durch „Neue Stimmen“ von Anfang an begleitet, um mehr über die faszinierende Welt der Oper zu erfahren und darüber, was eine Karriereförderung für Sänger bedeutet.
Die Artikel des Magazins bieten informative Hinter-die-Szenen-Einblicke in verschiedene „Neue Stimmen“-Veranstaltungen durch Reportagen, Interviews, Filmsequenzen und Audiobeiträge.

### Erfolg

Das Onlinemagazin „Change Story“ bringt das Thema Oper und Nachwuchsförderung auf sehr persönliche und berührende Art und Weise der Öffentlichkeit nahe. Das Magazin schildert die Förderung aus der persönlichen Sicht einer Sängerin und ist damit ein wichtiger Projektbaustein geworden, über die „Neue Stimmen“-Arbeit der Bertelsmann Stiftung im Kulturbereich zu berichten.
