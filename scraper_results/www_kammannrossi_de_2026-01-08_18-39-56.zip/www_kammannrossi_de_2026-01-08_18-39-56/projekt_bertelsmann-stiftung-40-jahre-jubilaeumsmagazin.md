---
url: https://www.kammannrossi.de/projekt_bertelsmann-stiftung-40-jahre-jubilaeumsmagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Bertelsmann Stiftung - 40 Jahre Jubiläumsmagazin
---

# Kammann Rossi – Projekt – Bertelsmann Stiftung - 40 Jahre Jubiläumsmagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Bertelsmann Stiftung


## /Jubiläumsmagazin

Wie stellt man das Jubiläum einer der wichtigsten deutschen Stiftungen in den Mittelpunkt? Durch Storytelling – und ein Webmagazin, das hören, sehen und staunen lässt. Mit der Hilfe von Kammann Rossi.

### Beschreibung

Seit 40 Jahren engagiert sich die Bertelsmann Stiftung in Gütersloh  für eine breite gesellschaftliche Teilhabe aller Menschen. Unter dem Leitmotiv „Menschen bewegen. Zukunft gestalten.“ läutete die Stiftung das Jubiläumsjahr ein. Zum Auftakt erschien das Jubiläumsmagazin „40 Jahre Bertelsmann Stiftung“, das die Facetten und Bereiche der Stiftung durch ausgewähltes Storytelling in einem eigens von Kammann Rossi zusammen mit der Bertelsmann Stiftung dafür konzipierten Onlinemagazin vorstellte. Kennzeichnend für das Magazin: Es beleuchtet nicht nur historisches, sondern schlägt auch den Bogen zur Arbeit der Stiftung in der Gegenwart sowie zu ihren Forschungen in der Zukunft.

### Erfolg

Optisch und inhaltlich wurde das Magazin in enger Kooperation zwischen Kammann Rossi und der Bertelsmann Stiftung realisiert. Das „vielschichtige“ Webmagazin wurde in zehn Kapitel unterteilt, vom Bildungs- und Demokratie-Gedanken über Wirtschaft, Gesellschaft und Gesundheit bis hin zur Kultur. Dabei kommen ehemalige Mitarbeiter ebenso zu Wort wie die Mitglieder der Stifterfamilie. Jedes Kapitel enthält neben herausragenden Projekten Rich-Media-Elemente wie Videobeiträge, Interviews und weiterführende Informationen.
