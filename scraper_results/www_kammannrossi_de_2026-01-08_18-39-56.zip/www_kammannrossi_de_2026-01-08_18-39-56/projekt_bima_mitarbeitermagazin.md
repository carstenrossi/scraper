---
url: https://www.kammannrossi.de/projekt_bima_mitarbeitermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – BImA - Mitarbeitermagazin
---

# Kammann Rossi – Projekt – BImA - Mitarbeitermagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Bundesanstalt für Immobilienaufgaben


## /BImAg Das Magazin für die Beschäftigten der BImA


### Der Kunde und das Projekt

Im Zuge einer öffentlichen Ausschreibung überzeugte Kammann Rossi die Bundesanstalt für Immobilienaufgaben – kurz BImA – mit dem Konzept für den Relaunch des Beschäftigtenmagazins „BImAg“. Die BImA ist das zentrale Immobilienunternehmen des Bundes und verwaltet rund 19.000 Liegenschaften. Mit rund 460.000 Hektar Grundstücksfläche und 38.000 Wohnungen in ihrem Eigentum verfügt sie über ein vielfältiges Portfolio, zu dem neben den Büro-, Gewerbe- und Wohnimmobilien auch militärische und forstwirtschaftliche Areale gehören. Bundesweit arbeiten rund 7.000 Beschäftigte für die BImA. Teil der internen Kommunikation ist das Beschäftigtenmagazin „BImAg“.

### Das zugrundeliegende Konzept

Nach sieben Jahren war es an der Zeit, das grafische und redaktionelle Konzept des Magazins zu überarbeiten. Zusammen mit Kammann Rossi machte die BImA eine kritische Bestandsaufnahme und entschloss sich für einen visuellen Re-Start und neue redaktionelle Formate. Der bereits vor dem grafischen Relaunch eingeschlagene Weg des Storytellings wird mit dem Relaunch weiter verstärkt. Reportagen über die vielfältigen Aufgaben und Arbeitsbereiche bei der BImA wechseln sich mit Mitarbeiterporträts und Servicebeiträgen ab. Dabei setzt die BImA auf die Kombination von einem gedruckten und einem digitalen Magazin (Made in pagestrip).

### Die Zusammenarbeit

In die Umsetzung flossen neben den Ergebnissen einer BImA-interner Fokusgruppenumfrage auch Erkenntnisse der Studie „Die Zukunft der Mitarbeiterzeitung“ der Agentur mit ein, die für 2022 wieder neu aufgelegt und veröffentlicht wurde. Nach sieben Jahren war es an der Zeit, das grafische und redaktionelle Konzept des Magazins zu überarbeiten. Zusammen mit Kammann Rossi machte die BImA eine kritische Bestandsaufnahme und entschloss sich für einen visuellen Re-Start und neue redaktionelle Formate.

### Der gemeinsame Erfolg

> „Mit dem Ergebnis des Relaunches sind wir sehr zufrieden und wollen darauf aufbauend die redaktionellen Formate im Magazin sukzessive weiter ausbauen“,
„Mit dem Ergebnis des Relaunches sind wir sehr zufrieden und wollen darauf aufbauend die redaktionellen Formate im Magazin sukzessive weiter ausbauen“,
so BImAg-Chefredakteurin Elena Berhausen. Bereits die erste Ausgabe des BImAg punktete bei Kommunikationspreisen im DACH-Raum und wurde für die frische und moderne Umsetzung ausgezeichnet.
