---
url: https://www.kammannrossi.de/projekt_bima_podcast
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – BImA - Podcast
---

# Kammann Rossi – Projekt – BImA - Podcast

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Bundesanstalt für Immobilienaufgaben


## /Podcast


### Der Kunde und das Projekt

Der Podcast der Bundesanstalt für Immobilienaufgaben, kurz BImA, ist ein Instrument der internen Kommunikation. Zielgruppe sind die rund 7.000 Beschäftigten der BImA, die dezentral auf 120 Haupt- und Nebenstellen über die gesamte Bundesrepublik verstreut sind. Jeder Standort hat seine eigenen Aufgaben, Arbeitsweisen, Probleme, aber auch Innovationen und gute Ideen.

### Das zugrundeliegende Konzept

Die BImA geht mit ihrem Podcast auf Reise und begibt sich per „Work & Travel“ in die verschiedenen Standorte; Neugier und Entdeckertum sind im Reisegepäck mit dabei.Der Podcast fördert und stärkt den Wandel der BImA hin zu einer modernen, flexiblen und innovativen Behörde. Die Beschäftigten werden als aktive Mitgestalter ihrer beruflichen Entwicklung betrachtet. So soll das „Wir-Gefühl“ und die Zufriedenheit sowie die Identifikation der Beschäftigten mit dem Unternehmen gesteigert werden.

### Highlights und Zusammenarbeit

- Authentizität:Die Moderatoren des Podcasts reisen wirklich für jede Folge zu ihren Ansprechpartner:innen und dokumentieren ihre komplette Reise, von der Vorbereitung bis zum Revue-Passieren-lassen nach ihrer Rückkehr.
- Beschäftigte im Fokus: Der Podcast hebt einzelne Beschäftigte mit ihren Projekten und ihrem Standort in den Mittelpunkt.
- Regionale Vielfalt: Jede Folge konzentriert sich auf einen anderen Standort mit Tipps zu Sehenswürdigkeiten, Ausflugszielen oder Restaurants.
- Sammeln von 'Mitbringseln': ein „Mitbringsel“ jeder Folge wird in einem Rucksack gesammelt, der am Jahresende im Intranet verlost wird.
- Interaktive Elemente: Der Podcast wird ergänzt durch Bildergalerien und kurze Videos, Freizeit- und Ausgehtipps, die über das Intranet zugänglich sind.
Kammann Rossi unterstützt die BImA von der Konzeption bis zur Umsetzung des Podcasts. Dies schließt die Produktion der Inhalte und die Beratung bei der technischen Umsetzung mit ein.

### Der gemeinsame Erfolg

Der Podcast „Work&Travel“ ist von Anfang an ein Erfolg und erhält immer wieder positives Feedback.
Insgesamt erreicht eine Folge durchschnittlich 1.500-3.000 Aufrufe mit einer hohen Abschlussrate von 52 Prozent. Dies spricht für ein hohes Interesse an den Standorten und für die charmant und unterhaltsam geführten Gesprächen.
Außerdem haben sich bundesweit bereits zahlreiche Standorte als Gastgeber für eine Folge beworben.
Unterstützt wird die Einführung der neuen Staffel durch eine Auftaktfolge zum Konzept sowie eine kleine Kampagne: Poster, Intranet Artikel, gebrandete E-Mail-Signaturen oder Hinweise im Beschäftigtenmagazin machen auf den Podcast aufmerksam.
