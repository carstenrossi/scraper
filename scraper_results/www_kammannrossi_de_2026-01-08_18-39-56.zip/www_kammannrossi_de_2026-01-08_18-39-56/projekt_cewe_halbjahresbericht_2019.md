---
url: https://www.kammannrossi.de/projekt_cewe_halbjahresbericht_2019
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – CEWE / Halbjahresbericht 2019
---

# Kammann Rossi – Projekt – CEWE / Halbjahresbericht 2019

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# CEWE


## /Halbjahresbericht 2019

Die Geschichte von CEWE beginnt 1912 mit der Eröffnung eines kleinen Fotostudios in Oldenburg durch Carl Wöltje. CEWE als Unternehmen wurde 1961 von dessen Schwiegervater Senator h. c. Heinz Neumüller gegründet und 1993 als Aktiengesellschaft an die Börse gebracht.
Heute ist CEWE Europas führender Fotoservice und innovativer Online Druckpartner. Die CEWE Stiftung & Co. KGaA ist im SDAX gelistet und erzielte im Jahr 2018 einen Konzernumsatz von 653,3 Mio. Euro. Das CEWE FOTOBUCH als Bestseller im Produktportfolio ist das beliebteste Fotobuch Europas, von dem 2018 6,18 Mio. Exemplare ausgeliefert wurden.
Seit über 20 Jahren werden für CEWE neben den Geschäftsberichten auch die Quartalsberichte realisiert. Die Umsetzung des umfangreichen Geschäftsberichts erfolgt in einem komplexem Workflow, mit zeitgleicher Produktion beider Sprachfassungen innerhalb eines kurzen Zeitrahmens. Für die beiden Publikationen, Geschäfts- und Quartalsbericht, wurden die Gestaltungselemente wie Businessgrafiken und Typografie aneinander angepasst.
Hinzu kommt die inhaltliche wie gestalterische Realisierung des Nachhaltigkeitsberichts der CEWE Stiftung, die redaktionelle Texterstellung und die Umstellung auf Basis der GRI Standards. Durch Kennzahlen, Piktogramme, neue Businessgrafiken und Schaubilder, wurden dem Leser Hilfsmittel zur schnellen Erfassung relevanter Inhalte an die Hand gegeben.

### Erfolg

Verlässlichkeit, Vertrauen und gegenseitige Wertschätzung – diese Werte prägen die über 20-jährige Zusammenarbeit. Seit dem Börsengang verlässt sich Europas größter Foto-Entwickler und Fotobuch-Produzent zunächst bei seinen Finanzberichten, später auch in der Nachhaltigkeitsberichterstattung, auf unsere Expertise.
