---
url: https://www.kammannrossi.de/projekt_clariant-integrierter-bericht-2017
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2017
---

# Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2017

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Clariant AG


## /Integrierter Bericht 2017

Der Inhalt des Integrierten Berichts 2017 unter dem Motto „All in one“ speist sich aus den für Clariant wesentlichen Themen, wie sie in der unternehmenseigenen „Materialitätsmatrix“ dargestellt werden. Er stellt Zahlen und die handelnden beziehungsweise beteiligten Personen dahinter vor. Damit ist der Bericht auch ein hervorragender Fundus für interne und externe Kommunikationsaktivitäten. Zu den sieben wichtigsten Themen der Materialitätsmatrix wurden Reportagen mit und über Mitarbeiter von Clariantweltweitfür den Bericht entwickelt.

### Erfolg

96 Prozent mehr User besuchten den Onlinebericht im Vergleich zum Vorjahr, 36 Prozent davon waren Mitarbeiter von Clariant. Ein deutlicher Indikator dafür, dass ein solcher Bericht und das damit verbundene Storytelling einen hervorragenden Fundus für interne und externe Kommunikationsaktivitäten darstellen.
Seitdem wir den Clariant Geschäftsbericht betreuen, konnte er diverse Preise – IF, RedDot, DDC und BCM Awards – gewinnen. Darüber hinaus belegte er zweimal beim Schweizer Geschäftsberichte-Rating den ersten Platz.
