---
url: https://www.kammannrossi.de/projekt_clariant-integrierter-bericht-2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2018
---

# Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Clariant AG


## /Integrierter Bericht 2018

Clariant, ein weltweit führendes Spezialchemieunternehmen, kombiniert mit seinem Integrierten Bericht 2018 (IR) finanzielle und nicht finanzielle Elemente und ermöglicht so Transparenz in der Berichterstattung. Der Bericht informiert detailliert über das integrierte Geschäftsmodell – ein ganzheitlicher Ansatz, der Mehrwert für Kunden, Mitarbeiter, Aktionäre und die Umwelt schafft. Die Generierung von Mehrwert und der Nachweis von Nachhaltigkeitsstrategien erzeugen ein starkes und interessantes Spannungsfeld für die Kommunikation. Im positiven Fall wird daraus ein echter Dialog. Das gelingt im IR 2018 insbesondere durch den ausgeprägten Stakeholder-Fokus: Themen, die für den Erfolg von Clariant von zentraler Bedeutung sind – etwa Innovation und technologischer Fortschritt oder Produktverantwortung – werden anhand von Experten-Interviews aus interner und externer Perspektive betrachtet und erklärt. Die Interviews belegen die Interaktion zwischen Clariant und den Stakeholdern bei innovativen und nachhaltigen Lösungsansätzen. Das Motto „Asking Questions Is What Makes Us Better“ zieht sich stringent durch den IR und die Interviewfragen.

### Erfolg

