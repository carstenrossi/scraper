---
url: https://www.kammannrossi.de/projekt_clariant-integrierter-bericht-2019
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2019
---

# Kammann Rossi – Projekt – Clariant / Integrierter Bericht 2019

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Clariant AG


## /Integrierter Bericht 2019

Clariant, ein weltweit führendes Spezialchemieunternehmen, kombiniert mit seinem Integrierten Bericht 2019 (IR) finanzielle und nicht finanzielle Elemente und ermöglicht so Transparenz in der Berichterstattung. Der IR orientiert sich am Rahmenwerk des International Integrated Reporting Council (IIRC) und an den Berichterstattungsstandards für Nachhaltigkeit der Global Reporting Initiative (GRI). Als weiteren Schritt zur Steuerung des Unternehmens hat Clariant Geschäftsaktivitäten anhand der Nachhaltigkeitsziele der Vereinten Nationen (UN Sustainable Development Goals, SDGs) bewertet. „Indem wir darüber berichten, wie die Umsetzung unserer Strategie einen positiven Beitrag zu den SDGs leistet, wollen wir die Unterstützung und das Vertrauen all unserer Stakeholder weiter stärken", betont Hariolf Kottmann, Executive Chairman von Clariant.

### Erfolg

