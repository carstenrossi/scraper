---
url: https://www.kammannrossi.de/projekt_clariant_themoleculist
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Clariant - Corporate Blog
---

# Kammann Rossi – Projekt – Clariant - Corporate Blog

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Clariant


## /Corporate Blog „The Moleculist“


### Der Kunde und das Projekt

Clariant ist ein innovatives Spezialchemieunternehmen mit Sitz in Muttenz bei Basel in der Schweiz. Das Portfolio von Clariant ist für zukünftiges Wachstum optimiert und konzentriert sich auf drei Geschäftsbereiche: Care Chemicals, Catalysis und Natural Resources. Mit dem Corporate Blog „The Moleculist“ bietet Clariant im B2B-Bereich einen Deep-dive in die Welt der „großen Moleküle“. Nicht zuletzt, weil Clariant unter anderem Additive herstellt, die polymere Kunststoffe verbessern. Dabei sind Nachhaltigkeit und Innovation strategische Wachstumstreiber für das Unternehmen.

### Das zugrundeliegende Konzept

Durch interessante, aufschlussreiche, teilbare und inspirierende Inhalte erweckt der Blog die Innovationen von Clariant in der Chemie zum Leben. Der Blog steigert das Bewusstsein für die Innovationen, Produkte, Dienstleistungen und Kooperationen von Clariant, macht Wissenschaft und Chemie verständlich und zeigt die leidenschaftlichen Menschen hinter den Produkten und Dienstleistungen des Unternehmens. Im Blog kann Clariant nicht nur werbewirksam auftreten, sondern auch das Bewusstsein für die Marke des Unternehmens stärken. Zu den Zielgruppen des Blogs zählen die breitere Öffentlichkeit, Clariant-Mitarbeitende und Kunden, aber auch die Leserschaft des Integrierten Berichts, den Clariant jährlich veröffentlicht.

### Die Zusammenarbeit

Die redaktionelle Themenhoheit von „The Moleculist“ obliegt der Unternehmenskommunikation von Clariant. Die Aufgaben von Kammann Rossi bestehen in der redaktionellen Beratung des „The Moleculist“-Teams sowie der redaktionellen Umsetzung von Beiträgen in Teil- und Vollredaktion und der Zulieferung von Visuals und Fotos.

### Der gemeinsame Erfolg

„The Moleculist“ wurde 2020 lanciert. Pünktlich zum 25. Geburtstag von Clariant 2020. Zudem fiel der Start von „The Moleculist“ mit dem 100. Jahrestag eines Schlüsseldatums der Chemiegeschichte zusammen. Im Jahr 1920 begann der deutsche Chemiker Hermann Staudinger mit der Veröffentlichung seiner bahnbrechenden Arbeiten über Polymere und makro-molekulare Chemie, für die er später den Nobelpreis erhielt. Staudingers Arbeit der „großen Moleküle“ beeinflusste die Welt der Chemie nachhaltig und bildete das Geschäftsmodell für viele Unternehmen, darunter auch das von Clariant.
