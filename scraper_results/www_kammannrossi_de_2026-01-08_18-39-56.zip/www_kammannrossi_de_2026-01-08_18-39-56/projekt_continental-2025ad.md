---
url: https://www.kammannrossi.de/projekt_continental-2025ad
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Continental / 2025AD
---

# Kammann Rossi – Projekt – Continental / 2025AD

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Continental AG


## /2025 AD

Die Social-Media-Strategie von 2025AD zielte auf den Dialog und die Auseinandersetzung mit dem Thema automatisiertes Fahren. Eines der Hauptziele war es, die Akzeptanz hierfür zu fördern und einzigartige Erkenntnisse aus dem öffentlichen Diskurs zu generieren.

### Beschreibung

Die Social-Media-Präsenz von 2025 AD sollte einen Dialog zwischen allen Stakeholdern über das Thema „Automatisiertes Fahren“ ermöglichen und das Engagement in den definierten Zielgruppen fördern. Ziel war es, den Konsumenten das Thema näherzubringen und mehr Reichweite zu generieren. Darüber hinaus sollten im Dialog mit der Zielgruppe Erkenntnisse für Forschung und Entwicklung gewonnen werden.

### Erfolg

Durch kontinuierliches Community-Management sind treue Anhänger und Fans entstanden, die regelmäßig an Diskussionen teilnehmen und als Multiplikatoren fungieren. Im Rahmen der Engagement-Aktion „Xperience AD“ hatten Besucher des 2025AD-Messestandes auf der IAA 2017 die Möglichkeit, ihr automatisiertes Traumauto von Designern zeichnen zu lassen. Die Kampagne wird regelmäßig auf unterschiedlichen Konferenzen und Veranstaltungen platziert, um zu zeigen, wie und warum automatisiertes Fahren Content Marketing benötigt und wie wir unsere Strategie um das Thema herum gestalten.
Auf der IAA 2017 hatten Besucher die Möglichkeit, sich ihr automatisiertes Traumauto von Illustratoren des Fachbereichs Transportation Design der Hochschule Pforzheim zeichnen zu lassen. Die besten Entwürfe wurden in einer PDF Edition publiziert.
