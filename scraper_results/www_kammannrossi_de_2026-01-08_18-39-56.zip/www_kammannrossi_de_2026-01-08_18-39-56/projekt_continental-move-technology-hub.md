---
url: https://www.kammannrossi.de/projekt_continental-move-technology-hub
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Continental / move – the technology hub
---

# Kammann Rossi – Projekt – Continental / move – the technology hub

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Continental AG


## /move – the technology hub

Bis zum Launch von „move – the technology hub“ im März 2017 gab es bei Continental Automotive kein internes Medium, das sich speziell mit den technischen Themen auseinandergesetzt hat. „move“ schließt diese Lücke und richtet sich damit speziell an die Ingenieure und technisch Interessierten unter den Mitarbeitern.

### Beschreibung

„move“ ist nicht nur Informationsplattform, sondern will bewusst auch den Austausch und die Vernetzung unter den Usern fördern. Kommentare und Likes sind daher ein genauso elementarer Bestandteil wie die Möglichkeit, sich über die interne Collaboration-Plattform „ConNext“ zu vernetzen.
Neben Beiträgen zu einem bestimmten Thema finden die Mitarbeiter von Continental auf „move“ Dossiers. Diese leuchten ein Thema unter unterschiedlichsten Blickwinkeln aus und sind zielgerichtet auf die Informationsbedürfnisse von bestimmten Zielgruppen hin aufbereitet. Neben einem einleitenden Artikel enthält ein Dossier weitere Beiträge, die zeitversetzt ausgespielt werden und – nach drei bis vier Wochen – eine kompakte Themeneinheit ergeben.

### Erfolg

Als Special-Interest-Publikation schafft„move–thetechnologyhub“ es, die Zielgruppe mit detaillierten und fachspezifischen Inhalten zur versorgen, ohne die unterschiedlichen Informationsbedürfnisse der Zielgruppen zu vernachlässigen. Die Resonanz der Zielgruppe zeigt, dass das Konzept aufgeht: Beiträge in „move“ werden intensiv und häufig kommentiert und tragen damit innerhalb der Zielgruppezu themenbezogenenfachlichen Diskursen bei.
