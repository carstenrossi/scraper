---
url: https://www.kammannrossi.de/projekt_demire_halbjahresbericht_2019
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DEMIRE / Halbjahresbericht 2019
---

# Kammann Rossi – Projekt – DEMIRE / Halbjahresbericht 2019

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Demire


## /Halbjahresbericht 2019

Die DEMIRE Deutsche Mittelstand Real Estate AG hält Gewerbeimmobilien in mittelgroßen Städten und an aufstrebenden Randlagen von Ballungsgebieten in ganz Deutschland. Die Gesellschaft hat ihre besondere Stärke an diesen Sekundärstandorten und konzentriert sich auf ein Angebot von Büros, Einzelhandel und Logistik, das sowohl für international agierende als auch regional ansässige Mieter attraktiv ist.
Die Gesellschaft legt Wert auf langfristige Verträge mit solventen Mietern und rechnet daher mit stabilen und nachhaltigen Mieteinnahmen. Die Aktie der DEMIRE Deutsche Mittelstand Real Estate AG (ISIN: DE000A0XFSF0) ist im Prime Standard der Deutschen Börse in Frankfurt notiert.
Seit 2017 realisieren wir die Finanzberichte von DEMIRE und haben die Finanzberichterstattung einem vollständigen Relaunch unterzogen: Die Reporte erscheinen im Querformat, optimiert für Bildschirm- und Präsentationsansichten, und bieten damit ausreichend Raum auch für umfangreiche Tabellen. Eine lesefreundliche Typografie, ein adäquates Seitenlayout, intelligente Leselogistik und eigenständige Icons ergeben ein Werk auf der Höhe der Zeit. Inhaltlich führt die stringente Strukturierung anhand der Geschäftsbereiche durch die einzelnen Berichtsteile.

### Erfolg

Der Weg vom ersten Quartalsbericht (Q3 2017) bis zum aktuellen Geschäftsbericht war grafisch und inhaltlich ein Meilenstein für die DEMIRE, der durch Effizienz in der Umsetzung und transparente Arbeitsschritte, unter anderem durch den Einsatz des Redaktionssystems Woodwing, erfolgreich erreicht wurde.
