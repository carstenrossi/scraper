---
url: https://www.kammannrossi.de/projekt_deufol_halbjahresbericht_2019
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DEUFOL / Halbjahresbericht 2019
---

# Kammann Rossi – Projekt – DEUFOL / Halbjahresbericht 2019

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# DEUFOL


## /Halbjahresbericht 2019

Die Erfolgsgeschichte von Deufol beginnt 1979 mit der Übernahme der Dönne + Hellwig GmbH durch Detlef W. Hübner, dem Enkel des damaligen Firmengründers. Das bis dahin als Textilgroßhandel tätige Unternehmen entwickelte Detlef W. Hübner systematisch zu einem konkurrenzfähigen Spezialisten für Industrie- und Konsumgüterlogistik sowie Inhouse-Outsourcing – ein Konzept, das später auch markenrechtlich geschützt wurde. Heute gehört Deufol zu den Anbietern modernster Verpackungstechnologien und Supply-Chain-Lösungen und zählt zu den Innovationstreibern der Branche mit 91 Standorten weltweit.

### Erfolg

Seit 15 Jahren wird die Deufol SE von einem eingespielten Grafik- und Redaktionsteam betreut. In dieser Zeit sind Geschäftsberichte entstanden, die viele Preise und Auszeichnungen gewonnen haben – vom iF communication design award bis zu Platinum-Auszeichnungen bei LACP und ARC. Gemeinsam ist allen Projekten die konsequente Gestaltung aus dem Unternehmenskern heraus – und die Produktion im Redaktionssystem Woodwing, auf das alle Beteiligten Zugriff haben.
