---
url: https://www.kammannrossi.de/projekt_deutsche-bahn-echtklar
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DB Fernverkehr / echt:klar
---

# Kammann Rossi – Projekt – DB Fernverkehr / echt:klar

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Deutsche Bahn Fernverkehr


## /echt:klar


### Die Kurzbeschreibung

Alle wichtigen Informationen in einer App – ohne auf die spezifischen Informationen aus den Fachbereichen verzichten oder gar weitere Medien in die Hand nehmen zu müssen. Das ist echt:klar. Ganz unter dem Motto „Wir sprechen Fernverkehr“ versammelt echt:klar alles Wichtige zum Fernverkehr in einer App, bietet Dialog- und Response-Möglichkeiten. Zudem wurden nach und nach die Fachbereiche mit ihren Bereichs-Medien in die App integriert. So finden alle Mitarbeiter sowohl die allgemeinen Fernverkehrs-Themen als auch die für sie spezifischen Themen in einem Kanal. Und das nicht als irrelevanten „Einheitsbrei“, sondern nach einer klaren Content-Strategie, zugespitzt auf und relevant für die einzelnen Persoa. Das macht echt:klar besonders.

### Das Ausgangslage

Ein Kanal für bereichsübergreifende Informationen und gleichzeitig für die fachspezifischen Beiträge aus den Bereichen. Mit diesem Anspruch ging echt:klar im Juli 2018 an den Start. Nach und nach haben „Bordservice“, „Fahrplan und Verkehrsleitung“, „Bereitstellung und Instandhaltung“ sowie „Triebfahrzeugführer“ ihre Fachbereichskanäle in echt:klar integriert. Somit finden die Mitarbeiter des Fernverkehrs unter dem Motto „Wir sprechen Fernverkehr“ in der App (und als Desktopversion) nicht nur mehrmals pro Woche News und Hintergrundberichte zu den wichtigen Fernverkehrsthemen, sondern auch zu ihren spezifischen Fachbereichen – und das schneller als je zuvor. News umgehend und direkt, ausführliche Berichte in zeitlicher Nähe zum Geschehen.

### Die Problemstellung

Durch regelmäßige Umfragen wurde klar, dass das Konzept des ausgabenbasierten Magazins („echt:zeit“) mit bis zu 30 Artikeln pro Ausgabe nicht mehr funktionierte. Zudem war den Lesern nicht mehr vermittelbar, warum überhaupt zwei Kanäle für die bereichsübergreifende Mitarbeiterkommunikation notwendig waren, zumal die einzelnen Fachbereiche zusätzlich regelmäßig eigene Newsletter veröffentlichten. Es sollte ein einziger Kommunikations-Kanal geschaffen werden, der nicht nur die bereichsübergreifende Berichterstattung in sich vereinte, sondern auch die fachspezifischen Newsletter und Kanäle integrierte. So wird allen Mitarbeitern die Möglichkeit gegeben, nicht nur alle relevanten Informationen aus dem Unternehmen, sondern auch ihre ganz persönlichen fachspezifischen Themen in einem Kanal zu finden.

### Die Kommunikative Herausforderung und das Kommunikationsziel

Die große Herausforderung ist die heterogene Zusammensetzung der Mitarbeiter beim Fernverkehr sowie die Tatsache, dass ein Großteil der Mitarbeiter fast ausschließlich unterwegs arbeitet. echt:klar gibt Mitarbeitern einen umfassenden Überblick über die Geschehnisse beim Fernverkehr und hält sie zu Zielen und Strategien des Unternehmens auf dem Laufenden – immer mit dem Fokus auf die Auswirkungen dieser Ziele und Strategien auf das persönliche Arbeitsumfeld. Sie erfahren von Änderungen, neuen Projekten und besonders von den Veränderungen ihres Arbeitsalltags schnell, hintergründig und umfangreich. Die Mitarbeiter haben zudem die Möglichkeit, darüber zu diskutieren, ihre Meinung zu äußern und Fragen an die zuständigen Projekte zu stellen. Die Inhalte sind persönlich, spannend, transparent, aufklärend, kritisch und multiperspektivisch. Sie sollen alle Mitarbeiter erreichen und für diese persönlich einen Mehrwert bieten.

### Der Strategische Ansatz

Die aktuelle Transformation bei der Deutschen Bahn Fernverkehr verständlich und aktiv begleiten – das ist die strategische Vorgabe. Es mussten Antworten gefunden werden auf die Frage, welche strategischen, konzeptionellen und inhaltlichen Leitplanken notwendig wären, um alle Mitarbeiter gleichermaßen und langfristig für die „neue DB Fernverkehr“ zu motivieren und ihnen gleichzeitig die Möglichkeit gegeben werden, Feedback zu den wichtigen Themen zu geben und sie aktiv einzubinden. Die Lösung: echt:klar, ein speziell für die digitale Mitarbeiterkommunikation entwickelte App für Smartphones, Tablets und Computer. Zudem bekommen Mitarbeiter in ihren fachspezifischen integrierten Kanälen die Informationen nicht nur schneller und direkter, sie haben auch dort jetzt alle Möglichkeiten, über die Beiträge zu diskutieren und diese zu kommentieren.

### Die Zielgruppe

Zur Zielgruppe gehören mehr denn je alle Mitarbeiter der Deutschen Bahn Fernverkehr AG – bereichsübergreifend. Zur gezielteren Ansprache wurden die Mitarbeiter in unterschiedliche Persona-Gruppen geclustert: Triebfahrzeugführer, Mitarbeiter im Bordservice (Zugbegleiter und Bordgastronomen), Werker, Verkehrsleiter/Disponenten, Referenten, Führungskräfte. Die Themen sind zielgruppengerecht auf die Personas zugeschnitten und in den Beiträgen umgesetzt. Zugrundeliegende Fragen bei der Planung der Beiträge sind: Für welche Persona ist das Thema relevant? Und welcher Aspekt des Themas interessiert die jeweilige Persona?

### Die taktisch-operative Umsetung

Die Themen- und Beitragsplanung erfolgt über das Strategie- und Content- Planungssystem Scompler. Auf Basis einer zielgruppengerechten Content-Strategie werden mit dem Tool der Themenplan und Beitragsworkflow erstellt bzw. abgebildet. News berichten aktuell über die neuesten Geschehnisse, Hintergrundberichte (in allen journalistischen Stilformen) erscheinen dann, wenn alle wichtigen Fakten gesammelt sind. Fokusthemen, die einer eingehenden Betrachtung aus unterschiedlicher Perspektive bedürfen, werden in mehreren Beiträgen aufbereitet. Für die journalistische Aufbereitung werden auch Videofeatures, Bildergalerien und Infografiken genutzt. Die spezifischen Fachbereichs-News werden über integrierten Fachbereichs- Kanäle in der App ausgespielt. Mitarbeitern des jeweiligen Fachbereichs werden alle Neuigkeiten aus dem Fachbereichs-Kanal auf der echt:klar-Startseite angezeigt. Aber auch Kollegen aus den anderen Bereichen können die jeweiligen Fachbereichs-Kanäle abonnieren.
