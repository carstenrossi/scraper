---
url: https://www.kammannrossi.de/projekt_deutsche-bahn-echtzeit
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DB Fernverkehr echt:zeit – digitales Magazin für Mitarbeiter
---

# Kammann Rossi – Projekt – DB Fernverkehr echt:zeit – digitales Magazin für Mitarbeiter

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Deutsche Bahn Fernverkehr


## /echt:zeit

Mit der Strategie 2020 hat sich DB Fernverkehr ambitionierte Ziele gesetzt, um „neue Maßstäbe in der Mobilität“ auch in der Mitarbeiterkommunikation zu setzen. Um diese Ziele zu erreichen, war ein Kulturwandel im Kommunikationsweg nötig und ein Printmagazin kam somit nicht in Frage. Die Inhalte sollten persönlich, bewegend, spannend, transparent, aufklärend und multiperspektivisch sein.

### Beschreibung


### Erfolg

Mit „echt:zeit“ wurde bei der Deutschen Bahn ein kommunikativer Kulturwandel angestoßen, bei dem alle Mitarbeiter zu jeder Zeit und an jedem Ort erreicht werden und durch Taggen, Liken und vor allem Kommentieren mit ihren Kollegen in den Dialog treten können.
Die „echt:zeit“ wurde sowohl mit dem Fox Award in Gold als auch dem BCM Award in Gold ausgezeichnet.
