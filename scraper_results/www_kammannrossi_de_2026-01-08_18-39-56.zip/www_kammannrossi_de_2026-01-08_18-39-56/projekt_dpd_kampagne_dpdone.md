---
url: https://www.kammannrossi.de/projekt_dpd_kampagne_dpdone
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DPD – Kampagne zur Einführung von oneDPD
---

# Kammann Rossi – Projekt – DPD – Kampagne zur Einführung von oneDPD

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# DPD Deutschland


## /Kampagne zur Einführung von oneDPD


### Der Kunde und das Projekt

DPD Deutschland gehört zur internationalen Geopost, dem größten Paketnetzwerk Europas. Die Nummer zwei im deutschen Paketmarkt verfügt über 79 Depots und 7.700 Pickup Paketshops. Um seine rund 10.000 kaufmännischen und gewerblichen Mitarbeitenden auf dem Laufenden zu halten, setzt DPD Deutschland seit Frühjahr 2022 auf ein neues Social Intranet: oneDPD. Für die Einführung holte sich das Unternehmen Unterstützung von Telekom MMS – die für die begleitende Kommunikation zur Einführung wiederum den Support von ihrem Partner Kammann Rossi anfragte.

### Das zugrundeliegende Konzept

Im Herbst 2021 entwickelte Kammann Rossi nach Beauftragung durch Telekom MMS eine Kampagne für die Einführung von oneDPD. Das Ergebnis ist ein perfekt orchestrierter Kommunikationsmix, der Nutzen und Mehrwerte des neuen Intranets betont und alle verfügbaren Kanäle ideal nutzt. Neben klassischen Maßnahmen wie Postern und Flyern, setzen DPD und KR bei der Begleitkommunikation auch auf eine Sonderausgabe des Mitarbeitermagazins, ein Infopaket zur Führungskräftekommunikation, Promo-Videos sowie Digital Signage. Ein frischer Look, eine universelle Bildsprache und eine starke Emotionalität schaffen einen hohen Wiedererkennungswert – und sorgen so im Arbeitsalltag für die nötige Aufmerksamkeit.

### Die Zusammenarbeit

Die Kampagne zur Einführung von oneDPD war das erste gemeinsame Projekt von DPD Deutschland, Telekom MMS und Kammann Rossi. Weitere Projekte – wie etwa die Unterstützung bei der Change Kommunikation – schlossen sich an. Bei der Einführung von oneDPD übernahm Kammann Rossi die Kampagnenkonzeption und -gestaltung. Telekom MMS kümmerte sich um die technische Realisierung und Implementierung des neuen Intranets sowie die Koordination mit dem Softwareanbieter.

### Der gemeinsame Erfolg

Die Kampagne zur Einführung von oneDPD hat es geschafft, die sehr heterogenen Zielgruppe der Mitarbeiter von DPD Deutschland zu erreichen. Durch die Nutzung von universell verständlichen Emojis hat sie Sprachhürden überwunden und auch Nicht-Muttersprachlern die wichtigsten Botschaften mit großen Gefühlen und wenigen Worten vermittelt. Eine direkte Ansprache und der klare Fokus auf die Bedürfnisse der Mitarbeiter nahmen Ängste und erleichterten die Kommunikation auf Augenhöhe.
