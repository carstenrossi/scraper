---
url: https://www.kammannrossi.de/projekt_drsc_jahresbericht_2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – DRSC / Jahresbericht 2018
---

# Kammann Rossi – Projekt – DRSC / Jahresbericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# DRSC


## /Jahresbericht 2018

Seit fast 20 Jahren darf Kammann Rossi für das Deutsche Rechnungslegungs Standards Committee e.V. (DRSC) die Jahresberichte betreuen – jedes Jahr unter einem neuen Motto und mit spannenden redaktionellen Inhalten. So wurde 2017 unter dem Motto „Im Bilde“ für den DRSC ein bilingualer Jahresbericht umgesetzt, der sich illustrativ hervorhebt und einen umfassenden Einblick in die nationale und internationale Arbeit seiner Gremien bot.
2018 feierte der DRSC, das auf europäischer Ebene die Interessen der deutschen Wirtschaft im Bereich der Rechnungslegung vertritt, sein 20-jähriges Bestehen. Der Jahresbericht 2019 präsentierte die Meilensteine der Arbeit in einer Expedition unter dem Motto „20 Jahre durch Raum und Zeit“ und hob Highlights des Vereins und ihre Bedeutung für den internationalen Finanzkosmos hervor.

### Erfolg

Mit seinen Berichten gibt der DRSC einen umfassenden Einblick in die nationale und internationale Arbeit seiner Gremien. KR ist stolz darauf, das spannende Themenfeld konzeptionell und redaktionell bearbeiten zu dürfen. Eine Auszeichnung dieser Arbeit war der Galaxy Award in Gold, den der DRSC Jahresbericht 2017 in der Kategorie „Annual Reports – Print: Non-Profit Organization” erhielt. Der Galaxy Award zählt zu den bedeutendsten internationalen Preisen im Bereich der Marketingkommunikation. Ausgezeichnet werden Projekte, die in Kreativität, Klarheit, Effektivität und Innovation besonders herausragen.
