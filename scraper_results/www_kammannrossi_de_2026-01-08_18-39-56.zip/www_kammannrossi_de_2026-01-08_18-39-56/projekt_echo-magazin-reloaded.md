---
url: https://www.kammannrossi.de/projekt_echo-magazin-reloaded
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – REWE / ECHO! Magazin Reloaded
---

# Kammann Rossi – Projekt – REWE / ECHO! Magazin Reloaded

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# REWE


## /ECHO! Magazin Reloaded


### 360-Grad-Relaunch für eines der traditionsreichsten Mitarbeitermagazine Deutschlands

ECHO! ist seit über 70 Jahren das wichtigste Instrument der internen Kommunikation von REWE. Es erscheint monatlich mit einer Auflage von knapp 37.000 Exemplaren und erreicht rund 34.000 Mitarbeiter:innen, davon 1.800 Kaufleute sowie Lieferanten und Produktionsbetriebe. An der gedruckten Ausgabe wird auch künftig festgehalten, denn REWE ist überzeugt davon, dass ein Print Mitarbeitermagazin auch in Zukunft nicht an Bedeutung verliert.

### Kammann Rossi 360 Grad Abo

Sie interessieren sich für unser Abo? Schreiben Sie uns und wir setzen uns umgehend mit Ihnen in Verbindung.
ZUM FORMULAR

### Herausforderung und Kommunikationsziel

Die Aufgabe von KR: Nach sieben Jahren war es Zeit – Zeit, das ECHO! kritisch zu betrachten und neu zu denken. Das ECHO! sollte durch den Relaunch fit für die Zukunft gemacht werden. Mit einem neuen Themenmix sowie einer Aufbereitung, die die REWEMitarbeiter:innen der Printausgabe auch digital bewegen.

### Realisierung und Zusammenarbeit

Für den Relaunch wurde bei REWE ein Kernteam gegründet, das mit einem interdisziplinären Team bei KR den ECHO!-Relaunch vom ersten Kick-off im Mai 2020 bis zur ersten Ausgabe vom ECHO! nach dem Relaunch im März 2021 zusammenarbeitete.Nach einer intensiven SWOT- und Wettbewerber-Analyse wurden in wöchentlichen Sprints – parallel zur regulären ECHO!-Produktion – die Entwicklungsphasen realisiert, angefangen bei der gemeinsamen Konzeptentwicklung mit neuen Rubriken, neuen Formaten und einem ganz neuen Heftrhythmus mit einem gestärkten Regionalteil, bis hin zu einer groß angelegten Marktforschung mit Testseiten für die Beurteilung durch Leser:innen.Rund ein Jahr hat das REWE+KR-Team am Relaunch zusammengearbeitet. Herausgekommen ist nicht nur ein neues Mitarbeitermagazin, sondern auch ein Online-Magazin mit ausgewählten Inhalten für alle digitalen Endgeräte. So kann das ECHO! in Zukunft ganz flexibel gelesen werden – wann und wo die Mitarbeiter:innen wollen.
