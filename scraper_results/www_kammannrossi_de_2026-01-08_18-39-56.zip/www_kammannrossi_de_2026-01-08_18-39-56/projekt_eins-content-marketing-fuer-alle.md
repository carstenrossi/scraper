---
url: https://www.kammannrossi.de/projekt_eins-content-marketing-fuer-alle
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Eins / Content Marketing für Alle
---

# Kammann Rossi – Projekt – Eins / Content Marketing für Alle

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@ KR


# SCM & Kammann Rossi


## /Eins

Das gemeinsam von Kammann Rossi und der SCM (School for Communication and Management) herausgegebene Fachmagazin vermittelt einen umfassenden Überblick über den aktuellen Stand und anstehende Entwicklungen im Bereich Content Marketing.

### Beschreibung

„EINS – Content Marketing für alle“ ist aus der Kooperation zwischen Kammann Rossi und dem Weiterbildungsunternehmen SCM – School for Communication and Management entstanden. Es ist das erste deutschsprachige Magazin, das gezielt Content Marketing in Theorie und Praxis behandelt und dabei bevorzugt auf einen ausgewogenen Mix aus Strategiethemen, Best Practices und Gastbeiträgen setzt. Das zweimal im Jahr erscheinende Printmagazin findet online untereins-content-marketing.deseine Erweiterung durch flankierende Zusatzelemente wie weiterführende Interviews, Studien und Downloadangebote.

### Erfolg

„EINS“ bietet rund um das Thema Content Marketing eine Plattform und einen entschleunigten, nachhaltigen Ort für Diskussionen hierzu. Praktiker – unabhängig von ihrer individuellen Aufgabe als Werber, Marketer, PRler oder Vertriebler – finden im Magazin Informationen, mit denen sie ihren Job im Markt für Kommunikation besser machen können.
