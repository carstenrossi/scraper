---
url: https://www.kammannrossi.de/projekt_emmi_nachhaltigkeitsbericht_2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Emmi / Nachhaltigkeitsbericht 2018
---

# Kammann Rossi – Projekt – Emmi / Nachhaltigkeitsbericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Emmi


## /Nachhaltigkeitsbericht 2018

Emmi ist eine bedeutender Schweizer Milchverarbeitungsbetrieb, dessen Wurzeln bis ins Jahr 1907 zurückreichen. Damals wurde die Vorgängerorganisation Zentralschweizerischer Milchverband Luzern (MVL) von 62 milchbäuerlichen Genossenschaften aus dem Kanton Luzern gegründet. Der Zusammenschluss vereinte 1.768 Milchbauern.
In den letzten 20 Jahren hat sich Emmi von einem mittelständischen Unternehmen zu einer internationalen Unternehmensgruppe entwickelt. Seit Ende 2004 ist Emmi an der Schweizer Börse notiert. Und seit 2009 folgt Emmi einer erfolgreichen Strategie, die auf drei Pfeilern basiert: Stärkung des Heimmarktes Schweiz, Wachstum im Ausland und Kostenmanagement.
Nachhaltigkeit hat bei Emmi einen hohen Stellenwert und stellt ein strategisches und globales Thema dar, in das , Emmi mittlerweile bedeutende finanzielle und personelle Ressourcen investiert. Seit 2018 realisiert Emmi den Nachhaltigkeitsbericht in Deutsch und Englisch zusammen mit Sustainsev und Kamman Rossi.

### Erfolg

Die Nachhaltigkeitsstrategie von Emmi startete 2016 bewusst mit lediglich vier Fokusthemen. Bis Ende 2020 möchte das Unternehmen die in diesen Themen gesetzten Ziele erreicht haben – und einem Unternehmen stehen viele Wege offen, um die eigene Nachhaltigkeit zu fördern. Für den Nachhaltigkeitsbericht 2019 hat Emmi zum Beispiel bei der jungen Generation nachgefragt, was ihr besonders wichtig ist. Die junge Generation wird durch Kinder vertreten, deren Väter oder Mütter bei Emmi arbeiten.
