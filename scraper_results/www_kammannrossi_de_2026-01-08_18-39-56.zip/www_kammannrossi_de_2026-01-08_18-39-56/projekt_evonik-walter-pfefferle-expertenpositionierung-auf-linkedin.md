---
url: https://www.kammannrossi.de/projekt_evonik-walter-pfefferle-expertenpositionierung-auf-linkedin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Evonik / Walter Pfefferle – Expertenpositionierung auf LinkedIn
---

# Kammann Rossi – Projekt – Evonik / Walter Pfefferle – Expertenpositionierung auf LinkedIn

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Evonik / Walter Pfefferle


## /Expertenpositionierung auf LinkedIn


### Der Kunde und das Projekt

Das Projekt beinhaltet die Konzeption, Umsetzung und Unterstützung einer LinkedIn-Kampagne für Walter Pfefferle, Senior Fellow und Experte für New Business Development bei Evonik. Seine komplexen Themen aus den Bereichen Healthcare, Food Chain, Cosmetics und Circular Economy erfordern ein anspruchsvolles Content-Management, das redaktionell hochwertige Posts mit strategischer Social-Media-Analyse verbindet, um so andere Experten und Stakeholder auf LinkedIn zu erreichen.

### Das zugrundeliegende Konzept

Auf dem Business-Netzwerk zählt neben Quantität insbesondere Qualität und der Mehrwert der Inhalte. Seine Positionierung als Experte erfordert neben fachlicher Expertise eine zielgerichtete und produktive Kommunikation mit anderen Experten und Stakeholdern. Durch das professionelle Content-Management von Kammann Rossi werden andere Professionals angezogen, die sich mit Walter Pfefferle vernetzen wollen.

### Die Zusammenarbeit

Kammann Rossi behält über einen Zeitraum von 15 Monaten den Account von Walter Pfefferle im Blick, überprüft die Performance der Beiträge und gibt ein qualifiziertes Feedback zu einer möglichen Optimierung für leistungsstarke Inhalte. Hierfür wurden Social-Media-Tools, wie z. B. „Hootsuite“ zum Verwalten des LinkedIn-Accounts und für die Auswertung der Beiträge genutzt. Neben dem nachhaltigen Managen des Redaktionsplans und der Koordination aller Beteiligten, war eine wichtige Aufgabe die Social-Media-Aktivitäten anderer Experten und Influencer zu analysieren, die sich in ähnlichen Wissensgebieten wie Walter Pfefferle bewegen.

### Der gemeinsame Erfolg

Für das Personal Branding sind Strategie und Social-Media-Expertise wichtig, um auf LinkedIn mehr Visibilität und Aufmerksamkeit zu generieren. Durch hochwertigen Content und die Analyse seines Profils rückt Walter Pfefferle im akademischen Umfeld nicht nur als kompetenter Experte, sondern auch als souveräner Kommunikator in den Fokus der Aufmerksamkeit.
