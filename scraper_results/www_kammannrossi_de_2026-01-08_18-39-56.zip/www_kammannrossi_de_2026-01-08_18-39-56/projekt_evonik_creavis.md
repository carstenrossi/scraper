---
url: https://www.kammannrossi.de/projekt_evonik_creavis
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Evonik - Creavis
---

# Kammann Rossi – Projekt – Evonik - Creavis

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Evonik Creavis


## /Videos „Unboxing the Future“


### Der Kunde und das Projekt

Creavis ist die strategische Innovationseinheit und Business Incubator des deutschen Spezialchemie-Unternehmens Evonik. Die Unit versteht sich als Wegbereiter nachhaltiger Lösungen für ein besseres Leben. Um diese Mission der Zielgruppe besser zu veranschaulichen und sich bei wichtigen Stakeholdern (Businesspartner, Unternehmen, Forschung, Wissenschaft und zukünftige Mitarbeiter) stärker zu positionieren, entwickelte Kammann Rossi Anfang 2023 für Creavis die Kampagne „Unboxing the Future“.

### Das zugrundeliegende Konzept

Die Kampagne „Unboxing the Future“ erläutert der Zielgruppe die Mission von Creavis: Die innovative Unit schafft Lösungen und Produkte, die es Unternehmen und Industrien ermöglichen, eine nachhaltige Kreislaufwirtschaft umzusetzen – und so klimaneutral zu werden und weniger Ressourcen zu verbrauchen. Die Paket-Boxen als zentrales Motiv stellen erstrebenswerte Zukunftsszenarien dar – mit funktionierenden und vernetzten Ökosystemen. Videos sollten die Kampagne zudem aufmerksamkeitsstark ergänzen.
(Zusammenschnitt aus drei Videos)

### Die Zusammenarbeit

Bis zum Frühjahr 2023 produzierte Kammann Rossi die drei etwa zwei Minuten langen Videos als „Flug durch die Boxen“– und sorgte dabei für Sounddesign, Schnitt und 3-D-Animation. Auf der Tonspur erklärt eine Sprecherin auf Deutsch die Lösungen und Zukunftsszenarien (mit englischen Untertiteln). Städte, Produktionsstätten und Gebäude sind animiert. In konstruktiver Abstimmung mit den Fachabteilungen von Evonik Creavis setzte Kammann Rossi die Visuals und Videos um. Die drei Videos thematisieren die drei sogenannten Incubation Cluster, in denen Creavis seine Aktivitäten bündelt und neue Geschäftsfelder erschließen will: Defossilation, Life Sciences und Solution beyond Chemistry.

### Der gemeinsame Erfolg

Die drei Filme flankieren das Marketing und die Kommunikation von Evonik Creavis. Die Videos sind starke, erklärende Medien für Social Media und werden mit dem Ziel, Geschäfts- und Entwicklungspartner zu gewinnen sowie das Employer Branding zu stärken, zum Beispiel auf LinkedIn ausgespielt. Außerdem werden Sie für Präsentationen bei potenziellen Kunden und Partnern genutzt und fungieren auf der eigenen Webseite, bei Kongressen und im Foyer von Evonik Creavis als imagefördernde Kommunikationsmittel.
