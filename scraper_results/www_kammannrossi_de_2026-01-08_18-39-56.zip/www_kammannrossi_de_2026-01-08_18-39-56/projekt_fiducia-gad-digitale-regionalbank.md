---
url: https://www.kammannrossi.de/projekt_fiducia-gad-digitale-regionalbank
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Fiducia GAD / Digitale Regionalbank
---

# Kammann Rossi – Projekt – Fiducia GAD / Digitale Regionalbank

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Fiducia & GAD


## /Digitale Regionalbank

Die Digitalisierung bringt auch für die Banken revolutionäre Veränderungen mit sich, die kommunikativ massiv begleitet werden müssen. Schon jetzt spielen die Volksbanken Raiffeisenbanken das Thema auf allen Kanälen und Medien. Die Genossenschaftsbanken wollen damit ihr Omnikanalmodell weiterentwickeln und für ihre Mitglieder und Kunden alle Zugangswege – von der Filiale über das Servicecenter bis zum Smartphone – stärker integriert anbieten. Die Fiducia & GAD IT AG und ihre Experten wiederum unterstützen als IT-Dienstleister die genossenschaftliche FinanzGruppe bei allen Themen rund um die digitale Regionalbank.

### Beschreibung

Ende 2017 hat der Bundesverband der Deutschen Volksbanken und Raiffeisenbanken (BVR) den Startschuss für die digitale Regionalbank im Rahmen seiner groß angelegten Digitalisierungsoffensive gegeben. Die Omnikanalvertriebsplattform mit allen Services und Leistungen wird vom genossenschaftlichen IT-Dienstleister Fiducia & GAD IT AG (www.fiduciagad.de) umgesetzt. Die dabei entwickelten IT-Lösungen ermöglichen Mitgliedern und Kunden, den von ihnen präferierten Kommunikationskanal noch flexibler selbst zu wählen und jederzeit wechseln zu können.

### Erfolg

Die Erwartungen an die Lösungen sind hoch: Die digitale Regionalbank gilt als wichtiger Wettbewerbsvorteil für das Privat- und Firmenkundengeschäft der Genossenschaftsbanken. Und darum steht die zielgerichtete Kommunikation für Banken im Vordergrund. Zusammen mit der Fiducia & GAD IT AG entwickelte Kammann Rossi eine eigens dafür ausgelegte Webseite, die die Entscheider und Anwender immer auf dem Laufenden hält.
