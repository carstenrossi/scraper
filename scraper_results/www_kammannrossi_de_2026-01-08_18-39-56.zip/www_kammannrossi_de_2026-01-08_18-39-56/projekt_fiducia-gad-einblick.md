---
url: https://www.kammannrossi.de/projekt_fiducia-gad-einblick
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Fiducia GAD / Einblick
---

# Kammann Rossi – Projekt – Fiducia GAD / Einblick

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Fiducia & GAD


## /einblick

Nach der Fusion der Fiducia IT AG und der GAD eG zur Fiducia & GAD IT AG zum 1. Juli 2015 sollten ab diesem Monat auch die Mitarbeitermagazine „Inhouse“ (GAD) und „Inside“ (Fiducia: seit 2013 konzipiert und umgesetzt von Kammann Rossi) vereinigt werden. Ziel war es, „das Beste aus zwei Welten“ in einem neuen Layout zu vereinen und einen wesentlichen Beitrag zum Zusammenwachsen der beiden Unternehmen zu leisten.

### Beschreibung

Aktiv, aktuell, nah am Geschehen – das ist der Ansatz, der dem gemeinsamen Mitarbeitermagazin „einblick“ zugrunde liegt. Das Heft zeichnet sich aus durch aktive Textstilistik, einen ausgewogenen Formatemix und ein dynamisches Layout. Die Themen sind gegenwarts- und zukunftsorientiert und enthalten nur wenige Rückblicke. Texte werden nah an realen Menschen/Mitarbeitern/Personen konzipiert und blicken „in das Geschehen“. So werden Nähe und Authentizität erzeugt. Feste Rubriken bieten Platz für strategisches Agendasetting („Unser Unternehmen“), Einblick in Projekte, in die alltägliche Arbeit und Arbeitswelten („Unsere Arbeit“) sowie Persönliches, Unterhaltendes und „Über-den-Tellerrand-hinaus-Themen“ („Unter uns“).

### Erfolg

„einblick“ schafft als Change-Communications-Medium den Spagat, zwei Unternehmen (Fiducia & GAD) und zwei Unternehmenskulturen zu vereinen. Dabei geht „einblick“ auf die Unterschiede ein, stellt aber gleichzeitig die Gemeinsamkeiten heraus und schafft so Brücken und Schnittmengen. Dass dies gelingt, wird durch die hohe Leserbeteiligung belegt – durch konstruktive Kritik und Vorschläge für Themen und Beiträge.
