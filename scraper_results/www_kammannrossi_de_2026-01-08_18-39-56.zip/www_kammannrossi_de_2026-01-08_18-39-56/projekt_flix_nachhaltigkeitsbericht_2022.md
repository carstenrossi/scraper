---
url: https://www.kammannrossi.de/projekt_flix_nachhaltigkeitsbericht_2022
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Flix - Nachhaltigkeitsbericht 2022
---

# Kammann Rossi – Projekt – Flix - Nachhaltigkeitsbericht 2022

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Flix SE


## /Nachhaltigkeitsbericht 2022


### Der Kunde und das Projekt

Die Flix SE startete 2013 als Start-Up Projekt in München und betreibt heute das größte europäische Fernbusnetz. Das Unternehmen ist in vielen Ländern Marktführer und versteht sich als innovative Kombination aus Tech-Start-Up, E-Commerce-Unternehmen und klassischem Verkehrsunternehmen. Außer den markanten grünen Reisebussen sind seit 2018 auch FlixTrains auf der Schiene unterwegs. Das Unternehmen hat zahlreiche Pilotprojekte gestartet, um nachhaltige Antriebe für das eigene Fernbusnetz zu testen, und 2022 seinen ersten Nachhaltigkeitsbericht veröffentlicht.

### Das zugrundeliegende Konzept

Für den Nachhaltigkeitsbericht der Flix SE empfahl Kammann Rossi ein klassisches journalistisches Format in Form einer Kombination aus Unternehmensreportage und Reisebericht. Auf einer Busfahrt von Brüssel nach Amsterdam wird exemplarisch ein nachhaltiges Pilotprojekt portraitiert, mit dem Flix Biogasantriebe für den Fernbusverkehr erforscht. Die lebendige Reportage führt die Leser in den Bericht ein und macht so ein komplexes Nachhaltigkeitsprojekt anschaulich.

### Die Zusammenarbeit

Die Route wurde gemeinsam mit Flix geplant. Ein Redakteur begleitete den Flixbus und führte Interviews mit Fahrgästen und dem Busfahrer, ein Fotograf hielt die Reportage visuell fest. Begleitende Interviews mit Verantwortlichen von Flix rundeten die Reportage über das Pilotprojekt ab. Für den Nachhaltigkeitsteil des Berichts arbeitete Kammann Rossi – wie schon bei anderen Projekten – mit den Nachhaltigkeitsexperten von Sustainserv zusammen.

### Der gemeinsame Erfolg

Durch die lebendige Reisereportage wird das Motto „DRIVING THE MOBILITÄT (R)EVOLUTION“ für die Leserinnen und Leser erlebbar und nachvollziehbar. Darüber hinaus werden weitere Kapitel des Berichts durch Zitate von Flix-Mitarbeitenden inhaltlich untermauert und die Nachhaltigkeits- und Dekarbonisierungsstrategie von Flix so auf sehr persönliche Weise erläutert. Das Ergebnis ist ein moderner Nachhaltigkeitsbericht, der durch journalistisches Storytelling und klare Zielgruppenansprache überzeugt.
