---
url: https://www.kammannrossi.de/projekt_foerderverein
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Foerderverein Kinderkrankenhaus
---

# Kammann Rossi – Projekt – Foerderverein Kinderkrankenhaus

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Förderverein För Pänz


## /Kinderkrankenhaus Köln

Im Gegensatz zu erwachsenen Patienten stellen Kinder – insbesondere chronisch kranke Kinder – spezifische Ansprüche an ihre Umwelt. Sie bedürfen sowohl mehr pflegerischer als auch mehr finanzieller Fürsorge. Dafür sind jedoch häufig keine öffentlichen Gelder vorgesehen. An dieser Stelle kommt der Verein der Freunde und Förderer des Kinderkrankenhauses Amsterdamer Straße Köln e. V. ins Spiel. Seit 1991 ist der Verein Anlaufstelle für alle, die kranken Kindern helfen wollen, ohne sich auf ein bestimmtes Projekt festlegen zu wollen. Kammann Rossi unterstützt den Förderverein seit 2018 bei allen Kommunikationsaufgaben und informiert via Webseite und Facebook über die Aktivitäten des Vereins, um so die Spendenbereitschaft für unterschiedlichste Projekte zu erhöhen.

### Erfolg

