---
url: https://www.kammannrossi.de/projekt_frauscher-mitarbeitermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Frauscher / Mitarbeitermagazin
---

# Kammann Rossi – Projekt – Frauscher / Mitarbeitermagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Frauscher


## /Mitarbeiterzeitung


### Erfolg

„moizeit!“ bricht mit Konventionen. Die (kulinarische) Richtung wurde durch das Social Intranet von Frauscher beeinflusst: „COFFEE“ ist die Plattform für den täglichen, raschen Austausch. Sozusagen der schnelle Kaffee zwischendurch. „moizeit!“ bildet den Gegenpol dazu: Darin ist Platz, um Aspekte ausführlicher vorzustellen. Und so zeichnet sich „moizeit!“ durch viele persönliche Stories von Mitarbeitern für Mitarbeiter aus – die mehr Nähe anstatt die simple „Vorstandstrompete“ erwarten.
