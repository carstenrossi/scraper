---
url: https://www.kammannrossi.de/projekt_gtai-markets-germany
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – GTAI / Markets Germany
---

# Kammann Rossi – Projekt – GTAI / Markets Germany

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Germany Trade & Invest


## /Markets Germany


### Ein Wirtschaftsmagazin für ausländische Investoren

Wer echte Insiderinformationen zu Investitionsmöglichen in Deutschland sucht, findet diese exklusiv in Markets Germany, dem Magazin von Germany Trade & Invest (GTAI) im Auftrag des Bundeswirtschaftsministeriums.Das englischsprachige Magazin bietet interessante Berichte, Reportagen und weitere Neuigkeiten über den Investitions- und Technologiestandort Deutschland. Es erscheint dreimal im Jahr und ist auch über eine App für Tablets und Smartphones erhältlich. Für die exklusiven Informationen sorgt ein Netzwerk von internen Experten für verschiedene Fachgebiete wie etwa Energie, Chemie, Automotive, F&E, etc. Diese Experten sind auch die ersten Ansprechpartner für ausländische Investoren und gleichzeitig die Fachredaktionsleiter für ihren jeweiligen Bereich.Die Beiträge werden basierend auf Informationen der Experten von muttersprachlichen englischsprachigen Journalisten verfasst, die in Deutschland ansässig sind und für renommierte ausländische Wirtschaftspublikationen schreiben.Zusammen mit wortwert und Kammann Rossi realisieren die Experten und die Chefredaktion von Markets Germany den Bestseller der GTAI seit vielen Jahren und legten Anfang 2021 nach: mit frischer Optik, mehr Leserführung und ganz neuen Formaten. Neben dem exklusiven inhaltlichen Mehrwert setzt Markets Germany verstärkt auf visuelles Storytelling und hebt sich so erfrischend von der Masse ab.

### Kammann Rossi 360 Grad Abo

Sie interessieren sich für unser Abo? Schreiben Sie uns und wir setzen uns umgehend mit Ihnen in Verbindung.
ZUM FORMULAR

### Herausforderung und Kommunikationsziel

Markets Germany schafft es mit einem Mix an nutzwertigen, aber auch bunten und überraschenden Themen, den Wirtschaftsstandort Deutschland vorzustellen und dabei auf die (rechtlichen) Besonderheiten hinzuweisen. So schafft Markets Germany eine Balance zwischen Nutzwertstorys und kulturellem Deutschland-Guide.

### Realisierung und Zusammenarbeit

In enger Zusammenarbeit mit der Wirtschaftsredaktion wortwert und Kammann Rossi, werden alle drei Ausgaben pro Jahr sowie Sonderausgaben wie „Markets Germany Spezial“ (1 x jährlich) geplant. In gemeinsamen Sprints wird jede Ausgabe in Absprache mit den Fachbereichen der GTAI produziert. Jede Ausgabe wird durch Schulterblicke für den jeweiligen Schwerpunkt und das gesamte Magazin begleitet. In exklusiver Kooperation mit der internationalen Fotoagentur und Fotografenrepräsentanz laif werden weltweit Fotostrecken und Reportagen realisiert. Diese Kooperation ist ein weiterer USP in derkollegialen Zusammenarbeit zwischen Agenturen und GTAI.

### Das sagt die Zielgruppe über Markets Germany

