---
url: https://www.kammannrossi.de/projekt_gtai-markets-medienfamilie
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – GTAI / Markets Medienfamilie
---

# Kammann Rossi – Projekt – GTAI / Markets Medienfamilie

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Germany Trade & Invest


## /Markets Medienfamilie

Den deutschen Mittelstand über Investitionschancen informieren und Deutschland als Investitionsstandort bekannt zu machen, ist Aufgabe von Germany Trade & Invest (GTAI).Kammann Rossi unterstützt dabei tatkräftig die Realisierung von„Markets International“, „Markets Germany“ und„Markets Online“.

### Kammann Rossi 360 Grad Abo

Sie interessieren sich für unser Abo? Schreiben Sie uns und wir setzen uns umgehend mit Ihnen in Verbindung.
ZUM FORMULAR

### Die Herausforderung

Germany Trade & Invest (GTAI) ist die erste Anlaufstelle für den exportorientierten Mittelstand in Deutschland und wirbt im Ausland für die Standortvorteile Deutschlands. Wirtschaftsanalysten der GTAI berichten über 120 Länder und liefern damit Unternehmen die Wissensgrundlage für Auslandsgeschäfte. Die Magazine „Markets International“ und „Markets Germany“ sind die Medien-Flaggschiffe von GTAI. Sie informieren gedruckt und online über Investitionschancen im Ausland sowie über den Investitionsstandort Deutschland: „Markets International“ wendet sich dabei an den exportorientierten deutschen Mittelstand, „Markets Germany“ an Investoren aus dem Ausland.

### Erfolg

Der neue Look der Markets Medienfamilie sowie die breit gefächerte redaktionelle Ausrichtung ist nicht nur bei der Leserschaft sehr gut aufgenommen(die Abonnentenzahlen haben sich nahezu verdoppelt),sondern auch mehrfach prämiert worden – unter anderem mit dem Fox Award und dem BCM Award in Gold.

### Markets Online

Um die Leser auch onlinemit wichtigen Informationen und Neuigkeiten zu versorgen, wurden beide Magazine als digitale E-Magazine entwickelt. Jedes Magazin informiert die jeweilige Zielgruppe mit den für sie relevanten Nachrichten: www.marketsgermany.com die ausländischen Investoren und www.marketsinternational.de deutsche Unternehmen. Mit Erfolg, denn seit dem Online-Relaunch sind die Besucherzahlen bei GTAI stark gestiegen und alle wichtigen Themen jederzeit online verfügbar.
