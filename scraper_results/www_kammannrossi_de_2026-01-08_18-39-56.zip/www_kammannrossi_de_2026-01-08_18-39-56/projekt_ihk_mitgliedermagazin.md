---
url: https://www.kammannrossi.de/projekt_ihk_mitgliedermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – IHK Köln - IHKplus
---

# Kammann Rossi – Projekt – IHK Köln - IHKplus

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Industrie- und Handelskammer zu Köln


## /Mitgliedermagazin „IHKplus“


### Der Kunde und das Projekt

Mit ihrem Mitgliedermagazin „IHKplus" informiert die Industrie- und Handelskammer zu Köln ihre Mitglieder seit über 70 Jahren direkt und zuverlässig über die wirtschaftlichen Entwicklungen im Kammerbezirk Köln. Ende 2021 schrieb die IHK Köln den Relaunch des in die Jahre gekommenen Mitgliedermagazins für einen umfassenden Relaunch öffentlich aus. Mit den Vorschlägen für eine redaktionelle und grafische Neuausrichtung konnte Kammann Rossi die IHK überzeugen und erhielt den Zuschlag, die Vorschläge zusammen mit der Inhouseredaktion der Grafik umzusetzen.

### Das zugrundeliegende Konzept

Das neue Konzept von „IHKplus" stellt Mitglieder der IHK ganz klar in den Fokus – und den umfassenden Service, den die IHK ihren Mitgliedern zu bieten hat. Die meisten Beiträge sind mit Serviceelementen versehen. Ein separater Magazinteil im letzten Heftdrittel bündelt alle Veranstaltungen und Weiterbildungsmöglichkeiten übersichtlich und geordnet nach Veranstaltungsdaten.

### Die Zusammenarbeit

In der gemeinsamen Zusammenarbeit mit der IHK Köln ist aus „IHKplus" nach dem Relaunch ein aktives Kammermagazin geworden, das den kritischen Dialog und die kritische Stellungnahme (gegenüber der Stadt und Politik) nicht scheut und klar herausstellt. Das Magazin bietet ein Mehr an Service und ein Mehr an Information über die Ziele und Pläne der IHK Köln.

### Der gemeinsame Erfolg

Die erste runderneuerte Ausgabe von „IHKplus" erschien im Dezember 2022. Die Reaktionen darauf waren sehr gut – sowohl innerhalb der IHK als auch bei Verbänden und Mitgliedern der IHK.
