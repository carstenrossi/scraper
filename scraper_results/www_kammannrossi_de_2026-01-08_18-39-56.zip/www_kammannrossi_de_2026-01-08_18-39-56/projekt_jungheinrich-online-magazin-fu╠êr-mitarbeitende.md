---
url: https://www.kammannrossi.de/projekt_jungheinrich-online-magazin-für-mitarbeitende
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Jungheinrich – Online-Magazin für Mitarbeitende
---

# Kammann Rossi – Projekt – Jungheinrich – Online-Magazin für Mitarbeitende

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Jungheinrich


## /Online-Magazin für Mitarbeitende „Yellow Press“


### Der Kunde und das Projekt

Jungheinrich mit Hauptsitz in Hamburg ist ein führender Lösungsanbieter für die Intralogistik mit Vertriebs- und Servicegesellschaften in 40 Ländern weltweit. Anfang 2022 beauftragte Jungheinrich Kammann Rossi mit der Neukonzeption seines Magazins für Mitarbeitende. Die Aufgabe nach dem gewonnenen Pitch lautete: erstmals nur online, monothematisch, mehr redaktionelle Formate, mehr Emotionalität, mehr Storytelling und mehr Jungheinrich-Mitarbeitende im Magazin.

### Das zugrundeliegende Konzept

Die neue Yellow Press führt die Idee des Leitthemas konsequent weiter. Jede Ausgabe des Onlinemagazins ist monothematisch konzipiert: Alle Inhalte richten sich an jeweils einem Führungsleitbild aus. Die intensive Beschäftigung mit diesem Stoff über die gesamte Ausgabe hinweg erlaubt es, den jeweiligen Wert aus den unterschiedlichsten Blickwinkeln zu betrachten und in verschiedenen, abwechslungsreichen, überraschenden Facetten darzustellen. Ein weiterer Vorteil: Ein Thema in seiner Gesamtheit wird bis in die Tiefe durch viele, auch kürzere Beiträge und (interaktive) Formate dargestellt.

### Die Zusammenarbeit

Erstmals umgesetzt wurde die neue Yellow Press im Sommer 2022 – mit dem Leitthema „Neue Wege gehen“. Drei Online-Ausgaben im Jahr produziert Kammann Rossi, jeweils startend mit einer Redaktionskonferenz mit dem Kunden. KR schreibt einen Teil der Beiträge zu den Themen Strategie, Projekte, Produkte und Mitarbeitende; gestaltet das Magazin inklusive Slideshows und Videos mit dem ToolPagestrip.

### Der gemeinsame Erfolg

Die ausschließliche Beschäftigung mit einem Thema gibt den Mitarbeitenden in Zeiten des Umbruchs und der Transformation sowohl Halt als auch Führung. Die unterschiedlichen, aber wiederkehrenden Formate erlauben es, Themen und Storys anschaulich, abwechslungsreich und onlineadäquat aufzubereiten. Gleichzeitig geben sie einen gewissen inhaltlichen Rahmen und damit Wiederkennungswert. Die Leserinnen und Leser der Yellow Press lernen Abteilungen, Produkte, Prozesse und strategische Ziele des Unternehmens besser kennen.
