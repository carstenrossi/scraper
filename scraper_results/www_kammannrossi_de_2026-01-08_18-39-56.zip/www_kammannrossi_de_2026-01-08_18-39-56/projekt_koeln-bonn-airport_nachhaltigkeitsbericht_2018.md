---
url: https://www.kammannrossi.de/projekt_koeln-bonn-airport_nachhaltigkeitsbericht_2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Köln Bonn Airport / NB 2018
---

# Kammann Rossi – Projekt – Köln Bonn Airport / NB 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Köln Bonn Airport


## /Nachhaltigeitsbericht 2018

Der Köln Bonn Airport gehört zu den fünf größten Verkehrsflughäfen in Deutschland. In einer der am dichtest besiedelten und wirtschaftlich stärksten europäischen Regionen übernimmt er eine unverzichtbare Rolle als Infrastrukturanbieter.
Für den drittgrößten Fracht- und sechstgrößte Passagierflughafen Deutschlands kommt wegen seiner Lage im Naturschutzgebiet der Wahner Heide, aber auch durch seine öffentlich-rechtliche Besitzstruktur eine besondere Verantwortung seines Wirtschaftens zu. Alle Mitarbeiter arbeiten daran, den Flughafen immer nachhaltiger zu betreiben.
Der erste Nachhaltigkeitsbericht der Flughafengesellschaft aus dem Jahr 2015 war eine Bestandsaufnahme des Status quo. Seitdem wird der Nachhaltigkeitsbericht auf Basis einer Wesentlichkeitsmatrix und laufen aktualisierten wesentlichen Themen weiterentwickelt. Zentraler Teil dieses Prozesses ist eine behutsame Revision der Wesentlichkeitsanalyse.
Zu den Leistungen gehörte die inhaltliche wie gestalterische Konzeption des Berichtes, die redaktionelle Texterstellung, die Umstellung auf die GRI Standards sowie die Entwicklung einer zeitgemäßen Grafiksprache mit eigenständigen Schaubildern und einer strukturierten und informativen Leselogistik.

### Erfolg

Gerade in einer Branche, die aus Klimaschutzgründen im Fokus steht, wird ein innovatives Nachhaltigkeitsmanagement besonders von der Öffentlichkeit beobachtet und erwartet. Der Stakeholder-Dialog mit Kunden und Passagieren, Anrainern, Umweltorganisationen und der interessierten Öffentlichkeit ist wichtig und vielfältig. Mit einem umfassenden Nachhaltigkeitsmanagement begleitet und steuert der Köln Bonn Airport diesen Prozess, formuliert Ziele und dokumentiert Ergebnisse und Veränderungen mit dem Nachhaltigkeitsbericht.
