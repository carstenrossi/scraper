---
url: https://www.kammannrossi.de/projekt_liebherr-beratung
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Liebherr – Beratung (Strategie & Inhalt)
---

# Kammann Rossi – Projekt – Liebherr – Beratung (Strategie & Inhalt)

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Liebherr Storys & mehr


## /Strategie und Content-Beratung


### Die Ausgangslage

Die Erfindung des mobilen Turmdrehkrans 1949 ist zugleich die Geburtsstunde von Liebherr. Seit dieser Zeit steht das Unternehmen für eine breite Palette anspruchsvoller Produkte und Leistungen. Die Firmengruppe ist ein familiengeführtes Technologieunternehmen mit einem breit diversifizierten Produktprogramm, das insgesamt 13 Produktsegmente umfasst. Der kreative Austausch zwischen den Segmenten fördert die Entwicklung von Innovationen und visionären Technologien, von faszinierenden Produkten und von Dienstleistungen, die einen wirklichen Unterschied machen.

### Kammann Rossi 360 Grad Abo

Sie interessieren sich für unser Abo? Schreiben Sie uns und wir setzen uns umgehend mit Ihnen in Verbindung.
ZUM FORMULAR

### Herausforderung und Kommunikationsziel

Liebherr versteht sich als Pionier und spricht mit all seinen Lösungen weltweit technisch wie kommunikativ verschiedene Zielgruppen mit ganz unterschiedlichen Bedürfnissen an. Für sein Corporate-Magazine, die „LiebherrStorys“, hatte sich die Unternehmenskommunikation zum Ziel gesetzt, die Marke Liebherr auffälliger zu positionieren und zu stärken und Reputation bei relevanten Zielgruppen aufzubauen beziehungsweise zu steigern.

### Analyse und Beratung

In einem Strategieworkshop, der aufgrund des plötzlichen ersten Corona-Lockdowns im April 2020 kurzfristig virtuell geplant und durchgeführt wurde, überarbeitete Kammann Rossi gemeinsam mit der Unternehmenskommunikation den Story-Bereich von Liebherr. Im Fokus standen dabei die Ausarbeitung von Details zu den relevanten Zielgruppen, die gemeinsame Erarbeitung von Ziel-Prioritäten sowie die Vorstellung und Priorisierung von extra für Liebherr zugeschnittenen inhaltlichen Formaten. Aus den Ergebnissen des Workshops erstellte Kammann Rossi einen Formate-Katalog, mit dessen Hilfe Liebherr in seinem Story-Bereich die Inhalte nun zielgerichtet und auf die jeweilige Zielgruppe zugespitzt planen und ausspielen kann.
Aus diesem singulären Beratungsmandat ergab sich schließlich der Folgeauftrag, Liebherrs interne Kommunikation bei der Modernisierung und Vereinheitlichung der zahlreichen Mitarbeitermagazine aus den einzelnen Produktsegmenten zu beraten. So erstellte Kammann Rossi nach eingehender Analyse der unterschiedlichen Zeitschriften auf Grundlage eines Workshops mit den jeweiligen Redakteuren ein umfangreiches Redaktionshandbuch. Es enthält neben vielen „handwerklichen“ Tipps auch eigens für die interne Kommunikation angepasste inhaltliche Formate zur abwechslungsreichen und gezielten Information und Unterhaltung der rund 48.000 Mitarbeiterinnen und Mitarbeiter. In einem Schreibworkshop für die verantwortlichen Redakteure vermittelte Kammann Rossi zudem die Grundlagen aus dem Redaktionshandbuch anhand praktischer Beispiele und Aufgaben.
Darüber hinaus betraute Liebherr Kammann Rossi mit zwei weiteren Aufgaben: Dem Renaming-Projekt für ein Kundenmagazin und mit einem ganz neuen, KR-typischen Format, das Liebherr sehr schätzt: „AMA – Ask Me Anything" – eine virtuelle Fragerunde mit KR-Geschäftsführer Carsten Rossi. Dabei stellen die Teilnehmer Fragen zu Themen, die ihnen aktuell unter den Nägeln brennen und erhalten Erste-Hilfe-Tipps: Praktisch, direkt und ungefiltert.

### Zusammenarbeit und Erfolge

Liebherr begeistert seine Kunden und das Familienunternehmen bietet einen schier unendlichen Fundus an spannenden Storys. Diesen Schatz gemeinsam zu heben, kennzeichnete die Zusammenarbeit zwischen Liebherr und Kammann Rossi, ebenso wie die offene und direkte Art der Kommunikation. „Auf einer Skala von 1 bis 10 würden wir Kammann Rossi mit der Höchstnote weiterempfehlen", erklärt Katharina Kaufeldt, Head of Corporate Publishing & Content Marketing bei Liebherr.
