---
url: https://www.kammannrossi.de/projekt_mann-hummel_nachhaltigkeitsbericht_2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – MANN+HUMMEL / Nachhaltigkeitsbericht 2018
---

# Kammann Rossi – Projekt – MANN+HUMMEL / Nachhaltigkeitsbericht 2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# MANN+HUMMEL


## /Nachhaltigkeitsbericht 2018


### Erfolg

Die Realisierung des Online-Nachhaltigkeitsberichtes erfolgt zusammen mit Sustainserv und Kammann Rossi auf Basis einer 2017 durchgeführten Materialitätsanalyse. Dabei hatte das Unternehmen unter Beteiligung von Vertretern aus den Bereichen „Innovation & Strategy“, „Human Resources“, „Legal“, „Quality & HSE“, „Property Management“, „Purchasing & Supply Chain Management“, „Marketing“ und „Corporate Communications“ bewertet, welche Nachhaltigkeitsthemen für MANN+HUMMEL und seine Partner besonders relevant sind. Seit 2018 realisiert MANN+HUMMEL den Nachhaltigkeitsbericht auf dieser Basis und nach den internationalen GRI-Standards zusammen mit Sustainserv und Kammann Rossi.
