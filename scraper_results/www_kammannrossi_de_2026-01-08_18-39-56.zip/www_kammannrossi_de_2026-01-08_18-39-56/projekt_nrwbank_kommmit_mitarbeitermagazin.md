---
url: https://www.kammannrossi.de/projekt_nrwbank_kommmit_mitarbeitermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – NRW.BANK – KOMM MIT! – digitales Mitarbeitermagazin
---

# Kammann Rossi – Projekt – NRW.BANK – KOMM MIT! – digitales Mitarbeitermagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# NRW.BANK


## /„KOMM MIT!“ digitales Mitarbeitendenmagazin


### Der Kunde und das Projekt

Die NRW.BANK ist die Förderbank für Nordrhein-Westfalen. In enger Partnerschaft mit ihrem Eigentümer, dem Land NRW, trägt sie dazu bei, dass Mittelstand und Gründungen gestärkt, bezahlbarer Wohnraum geschaffen und öffentliche Infrastrukturen verbessert werden. Die NRW.BANK bietet Menschen, Unternehmen und Kommunen in NRW passgenaue Finanzierungs- und Beratungsangebote. Dabei arbeitet sie wettbewerbsneutral mit Finanzierungspartnerinnen und  -partnern, insbesondere allen Banken und Sparkassen, zusammen. Um die Transformationsprozesse zu verstärken, setzt sie gezielte Förderimpulse – hin zu einem nachhaltigen, klimaneutralen und digitalen NRW. Über die vielfältigen Arbeitsbereiche der Bank berichtet regelmäßig KOMM MIT! – das digitale Mitarbeitendenmagazin der NRW.BANK.

### Das zugrundeliegende Konzept

Die Kommunikationsaufgabe von KOMM MIT! ist es, die Mitarbeiterinnen und Mitarbeiter über die wichtigsten Themen der Bank zu informieren und damit die Identifikation mit dem Unternehmen zu stärken. Die Themenbreite erstreckt sich über strategische Themen und Förderprojekte der NRW.BANK über Personalthemen wie die Vereinbarkeit von Beruf und Privatem bis hin zu dem ehrenamtlichen Engagement und den Hobbys der Mitarbeitenden. Redaktionell nutzt KOMM MIT! dazu die ganze Bandbreite journalistischer Stilmittel von Interviews bis hin zu Reportagen.

### Die Zusammenarbeit

Wir haben das Magazin 2020 gemeinsam mit unserem Partner der Finanz- und Wirtschaftsredaktion Wortwert und in enger Zusammenarbeit mit der NRW.BANK konzipiert und dabei Wert auf Prägnanz und Übersichtlichkeit gelegt. Wo es passt, setzt KOMM MIT! auf Storytelling-Elemente, die die jeweiligen Beiträge abwechslungsreich flankieren, wie etwa kurze Videofeatures, Bildergalerien oder den eigenen Podcast „NRW.BANK.Hörbar“. Im März 2021 ging die erste digitale Ausgabe live. Wir haben neben der organisatorischen Betreuung das Design und den Publikationsprozess übernommen.

### Der gemeinsame Erfolg

KOMM MIT! wird von den Mitarbeitenden der NRW.BANK als abwechslungsreiches Informationsmedium geschätzt. Dies spiegeln auch die Statistiken wider:
- Sehr gute Zugriffszahlen von Mitarbeitenden, Pensionären und Elternzeitlern
- Regelmäßig wiederkehrende Besucherinnen/Besucher mit langer Lesedauer
- Hohe Engagement-Rate
- Niedrige Bounce-Rate
