---
url: https://www.kammannrossi.de/projekt_olb-digitaler-geschaeftsbericht-2021
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – OLB / (Digitaler) Geschäftsbericht 2021
---

# Kammann Rossi – Projekt – OLB / (Digitaler) Geschäftsbericht 2021

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Oldenburgische Landesbank


## /(Digitaler) Geschäftsbericht 2021


### Die Kurzbeschreibung

Die Oldenburgische Landesbank AG (OLB) ist ein modernes, in Norddeutschland ansässiges Finanzinstitut, das seinen Kunden unter den beiden Marken OLB Bank und Bankhaus Neelmeyer deutschlandweit Dienstleistungen anbietet. Der Anspruch ist es, ganzheitliche Lösungen für komplexe Finanzfragen anzubieten. 2021 war ein besonderes Jahr, in dem die OLB ihre Transformation inklusive digitaler Innovationen vorantrieb und trotz Coronakrise erfolgreich abschloss.
Für den Geschäftsbericht 2021 (Print und digital) entwickelte Kammann Rossi das inhaltliche und gestalterische Konzept und übernahm Produktion und Erstellung.

### Das Konzept

21 FRAGEN – 21 ANTWORTENIn Anlehnung an das Berichtsjahr 2021 leiten den Geschäftsbericht als Motiv 21 Fragen.Die 21 Antworten geben einen Überblick über die Ergebnisentwicklung, das Geschäftsmodell, die strategische Ausrichtung und weitere Aspekte der OLB. Damit erklärt der Geschäftsbericht Komplexes auf sehr verständliche Art und Weise.Die Leser des Geschäftsberichts sind Stakeholder, Mitarbeitende, Wirtschaftsjournalisten, Entscheider der Financial Community und Multiplikatoren.

### Die Besonderheit

Visuell sticht der Bericht – wie in den Jahren zuvor – durch seine prägnante Typografie, die OLB-CI-Farbe Grün und durch die typische Schwarz-Weiß-Fotografie hervor. Für den Bericht 2021 wurden – passend zum abgeschlossenen Geschäftsjahr – 21 wichtige Fragen in den Vordergrund gerückt, die von den Verantwortlichen bei der OLB beantwortet werden. Die 21 Fragen ziehen sich durch den gesamten Bericht und wurden aufmerksamkeitsstark fotografiert und illustriert. Parallel zumOnlinebericht(Made in pagestrip) erschien eine kleine Printauflage, die auf FSC-zertifiziertem Papier und klimaneutral in zwei Sprachversionen (deutsch und englisch) gedruckt wurde.

### Kanal- und Themenmix

Mit der Mehrfachverwertung schöpft die OLB das Potenzial des Geschäftsberichts als Content-Hub für verschiedene Kanäle maximal aus. Der Themenmix beschreibt die dynamische Weiterentwicklung in den vergangenen und kommenden Jahren. Dabei stehen zwei der wichtigsten Faktoren im Mittelpunkt: Das Wissen und das Engagement der Mitarbeiter.
Die OLB hat in ihrer langen Historie stets ausgezeichnet, sich immer wieder erfolgreich an sich dynamisch verändernde Marktbedingungen anzupassen. So ist es ihr gelungen, in 153 Geschäftsjahren ausschließlich positive Ergebnisse zu schreiben. Jetzt treibt sie die Motivation an, die Zukunft und Eigenständigkeit der Bank langfristig zu sichern.
Im Bericht sind die entsprechenden Fakten tendenziell kurz gehalten und auf verschiedene Leseebenen verteilt und sind schnell erfassbar.
