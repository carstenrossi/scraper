---
url: https://www.kammannrossi.de/projekt_olb-finanzbericht-2019
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – OLB / Finanzbericht 2019
---

# Kammann Rossi – Projekt – OLB / Finanzbericht 2019

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Oldenburgische Landesbank AG (OLB)


## /Finanzbericht 2019

Die Oldenburgische Landesbank AG (OLB) ist ein modernes, in Norddeutschland verankertes Finanzinstitut, das seine Kunden unter den beiden Marken OLB Bank und Bankhaus Neelmeyer deutschlandweit betreut. Der Anspruch ist es, ganzheitliche Lösungen in komplexen Finanzfragen zu bieten. 2019 war ein besonderes Jahr, denn die OLB feierte ihr 150-jähriges Bestehen und hat mit dem Erwerb sowie der Integration der Wüstenrot Bank AG Pfandbriefbank einen weiteren Schritt zu einem deutschlandweit agierenden Finanzinstitut mit umfassendem Leistungsangebot für ein breites Kundenspektrum gemacht. Die Veränderungen und umfassenden Leistungen der OLB spiegelt der Finanzbericht 2019 wider.

### Umsetzung

