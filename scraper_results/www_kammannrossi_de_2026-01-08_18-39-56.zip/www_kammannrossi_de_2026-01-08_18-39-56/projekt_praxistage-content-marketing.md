---
url: https://www.kammannrossi.de/projekt_praxistage-content-marketing
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Convention / Praxistage Content Marketing
---

# Kammann Rossi – Projekt – Convention / Praxistage Content Marketing

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Praxistage


## /Content Marketing

Mit den Praxistagen Content Marketing bietet Kammann Rossi in Zusammenarbeit mit der SCM (School for Communication and Management) Interessierten aus den Bereichen Unternehmenskommunikation, PR, Corporate Publishing, Brand Communications, Marketing und Vertrieb eine zweitägige Veranstaltung, bei der – neben einem umfassenden Überblick über die Grundlagen des strategischen Content Marketings – der Fokus vor allem auf interaktiven Workshop-Formaten und interessanten Best-Practice-Cases liegt.

### Beschreibung

Zusammen mit der SCM hat Kammann Rossi ein Veranstaltungsformat entwickelt, dessen Anspruch es ist, jeden Aspekt der Entwicklung einer erfolgreichen Content-Marketing-Strategie zu beleuchten. Die Grundlagen werden in einführenden Vorträgen zu den Themen „Strategie & Ziele“ und „Bedürfnisse & Themenfindung“ vermittelt und dann jeweils in praxisorientierten Workshops vertieft. Durch die Bearbeitung praktischer Aufgaben können die Teilnehmenden das erlernte Wissen anwenden und sich aufkommende Fragen direkt von Experten beantworten lassen. Durch mehrere Best-Practice-Cases aus renommierten Unternehmen erhalten die Teilnehmenden zudem wertvolles Praxiswissen.

### Erfolg

Die seit 2016 zweimal jährlich im Kölner Raum stattfindenden Praxistage Content Marketing ziehen Interessierte aus den unterschiedlichsten Branchen an, die gerade in das Thema Content Marketing eingestiegen sind oder es vorhaben. Die ausgewogene Kombination aus theoretischen Grundlagen, praxisorientierten Workshops und Best-Practice-Cases ermöglicht den Teilnehmenden einen methodischen Zugang, der mit Begeisterung angenommen wird.
