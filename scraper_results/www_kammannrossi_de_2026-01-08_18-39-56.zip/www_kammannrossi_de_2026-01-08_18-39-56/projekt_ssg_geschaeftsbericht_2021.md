---
url: https://www.kammannrossi.de/projekt_ssg_geschaeftsbericht_2021
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – SSG – Geschäftsbericht 2021
---

# Kammann Rossi – Projekt – SSG – Geschäftsbericht 2021

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Swiss Steel Group


## /Geschäftsbericht 2021


### Der Kunde und das Projekt

Die Swiss Steel Group (SSG) ist ein börsennotierter Stahlkonzern mit Hauptsitz in Luzern. Die Unternehmensgruppe beschäftigt über 10.000 Mitarbeitende weltweit. Ihre Produkte werden in zahlreichen Zukunftsbranchen verarbeitet – von der Medizintechnik bis zur Luft- und Raumfahrt. Mit ihren Elektrolichtbogenöfen ist die SSG an vorderster Front aktiv, um den Übergang zu umweltfreundlicheren Technologien und CO2-neutralem Spezialstahl mitzugestalten. Dieses breite Spektrum soll auch das Storytelling des Geschäftsberichts 2021 widerspiegeln und erläutern.

### Das zugrundeliegende Konzept

Kreislaufwirtschaft und Recycling sind Teil der DNA der Swiss Steel Group und bieten darüber hinaus einen reichen Fundus an interessanten Geschichten rund um das Thema. Neben dem Herstellungsprozess erläutert der Geschäftsbericht, welche Einsatzmöglichkeiten die SSG-Spezialstähle bieten und welchen Beitrag der zu 100 Prozent recycelbare Stahl zur Klimaneutralität leistet. In drei Kapiteln wird der Produktionsprozess erläutert, bei dem ausschließlich Schrott in Elektrolichtbogenöfen erschmolzen und wiederverwertet wird.

### Die Zusammenarbeit

Die SSG und Kammann Rossi arbeiteten bei der Suche nach außergewöhnlichen Geschichten eng zusammen. Gemeinsam wurden Best-Practice-Beispiele und Spezialgebiete der SSG gefunden. So wurde beispielsweise für einen Luxusuhrenhersteller ein Spezialstahl aus 100 Prozent recyceltem Edelstahl aus Uhrenteilen hergestellt. Solche und weitere interessante Sidekicks runden das grafisch ausgefallene Konzept ab und geben interessante Einblicke in den Zukunftsmarkt des grünen Stahls.

### Der gemeinsame Erfolg

Das grafische und redaktionelle Ergebnis des Geschäftsberichts ist ein Zeitdokument, das neben dem Zahlenteil darstellt, wie die Swiss Steel Group mit ihrem Produktionsprozess und ihren Spezialstählen mit 100 Prozent recycelbarem Stahl einen Beitrag zur Klimaneutralität leistet.
