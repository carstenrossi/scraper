---
url: https://www.kammannrossi.de/projekt_steb_mitarbeitermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Stadtentwässerungsbetriebe Köln - Mitarbeitermagazin
---

# Kammann Rossi – Projekt – Stadtentwässerungsbetriebe Köln - Mitarbeitermagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Stadtentwässerungsbetriebe Köln


## /Mitarbeitermagazin „WASSER BESSER MACHER“


### Der Kunde und das Projekt

Bei den Stadtentwässerungsbetrieben Köln – kurz StEB Köln – arbeiten rund 650 Beschäftigte aus dem technischen und kaufmännischen Bereich. Eine Umfrage zur internen Kommunikation der StEB Köln im August 2019 ergab, dass sich Mitarbeiter Veränderungen beim Mitarbeitermagazin wünschten. Im Rahmen einer öffentlichen Ausschreibung gewann Kammann Rossi den Auftrag vü einen umfassenden Relaunch mit neuem Konzept und neuem Titelnamen. Im Mai 2020 erschien der WASSER BESSER MACHER, das (neue) Mitarbeitermagazin der Stadtentwässerungsbetriebe Köln (StEB Köln) runderneuert

### Das zugrundeliegende Konzept

Mit dem Relaunch werden die Arbeitsbereiche der StEB inhaltlich und visuell ansprechend kommuniziert und dabei das Engagement der Mitarbeiter in den Vordergrund gestellt – denn Wertschätzung ist eine zentrale Aufgabe des neuen Magazins. WASSER BESSER MACHER verankert die gendergerechte Kommunikation im Unternehmen und kommuniziert solche und andere Themen offensiv mit Hilfe des Mitarbeitermagazins.

### Die Zusammenarbeit

Für den Relaunch hat Kammann Rossi eng mit der internen Kommunikation der StEB zusammengearbeitet, gemeinsam neue Rubriken und Formate entwickelt und ein Magazin produziert, das dem kommunalen Unternehmen ein neues Gesicht gibt und gerne gelesen wird.

### Der gemeinsame Erfolg

Seit dem Relaunch von WASSER BESSER MACHER ist die Sensibilisierung für das Thema Nachhaltigkeit im Unternehmen noch ausgeprägter geworden. Auch die Wahrnehmung und Akzeptanz von strategischen Themen ist gestiegen. WASSER BESSER MACHER verankert die gendergerechte Kommunikation im Unternehmen und kommuniziert solche und andere Themen offensiv mit Hilfe des Mitarbeitermagazins. Für die redaktionelle uns visuelle Umsetzung wurde das Magazin mittlerweile mehrfach (international) ausgezeichnet.
