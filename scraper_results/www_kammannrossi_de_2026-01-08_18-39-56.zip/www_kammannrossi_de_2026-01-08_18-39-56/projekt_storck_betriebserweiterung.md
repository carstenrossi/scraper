---
url: https://www.kammannrossi.de/projekt_storck_betriebserweiterung
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Storck – Betriebserweiterung Halle
---

# Kammann Rossi – Projekt – Storck – Betriebserweiterung Halle

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Storck


## /Informationen zur Betriebserweiterung Halle


### Der Kunde und das Projekt

Der Süßwarenhersteller Storck plant eine Betriebserweiterung am Standort Halle (Westfalen), um sich als Unternehmen zukunftsfähig aufzustellen. Seit Juni 2021 ist der Bebauungsplan rechtskräftig. Da die Erweiterungsmaßnahmen von großem, öffentlichen Interesse sind, möchte Storck proaktiv und transparent informieren.

### Das zugrundeliegende Konzept

Von Storck beauftragt, konzipierte Kammann Rossi einen Webauftrittmit eigener URL, unterstützte bei der Textarbeit und setzte den Launch im modernen Design im März 2022 mit dem Toolpagestripum. Das Ziel: Interessierte sollen sich ausführlich über den Ausbau des Werkes und die Hintergründe informieren sowie Fortschritte der Bau- und Ausgleichsmaßnahmen verfolgen können.

### Die Zusammenarbeit

Kammann Rossi hat den Webauftritt konzipiert, das Layout gestaltet und redaktionelle Arbeiten übernommen.

### Der gemeinsame Erfolg

Die Website zur Betriebserweiterung mit den drei Reitern (Rubriken) Fortschritt, Planungen und Hintergründe informiert mit zahlreichen Beiträgen stets aktuell über die Betriebserweiterung mit all ihren Facetten. Mit zahlreichen Fotos und interaktiven Karten zeigt Storck – mit 3.200 Mitarbeitern der größte Arbeitgeber in Halle – welche Maßnahmen zukünftig geplant sind und welche aktuell umgesetzt werden.
