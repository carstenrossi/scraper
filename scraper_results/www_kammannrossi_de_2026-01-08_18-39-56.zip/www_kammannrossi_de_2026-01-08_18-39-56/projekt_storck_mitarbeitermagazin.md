---
url: https://www.kammannrossi.de/projekt_storck_mitarbeitermagazin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Storck – Mitarbeitermagazin
---

# Kammann Rossi – Projekt – Storck – Mitarbeitermagazin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Storck


## /Mitarbeitermagazin „Wir von Storck“


### Der Kunde und das Projekt

Nach Analyse und überzeugenden Entwürfen von Kammann Rossi im Frühjahr 2021 beauftragte der Süßwarenhersteller Storck Kammann Rossi mit der Neukonzeption des Mitarbeitermagazins „Wir von Storck“. Die Maßgabe lautete: ein zeitgemäßes und informatives Mitarbeitermagazin mit redaktionellen Formaten entwickeln, die die Arbeit bei Storck und das Miteinander anschaulich und authentisch präsentieren.

### Das zugrundeliegende Konzept

Die familiäre Botschaft „Wir von Storck“, die der Titel bereits seit 1986 sendet, sollte sich stärker in den redaktionellen und grafischen Formaten ausdrücken. In abwechslungsreichen journalistischen Stilformen und redaktionellen Elementen werden Mitarbeiterinnen und Mitarbeiter, Teams und Abteilungen in den Fokus gerückt. Formate wie „Stolz wie Storck“ – ein Kurzportrait zu einem Markenprodukt von Storck – oder „Was machen Sie da?“, ein ansprechendes Bild aus der Arbeitswelt, das die persönlichen Aufgaben im Unternehmen beispielhaft vorstellt, verstärken die Identifikation mit dem Unternehmen als solches.

### Die Zusammenarbeit

Neben der gedruckten Ausgabe von „Wir von Storck“ wird auch eine digitale Ausgabe in Deutsch und Englisch mitpagestriprealisiert. In dieser werden Beiträge redaktionell verlängert und durch audiovisuelle Elemente ergänzt.

### Der gemeinsame Erfolg

Nach dem Relaunch ist die Botschaft „Wir von Storck“ im gesamten Heft Programm. Formate wie „Stolz wie Storck“ oder „Was machen Sie da?“ binden Mitarbeiterinnen und Mitarbeiter der verschiedenen Unternehmensbereiche ein und erhöhen die Identifikation. Auch die digitale Version der „Wir von Storck“ wird sehr gut angenommen und hat die Mitarbeiterkommunikation positiv verstärkt und erweitert.
