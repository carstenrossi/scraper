---
url: https://www.kammannrossi.de/projekt_thalia-relaunch-corporate-website
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Thalia / Relaunch Corporate Website
---

# Kammann Rossi – Projekt – Thalia / Relaunch Corporate Website

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Thalia


## /Relaunch Corporate Website


### Der Kunde und das Projekt

Thalia, marktführender Buchhändler in Deutschland, Österreich und der Schweiz, bietet nicht nur ein umfangreiches Netzwerk von rund 500 stationären Buchhandlungen, sondern mit App und Onlineshop auch ein umfassendes digitales Angebot. Das Unternehmen, das sich vor allem als „Geschichtenentdecker“ versteht, beabsichtigte mit dem Relaunch seiner Corporate Website unter anderem, diese Kernkompetenz noch stärker hervorzuheben.

### Das zugrundeliegende Konzept

Die neue Online-Präsenz sollte die besonderen Eigenschaften, Werte und Ziele der Marke Thalia umfassend widerspiegeln und dafür zentrale Themen – wie etwa das Engagement für Bildung und Kultur – in den Vordergrund rücken. Damit die Corporate Website zudem allen aktuellen Nutzeranforderungen entspricht, wurden neben den inhaltlichen auch zahlreiche gestalterische Anpassungen vorgenommen. Ziel ist es, die Plattform nun sukzessive zum zentralen Informationsmedium für die externe Kommunikation auszubauen.
Highlights des Relaunchs beinhalten:
- Emotionales Storytelling: Mit den „Thalia Geschichten“ auf der Startseite hat Thalia nun die Möglichkeit, alle wichtigen Neuigkeiten und Inhalte aus dem Unternehmenskosmos erzählerisch attraktiv aufzubereiten und um Bildergalerien und Bewegtbild zu ergänzen
- Interaktive Features: Einführung von Text-to-Speech-Funktionalität, um den Geschichten Leben einzuhauchen.
- Visuelle Attraktivität: Große emotionale Fotobühnen und kleinere Animationen, die die Benutzererfahrung verbessern.
- Moderne Webstandards: Einsatz von Slidern, Flipcards und einem tagesaktuellen LinkedIn-Feed.
- Erweiterter Inhalt: Mehr Raum für Themen wie Nachhaltigkeit und Bildung & Kultur, um tiefere Einblicke in diese Bereiche zu ermöglichen.
- Design-Update: Neue Gestaltungselemente wie das Thalia Buch-Shape und eine ergänzende Schreibschrift, die im Rahmen des Corporate Design Refreshs entwickelt wurden.

### Die Zusammenarbeit

Kammann Rossi übernahm die strategische Beratung, die Konzeptentwicklung sowie die kreative Entwicklung von Inhalten, UX-Design und Gestaltung für die Corporate Website von Thalia. Auch ihre Realisierung begleitete die Agentur – in enger Zusammenarbeit mit Thalias Umsetzungspartner.

### Der gemeinsame Erfolg

Der Relaunch der Corporate Website von Thalia markiert einen wichtigen Schritt: Durch neue Inhalte, frische Designelemente und interaktive Features ist eine moderne, userfreundliche und dynamische Plattform entstanden, die nicht nur Thalias Leidenschaft für Geschichten, sondern auch das große unternehmerische Engagement für Nachhaltigkeit und Kultur widerspiegelt.
