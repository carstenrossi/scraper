---
url: https://www.kammannrossi.de/projekt_ubs-real-estate-switzerland-nachhaltigkeitsbericht-2016/17
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – UBS Real Estate Switzerland / Nachhaltigkeitsbericht 2016/17
---

# Kammann Rossi – Projekt – UBS Real Estate Switzerland / Nachhaltigkeitsbericht 2016/17

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# UBS Real Estate Switzerland


## /Nachhaltigkeitsbericht 2016/2017


### Beschreibung

Nachhaltigkeit ist ein zentrales Thema beim Schweizer Immobiliengeschäft von UBS Asset Management. Aufgrund des global steigenden Energiebedarfs, der damit verbundenen höheren Kosten und des gesteigerten Bewusstseins der Menschheit, wie wichtig eine intakte Umwelt ist, wird Nachhaltigkeit in der Immobilienbranche auch weiter an Bedeutung gewinnen.

### Erfolg

Als langjähriger, verantwortungsvoller Investor räumt UBS diesem Thema Aufmerksamkeit ein, um Immobilienanlagelösungen unter Nachhaltigkeitsaspekten weiterzuentwickeln. Über die strategische Herangehensweise informiert der übergeordnete Nachhaltigkeitsbericht von Real Estate Switzerland. Die Immobilienfonds „UBS Direct Urban“, „UBS Direct Residential“, „UBS Foncipars“, „UBS Sima“, „UBS Anfos“ und „UBS Swissreal“ sowie die beiden Immobilienanlagegruppen der Anlagestiftung der UBS für Personalvorsorge UBS AST Immobilien Schweiz und AST Kommerzielle Immobilien Schweiz stellen ihr Engagement in ihren separaten Nachhaltigkeitsberichten dar. Alle Nachhaltigkeitsberichte erfüllen die Standards der Global Reporting Initiative (GRI).
