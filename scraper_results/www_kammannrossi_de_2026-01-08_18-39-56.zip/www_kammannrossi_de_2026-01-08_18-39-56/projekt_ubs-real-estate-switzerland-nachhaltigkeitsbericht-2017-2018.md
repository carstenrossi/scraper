---
url: https://www.kammannrossi.de/projekt_ubs-real-estate-switzerland-nachhaltigkeitsbericht-2017-2018
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – UBS / Nachhaltigkeitsbericht 2017/2018
---

# Kammann Rossi – Projekt – UBS / Nachhaltigkeitsbericht 2017/2018

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# UBS Real Estate Switzerland


## /Nachhaltigkeitsbericht 2017/2018

Das Immobiliengeschäft Real Estate Switzerland von UBS Asset Management schafft seit über 75 Jahren nachhaltigen Mehrwert mit intelligenten Immobilienlösungen. Die auf Nachhaltigkeit ausgerichtete Entwicklung ist eine wichtige Zielsetzung der Berichterstattung.
Nachhaltigkeit ist ein zentrales Thema beim Schweizer Immobiliengeschäft von UBS Asset Management. „Unser Credo ist ,Wir leben Immobilien‘. Das heißt für uns nicht nur ökonomisch, sondern im Einklang mit Umwelt und Gesellschaft zu handeln“, erklärt Daniela Jorio, Nachhaltigkeitsbeauftrage bei UBS Real Estate Switzerland. Seit 2018 realisiert UBS die Nachhaltigkeitsberichte der acht Einzelfonds und den Gesamtnachhaltigkeitsbericht für Real Estate Switzerland in Deutsch, Französisch und Englisch mit Sustainsev und Kamman Rossi.

### Erfolg

Als langjähriger, verantwortungsvoller Investor räumt UBS diesem Thema Aufmerksamkeit ein, um Immobilienanlagelösungen unter Nachhaltigkeitsaspekten weiterzuentwickeln. Über die strategische Herangehensweise informiert der übergeordnete Nachhaltigkeitsbericht von Real Estate Switzerland. Die Immobilienfonds „UBS Direct Urban“, „UBS Direct Residential“, „UBS Foncipars“, „UBS Sima“, „UBS Anfos“ und „UBS Swissreal“ sowie die beiden Immobilienanlagegruppen der Anlagestiftung der UBS für Personalvorsorge UBS AST Immobilien Schweiz und AST Kommerzielle Immobilien Schweiz stellen ihr Engagement in ihren separaten Nachhaltigkeitsberichten dar. Alle Nachhaltigkeitsberichte erfüllen die Standards der Global Reporting Initiative (GRI).
