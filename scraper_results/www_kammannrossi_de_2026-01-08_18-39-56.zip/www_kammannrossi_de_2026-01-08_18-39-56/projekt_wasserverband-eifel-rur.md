---
url: https://www.kammannrossi.de/projekt_wasserverband-eifel-rur
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Projekt – Wasserverband Eifel-Rur / Hochwasserresilienz
---

# Kammann Rossi – Projekt – Wasserverband Eifel-Rur / Hochwasserresilienz

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### PROJEKT@KR


# Wasserverband Eifel-Rur


## /Info-Broschüre und Website zum Thema Hochwasserresilienz


### Der Kunde und das Projekt

Nach dem Hochwasser vom Juli 2021 hat der Wasserverband Eifel-Rur (WVER) einen Maßnahmenkatalog zur Verbesserung der Hochwasserresilienz erarbeitet. Für die Kommunikation engagierte der WVER im März 2022 Kammann Rossi. Bereits im Juli 2022 erschien eine 16-seitige Info-Broschüre; die neue Websitehochwassergefahrenvorbeugen.deging zeitgleich live.

### Das zugrundeliegende Konzept

Für die Broschüre als auch für die Website hat Kammann Rossi jeweils ein Konzept erstellt, das den WVER überzeugt hat. Das Konzept der Broschüre setzt auf eine klare Strukturierung wichtiger Informationen und die direkte Ansprache der Bürgerinnen und Bürger. Transparent werden den Leserinnen und Lesern die Herangehensweise erläutert und die die einzelnen Maßnahmen übersichtlich und bebildert erläutert. Auf der Website werden die Maßnahmen zum Hochwasserschutz stetig ergänzt. Zudem finden Besucher Termine zu Info-Veranstaltungen und erfahren, wie man selbst durch bauliche Maßnahmen zum Objekt- und Hochwasserschutz beitragen kann.

### Die Zusammenarbeit

Kammann Rossi hat die Informationsbroschüre mit dem Titel „Gemeinsam vorbeugen. Hochwasser Resilienz im Einzugsgebiet der Gewässer Inde und Vicht" konzipiert und sämtliche Texte erstellt. In regelmäßiger Abstimmung mit dem WVER hat Kammann Rossi hier bewusst auf eine verständliche Sprache bei komplexen Inhalten gesetzt.

### Der gemeinsame Erfolg

Wir tun eine ganze Menge! Der WVER kann mit der Broschüre und der Website demonstrieren, dass er verschiedenste Maßnahmen zum Hochwasserschutz im Einzugsgebiet von Inde und Vicht ergriffen hat – und weitere sukzessive umsetzen wird. Der WVER kann somit seine engagierte Arbeit für den Hochwasserschutz online und offline den Bürgerinnen und Bürgerinnen im Einzugsgebiet nahebringen und zukünftige Maßnahmen auf der dynamisch wachsenden Website – auch in leichter Sprache – ergänzen. Online auch mit einer digitalen Karte.
