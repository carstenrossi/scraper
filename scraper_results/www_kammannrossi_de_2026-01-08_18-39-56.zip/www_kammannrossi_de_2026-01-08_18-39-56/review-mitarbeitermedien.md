---
url: https://www.kammannrossi.de/review-mitarbeitermedien
scraped_at: 2026-01-08 18:39
title: Review Magazine und Medien
---

# Review Magazine und Medien

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

# Wie gut sind Ihre Magazine und Medien?


## /Unverbindlich – Neutral – Ehrlich


### Werden Sie gerne kritisiert? Dann sind wir die richtigen für Sie!

Sie meinen, ein Blick von außen auf Ihre Unternehmensmedien (Print- und Digitale Magazine, Blogs, Newsletter, Content Hubs etc.) schadet nicht? Sie glauben, konstruktive Kritik bringt Sie weiter? Wir analysieren Ihre Unternehmens- und Mitarbeitermedien im Hinblick auf:
- Name und Front-Page-Gestaltung
- Dramaturgie und Rubrizierung / Informationsarchitektur
- Gestaltung und Bildsprache
- Textqualität und Stilformen
- Einbettung in Ihre Kommunikationsstrategie
Füllen Sie einfach unten das Formular aus. Sie erhalten eine E-Mail von uns und schicken einen Link, ein PDF oder Screenshots Ihrer Medien in einer Präsentation direkt an Ihren Ansprechpartner bei Kammann Rossi.
Unsere Anmerkungen notieren wir Ihnen direkt mit kleinen gelben Zetteln ins Dokument – diese Datei können Sie dann mit Ihren Kollegen teilen und bei Rückfragen gerne auf uns zukommen. Selbstverständlich unterzeichnen wir gerne eine Vertraulichkeitserklärung.

### Jetzt Review anfordern

