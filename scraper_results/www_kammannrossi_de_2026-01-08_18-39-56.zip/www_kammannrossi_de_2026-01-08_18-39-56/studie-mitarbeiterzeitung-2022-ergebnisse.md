---
url: https://www.kammannrossi.de/studie-mitarbeiterzeitung-2022-ergebnisse
scraped_at: 2026-01-08 18:39
title: Studie Die Zukunft der Mitarbeiterzeitung 2022 - Ergebnisse
---

# Studie Die Zukunft der Mitarbeiterzeitung 2022 - Ergebnisse

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

# „Die Zukunft des Mitarbeiter­magazins 2022“


## /Ausführliche Ergebnisse

Über 250 Teilnehmer aus nahezu allen relevanten Branchen der Wirtschaft und staatlichen Institutionen im DACH-Raum haben an der diesjährigen Befragung zur Zukunft der Mitarbeiterzeitung von Kammann Rossi undSCM (School for Communication and Management) teilgenommen.Nach der Kurzauswertung liegen nun die ausführlichen Ergebnisse vor.Ein Auszug aus unserem Fazit:
• Die MAZ spielt künftig (nur) eine Rolle unter vielen im Kommunikations-Ensemble.
• Die Entwicklung hin zum Mitarbeitermagazin als mobile App wurde bestätigt – das gedruckte Magazin hat aber nach wie vor einen hohen Stellenwert in den Unternehmen.
• Die überwiegende Mehrheit der Befragten glaubt, dass der Etat für die Mitarbeiterzeitung eher stagnieren wird.
Füllen Sie einfach das Formular unten aus, um die Auswertung im PDF-Format herunterzuladen.

### Hier geht's zum Download

