---
url: https://www.kammannrossi.de/team
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team
---

# Kammann Rossi – Team

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

# TEAM@KR


## /Creators with passion

- Geschäftsführung
- AI & Digital
- Produktion & Projektmanagement
- Design
- Content & Strategie
- Alle
