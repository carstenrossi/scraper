---
url: https://www.kammannrossi.de/team_arne-buedts
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Arne Büdts
---

# Kammann Rossi – Team – Arne Büdts

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Arne Büdts


## /Leiter Design

Arne Büdts studierte Kommunikationsdesign in Düsseldorf und Köln und ist seit 2009 für Kammann Rossi tätig. Als Kreativ-Direktor ist er verantwortlich für Konzeption, Layout, Beratung und Umsetzung von Kunden- und Mitarbeitermagazinen, Geschäftsberichten, Nachhaltigkeitsberichten, Corporate Designs und Kampagnen für Kunden wie u. a. BDEW,Clariant,Commerzbank,Evonik,GTAI, MANN+HUMMEL,Metro Group undSAP.
In seiner Freizeit ist er meistens mit der Familie unterwegs – es sei denn, er braut sein eigenes Bier.
> Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
—Unbekannt
