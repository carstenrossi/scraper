---
url: https://www.kammannrossi.de/team_bernd-kirchhoefer
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Bernd Kirchhoefer
---

# Kammann Rossi – Team – Bernd Kirchhoefer

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Bernd Kirchhoefer


## /Audio & Video Specialist

Seit 2015 ist Bernd Kirchhoefer bei Kammann Rossi für den Bereich Audio- und Videoediting zuständig. Er verfügt über eine 30jährige Berufserfahrung als Produzent, Regisseur und realisierte zahlreiche Film- und Videoprojekte für Fernseh- und Hörfunksender sowie Auftraggeber aus der Wirtschaft und Industrie.
Wenn er grade keine Projekte auf dem Tisch hat, gestaltet er seine Fensterfront nach dem goldenen Schnitt.
> „Sand wird überschätzt. Es sind doch nur winzig kleine Steine.“
—Eternal sunshine of the spotless mind
