---
url: https://www.kammannrossi.de/team_carsten-rossi
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Carsten Rossi
---

# Kammann Rossi – Team – Carsten Rossi

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Carsten Rossi


## /Geschäftsführer

Als Geschäftsführer und Experte für Content Marketing berät Carsten Rossi große und mittelständische Unternehmen auf ihrem Weg zur Content Excellence. Seine aktuellen Key Accounts sind unter anderem Canada Life, Continental, die Deutsche Bahn, Fiducia & GAD und Royal Canin. Seinen ersten Online-Zugang hatte er 1984, was einen gewissen Hang zum Digitalen und die damit einhergehende Ungeduld erklärt.
Er ist häufig gebuchter Sprecher und Seminarleiter auf Events wie der CeBit, den Praxistagen Interne Kommunikation und Content Marketing oder der CMCX, engagiert sich im BVDW und CMF und kümmert sich um die agentureigenen Social-Media-Kanäle.
MitAssistantOStreibt Carsten Rossi aktuell eine innovative KI-Lösung voran, die Kommunikationsprozesse revolutioniert und Unternehmen ermöglicht, sich auf ihre Kernaufgaben zu konzentrieren.
In seiner Freizeit liest er, läuft er und spielt mit seinen drei Kindern. Außerdem regt er sich jedes Wochenende leidenschaftlich über den Effzeh auf und teilt dieses Hobby mit Sebastian.
> Bazinga!
—S. Cooper
