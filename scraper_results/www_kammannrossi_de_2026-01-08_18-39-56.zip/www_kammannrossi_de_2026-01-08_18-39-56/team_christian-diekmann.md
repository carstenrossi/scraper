---
url: https://www.kammannrossi.de/team_christian-diekmann
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Christian Diekmann
---

# Kammann Rossi – Team – Christian Diekmann

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Christian Diekmann


## /Art Director

Christian Diekmann absolvierte zunächst eine Ausbildung zum Mediengestalter Digital & Print, bevor er an der KISD Fachhochschule in Köln Design studierte und sein gestalterisches Können und Wissen vertiefte. Der ArtDirectorhat sich auf die Kreativkonzeption von Printmedien der Unternehmens- und Nachhaltigkeitskommunikation spezialisiert und zählt das Entwickeln und Umsetzen von Infografiken, komplexen Schaubildern und Piktogrammen zu seinen Steckenpferden.
Der Vater von zwei Töchtern ist großer Eishockey Fan und glühender Anhänger der Kölner Haie. Seine freie Zeit verbringt er am liebsten mit seiner Familie–wenn immer möglich auf Reisen in den asiatischen Raum.
> „A lineis a dot that went fora walk.“
—Paul Klee
