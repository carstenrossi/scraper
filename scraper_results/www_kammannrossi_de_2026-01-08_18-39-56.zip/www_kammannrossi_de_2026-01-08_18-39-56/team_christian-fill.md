---
url: https://www.kammannrossi.de/team_christian-fill
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Dr.-Ing. Christian Fill
---

# Kammann Rossi – Team – Dr.-Ing. Christian Fill

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Dr.-Ing. Christian Fill


## /Geschäftsführer

Als Geschäftsführer verstärkt er KammannRossi seit Dezember 2020 mit seiner Erfahrung aus rund 20 Jahren Content Marketing und Corporate Publishing. Der promovierte Chemieingenieur hat seine Leidenschaft, das Schreiben, zum Beruf gemacht – vor allem B2B-Kunden profitieren gerne davon. Als Netzwerker ist er in den Verbänden CMF und BVDW unterwegs.
Wenn die Bürotür ins Schloss gefallen ist, steht er gerne am Herd, kocht für die Familie, lümmelt im Lese- oder Kinosessel oder verausgabt sich im Aikido-Dojo.
> „Bunbu ryodo – Schwert und Feder sind beides Wege der Erleuchtung.“
