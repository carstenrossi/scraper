---
url: https://www.kammannrossi.de/team_florian-stuermer
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Florian Stürmer
---

# Kammann Rossi – Team – Florian Stürmer

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Florian Stürmer


## /Digital & Technical Specialist

Florian Stürmer ist bereits seit 2009 bei Kammann Rossi. Als Digital Consultant verantwortet er die Umsetzung neuer technischer Trends und ist für die Implementierung von Online-Projekten zuständig. Darüber hinaus kümmert er sich um Beratung, technische Entwicklung und Umsetzung von Online-Geschäftsberichten sowie Kunden- und Mitarbeitermagazinen. Zu seinen Kunden gehören oder gehörten u. a. ARAG, Fiducia GAD, Bertelsmann Stiftung, Rolls-Royce Power Systems und Symrise.
Aktuell widmet er sich der Entwicklung vonAssistantOS, einer KI-basierten Lösung, die als kreativer Assistent den Fokus wieder auf das Wesentliche lenkt.
In seiner Freizeit verfolgt er alle Spiele seines Lieblingsvereins Borussia Dortmund - am liebsten im Stadion.
> „That’s the difference between you and me: You wanna lose small. I wanna win big.“
—Harvey Specter
