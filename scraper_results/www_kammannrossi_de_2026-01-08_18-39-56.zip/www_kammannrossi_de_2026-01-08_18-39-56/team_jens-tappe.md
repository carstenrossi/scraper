---
url: https://www.kammannrossi.de/team_jens-tappe
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Jens Tappe
---

# Kammann Rossi – Team – Jens Tappe

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Jens Tappe


## /Senior Art Director

Jens Tappe studierte Kommunikationsdesign in Köln und verfügt über nunmehr 24Jahre Erfahrung als Designer für Geschäfts- und Nachhaltigkeitsberichte. Als Senior Art Director weiß er, wie man die Fäden zusammenhält und ist bei Kammann Rossi von der Konzeption über das Layout bis hin zum Projektmanagement in namhafte Projekte involviert. Unter anderem zählte oder zählt er so unterschiedliche Unternehmen wie Bahlsen,Spar- und Bauverein Dortmund,die Oldenburgische Landesbank,Deufolund den Flughafen Köln-Bonn zu seinen Kunden.
Der Vater von zwei fast erwachsenen Söhnen bewegt sich gerne und viel. So kommt er nicht nur täglich mit dem Fahrrad in die Agentur, sondern läuft auch mehrmals wöchentlich durch den Kölner Stadtwald oder wandert im Urlaub in den Bergen.
> „Alles ist fertig;es muss nur noch gemacht werden.“
—Vox populi
