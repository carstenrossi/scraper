---
url: https://www.kammannrossi.de/team_jessica-fradin
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Jessica Fradin
---

# Kammann Rossi – Team – Jessica Fradin

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Jessica Fradin


## /Office Management

> „Manchmal zeigt sich der Weg erst, wenn wir anfangen, ihn zu gehen.“
—Paulo Coelho
