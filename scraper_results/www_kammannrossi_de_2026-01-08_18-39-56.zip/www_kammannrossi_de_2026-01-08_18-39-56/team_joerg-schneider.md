---
url: https://www.kammannrossi.de/team_joerg-schneider
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Jörg Schneider
---

# Kammann Rossi – Team – Jörg Schneider

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Jörg Schneider


## /Layouter & Illustrator

Jörg Schneider ist seit 2008 in den Bereichen Layout, Illustration und Produktion bei Kammann Rossi in Print- und Web-Anwendungen tätig. Er betreut unter anderem Unternehmen wie Dr. Kleeberg & Partner oder Atruvia vom grafischen Konzept bis zur Realisation. Auch seine langjährige Erfahrung bei der Erstellung von Geschäftsberichten kommt z.B. bei den ARAG Geschäfts- und Nachhaltigkeitsberichten zum Einsatz. Jörg Schneider betreut unsere Praktikanten im grafischen Bereich, beginnend bei der Vermittlung von Gestaltungsgrundlagen bis zur Erstellung des Praktikumsberichts in Form eines professionell gestalteten Magazins.
In seiner Freizeit entspannt er sich mit Yoga und Wandern.
> Du kannst eine Brücke erst dann überqueren, wenn du sie erreicht hast.
