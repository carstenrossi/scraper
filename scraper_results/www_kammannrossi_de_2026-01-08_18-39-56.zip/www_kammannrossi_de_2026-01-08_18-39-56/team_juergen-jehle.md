---
url: https://www.kammannrossi.de/team_juergen-jehle
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Jürgen Jehle
---

# Kammann Rossi – Team – Jürgen Jehle

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Jürgen Jehle


## /Senior Editor

Jürgen Jehle verfügt über 25 Jahre Erfahrung im Bereich Journalismus, Kundenkommunikation, Content Marketing sowie Presse- und Öffentlichkeitsarbeit. Neben der Redaktionsleitung für Projekte des Jahreszeiten-Verlages und Chef-vom-Dienst-Stationen bei Gruner+Jahr entwickelt und realisiert er auf Agenturseite seit über 15 Jahren zahlreiche Kunden- und Mitarbeitermedien, die international ausgezeichnet wurden. Darunter Magazine für die Stiftung Preußischer Kulturbesitz, Electronic Arts, die Aktion Mensch sowie zahlreiche Finanzinstitute und mittelständische Unternehmen.
In seiner Freizeit ist der Flohmarktliebhaber immer auf der Suche nach verschollenen Schätzen und schreibt Bücher in alemannischer Mundart.
> Leben ist Reinschrift.
