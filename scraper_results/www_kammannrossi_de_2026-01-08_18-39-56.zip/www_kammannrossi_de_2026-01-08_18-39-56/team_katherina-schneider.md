---
url: https://www.kammannrossi.de/team_katherina-schneider
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Katherina Schneider
---

# Kammann Rossi – Team – Katherina Schneider

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Katherina Schneider


## /Leiterin Projektmanagement & Produktion

Katherina Schneider ist seit 2006 Projektmanagerin und Beraterin bei Kammann Rossi und in dieser Funktion tätig für mittelständische und große Unternehmen wie zum Beispiel ARAG,Carl Zeiss, Clariant, Continental,Henkel oder MANN+HUMMEL. Seit 2017 leitet sie den Bereich Projektmanagement und Produktion.
In ihrer Freizeit entspannt sie sich am besten beim Laufen. Außerdem reist Katherina leidenschaftlich gern und erkundet dabei sämtliche Fleckchen der Erde.
> „Everything will be alright in the end if it‘s not all right then it‘s not the end.“
—Fernando Sabino
