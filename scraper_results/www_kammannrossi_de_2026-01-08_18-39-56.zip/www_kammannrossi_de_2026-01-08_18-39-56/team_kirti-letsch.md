---
url: https://www.kammannrossi.de/team_kirti-letsch
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Kirti Letsch
---

# Kammann Rossi – Team – Kirti Letsch

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Kirti Letsch


## /Senior Editor

Kirti Letsch entwickelt und betreut seit mehr als 10 Jahren Publikationen für die interne und externe Kommunikation ihrer Kunden. Ausgebildet an der Burda Journalistenschule schreibt und schrieb die bilinguale Redakteurin für zahlreiche international tätige Unternehmen wie Continental, Telefónica, Siemens, MAN, und Freudenberg Sealing Technologies auf deutsch und englisch.
Off the clock, erkundet sie am liebsten heimische Wälder oder ferne Länder. Außerdem begeistert sie sich für kreative und fantasievolle Geschichten in jeglicher Darstellungsform.
> „One day I will find the right words, and they will be simple.“
—Jack Kerouac, The Dharma Bums
