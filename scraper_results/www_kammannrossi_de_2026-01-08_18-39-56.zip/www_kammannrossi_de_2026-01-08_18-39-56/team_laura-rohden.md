---
url: https://www.kammannrossi.de/team_laura-rohden
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Laura Rohden
---

# Kammann Rossi – Team – Laura Rohden

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Laura Rohden


## /Duale Studentin

Laura Rohden verstärkt das Team von Kammann Rossi seit 2022 als duale Studentin. An zwei Tagen pro Woche widmet sie sich ausschließlich ihrem Mediendesign-Studium an der iu in Köln. An den übrigen drei Tagen unterstützt sie unser Designteam und sammelt dabei wertvolle praktische Erfahrung.In ihrer Freizeit begeistert sich Laura für analoge Fotografie und werkelt fleißig an eigenen Mixed-Media-Projekten. Sie liebt Filme und Musik und kennt alle ihre Favoriten in- und auswendig. Kein Wunder also, dass man Laura am Wochenende meist beim Tanzen oder in Ausstellungen treffen kann.
> „There is no greater instrument for understanding the visual world than the hand and a pencil.“
—Milton Glaser
