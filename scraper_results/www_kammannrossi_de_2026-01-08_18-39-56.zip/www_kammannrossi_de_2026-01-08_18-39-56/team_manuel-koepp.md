---
url: https://www.kammannrossi.de/team_manuel-koepp
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Manuel Köpp
---

# Kammann Rossi – Team – Manuel Köpp

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Manuel Köpp


## /Art Director

Manuel Köpp ist seit 2013 bei Kammann Rossi als Art Director tätig und arbeitet unter anderem für Kunden wie ARAG, Continental, GTAI und MANN+HUMMEL. Sein Schwerpunkt ist die Konzeption und Umsetzung von Layouts und Designs. Darüber hinaus ist er unser Spezialist für Cinema 4D und erstellt damit 3D Renderings für die verschiedensten Projekte.
In seiner Freizeit ist er ein passionierter Filmfan und Gamer mit einem besonderen Faible für gutes Essen, der immer einen Tipp für gute und ausgefallene Restaurants auf Lager hat.
> „It’s very easy to be different, but very difficult to be better.“
—Jonathan Ive
