---
url: https://www.kammannrossi.de/team_marc-ribbrock
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Marc Ribbrock
---

# Kammann Rossi – Team – Marc Ribbrock

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Marc Ribbrock


## /Leiter Content & Strategie

Marc Ribbrock ist Leiter Content & Strategie bei Kammann Rossi und seit über 15 Jahren in den Bereichen Corporate Publishing und Content Marketing tätig. Sein Wissen und seine Erfahrungen setzt er vor allem bei der Erarbeitung von Content Strategien und deren Umsetzung sowie der (Weiter-)Entwicklung von Magazinen und Content Hubs und dafür zielgerichteter Formate ein.
Der ausgebildete Redakteur hat seine Leidenschaft für Texte und Schreiben nie verloren. Sein Know-how auf diesem Gebiet gibt er in Redaktions-Workshops (u. a. „Schreiben für Online-Medien“) weiter.
Wenn er privat gerade nicht von seinen beiden Söhnen gefordert wird, geht er gerne zusammen mit seiner Frau auf Rockkonzerte und nutzt ansonsten jede Gelegenheit, selbst die Gitarre in die Hand zu nehmen, sich sportlich zu betätigen oder sich in ein gutes Buch zu vertiefen.
> Schreiben ist leicht, man muss nur die falschen Wörter weglassen.
—Mark Twain
