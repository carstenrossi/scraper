---
url: https://www.kammannrossi.de/team_marion-mueller-gotthard
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Marion Müller-Gotthard
---

# Kammann Rossi – Team – Marion Müller-Gotthard

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Marion Müller-Gotthard


## /Projektmanagerin & Beraterin

Seit 2001 ist sie Projektmanagerin bei Kammann Rossi in den Bereichen Reporting und Corporate Publishing (Print und Online). Als Projektleiterin ist sie verantwortlich für mittelständische und große Unternehmen aus den verschiedensten Branchen, z.B. ARAG, BDEW, GTAI, MANN+HUMMEL, SAP und UBS Fund Management (Switzerland) AG.
Im Herzen ist sie ein kölsches Mädchen, kennt jedes Karnevalslied und ist mindestens einmal im Jahr richtig jeck.
> „Plans are worthless but planning is everything“.
—Dwight D. Eisenhower
