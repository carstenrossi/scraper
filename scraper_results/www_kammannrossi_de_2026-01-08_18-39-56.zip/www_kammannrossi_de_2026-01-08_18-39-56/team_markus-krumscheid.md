---
url: https://www.kammannrossi.de/team_markus-krumscheid
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Markus Krumscheid
---

# Kammann Rossi – Team – Markus Krumscheid

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Markus Krumscheid


## /Art Director

Markus Krumscheid ist seit 2023 bei Kammann Rossi als Art Director tätig. Sein Schwerpunkt ist die Konzeption und Umsetzung von Layouts und Designs für Digital und Print. Darüber hinaus beschäftigt er sich mit dem Thema KI, hier insbesondere Midjourney und ChatGPT.
In seiner Freizeit fährt der zweifache Vater gerne Fahrrad, liebt gute Serien und Filme und fiebert (leidet) jedes Wochenende mit dem 1. FC Köln.
> „There are 9 rejected ideas for every idea that works.“
—Jonathan Ive
