---
url: https://www.kammannrossi.de/team_martina-thelen
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Martina Thelen
---

# Kammann Rossi – Team – Martina Thelen

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Martina Thelen


## /Content Strategist & Platform Specialist

Martina Thelen hat irgendwann mal Kommunikationsdesign studiert, aber bei Kammann Rossi schnell die Liebe zu Sozialen Medien, Networking und Kundenberatung entdeckt.
Inzwischen berät sie Kunden bei der Erarbeitung einer Content Strategie und deren Umsetzung. Martina ist auch Ansprechpartnerin für die strategische Planung von Content mitScompler, die Umsetzung Ihrer Inhalte im Social Intranet mitHaiilo / COYOoderStaffbaseund alles rund um die Inbound Marketing PlattformHubSpot.
Ihre Freizeit verbringt sie am liebsten mit ihrer Familie an der frischen Luft – oder sie vergräbt sich in ein Buch.
> „My life is a reading list.“
—John Irving
