---
url: https://www.kammannrossi.de/team_moritz-pfingsten
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Moritz Pfingsten
---

# Kammann Rossi – Team – Moritz Pfingsten

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Moritz Pfingsten


## /Consultant AI & Digital

Moritz Pfingsten studierte Kommunikationsmanagement in Osnabrück und spezialisierte sich dort auf die interne Kommunikation im Rahmen von Veränderungsprozessen. Dieser Leidenschaft ging er zunächst als Digital Workplace-Berater nach. Zudem unterstützte er die Gothaer Versicherung als Change Manager innerhalb eines konzernweiten IT-Programms.
Bei Kammann Rossi setzt Moritz sein Wissen vor allem bei der inhaltlichen und strategischen Kundenberatung ein. Sein Fokus liegt auf der Begleitung von Change- und Transformationsprojekten.
In seiner aktuellen Rolle treibt Moritz Pfingsten die Weiterentwicklung vonAssistantOSvoran, indem er innovative Prompt-Engineering-Methoden implementiert, um maximalen Mehrwert für Kunden zu generieren.
In seiner Freizeit widmet er sich am liebsten diversen Ballsportarten, sowohl auf der Couch als auch auf dem Platz. Zudem geht er regelmäßig auf Konzerte und verreist gerne, bevorzugt nach Italien.
> „Worte ändern alles.“
—Max Richard Leßmann
