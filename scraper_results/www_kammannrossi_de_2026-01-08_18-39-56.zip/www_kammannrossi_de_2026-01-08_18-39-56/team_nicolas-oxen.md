---
url: https://www.kammannrossi.de/team_nicolas-oxen
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Nicolas Oxen
---

# Kammann Rossi – Team – Nicolas Oxen

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Nicolas Oxen


## /Editor

Nicolas Oxen ist promovierter Medienwissenschaftler und hat an Universitäten und Kunsthochschulen als Dozent gearbeitet. Zu Kammann Rossi bringt ihn seine Motivation, klare und kluge Texte zu schreiben, die komplexe Themen auf den Punkt bringen und zum Weiterlesen und Weiterdenken anregen.
In seiner Freizeit dreht er gerne eine Joggingrunde im Park, spielt mit seiner kleinen Tochter oder stöpselt für ein bisschen Blues oder Funk die E-Gitarre in den Verstärker.
> „Ich weiss nicht, ob es besser wird, wenn es anders wird. Aber es muss anders werden, wenn es besser werden soll“
—Georg Christoph Lichtenberg
