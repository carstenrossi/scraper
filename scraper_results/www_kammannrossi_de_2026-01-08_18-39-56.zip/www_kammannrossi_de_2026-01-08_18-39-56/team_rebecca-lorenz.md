---
url: https://www.kammannrossi.de/team_rebecca-lorenz
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Rebecca Lorenz
---

# Kammann Rossi – Team – Rebecca Lorenz

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Rebecca Lorenz


## /Senior Editor

Seit über sieben Jahren lebt und liebt Rebecca Lorenz das Agenturleben. Sie verfügt über Erfahrung in der Magazin-Produktion, im Content Marketing sowie im Projektmanagement.
Nach einem klassischen Volontariat betreute sie als Redakteurin und Projektleiterin zahlreiche ausgezeichnete Kunden- und Mitarbeitermagazine. Darunter Magazine für den Malteser Hilfsdienst e.V., Rittal, Klingspor oder die Kölnmesse. Seit 2019 ist sie zudem zertifizierte Online-Marketing-Managerin.
Ihre Freizeit verbringt sie am liebsten lesend, backend oder reisend. Weitaus häufiger kann man sie seit der Geburt ihrer Tochter aber tobend auf dem Spielplatz beobachten.
> „I write because I don't know what I think until I read what I say.“
—Flannery O’Connor
