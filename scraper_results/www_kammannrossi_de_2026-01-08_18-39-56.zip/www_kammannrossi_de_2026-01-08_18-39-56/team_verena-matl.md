---
url: https://www.kammannrossi.de/team_verena-matl
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Verena Matl
---

# Kammann Rossi – Team – Verena Matl

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Verena Matl


## /Art Director

Verena Matl verfügt über langjährige Erfahrung sowohl bei der Umsetzung von Kunden- und Mitarbeitermagazinen, Geschäftsberichten, Corporate Designs und Kampagnen als auch im Bereich Animation und Video. Als Art-Direktorin ist Verena für das Editorial Design von „Markets Germany“ und „Markets International“ von Germany Trade & Invest zuständig und freut sich über den goldenen BCM Award 2018.
Verena hat nach jahrelanger Suche endlich eine größere Wohnung gefunden und mutiert in ihrer Freizeit zur Umzugsmanagerin.
> „If you can visualize it, if you can dream it, there's some way to do it.“
—Walt Disney
