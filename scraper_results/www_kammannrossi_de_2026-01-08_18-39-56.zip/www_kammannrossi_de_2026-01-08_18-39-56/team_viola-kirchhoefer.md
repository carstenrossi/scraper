---
url: https://www.kammannrossi.de/team_viola-kirchhoefer
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Team – Viola Kirchhoefer
---

# Kammann Rossi – Team – Viola Kirchhoefer

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### TEAM@KR


# Viola Kirchhoefer


## /Geschäftsführerin

Als Geschäftsführerin und Leiterin Controlling steuert Viola Kirchhoefer die internen Prozesse und Abläufe der Agentur. Sie bringt mehr als ein Jahrzehnt Erfahrung im Corporate Reporting und Corporate Publishing mit. Darüber hinaus unterstützt sie Kunden bei der Nachhaltigkeitskommunikation und -berichterstattung, also der Anwendung der Richtlinien der GRI oder des IIRC.
In ihrer Freizeit genießt Viola die gemeinsame Zeit mit ihrer Familie. Außerdem beweist sie ihr Organisationstalent beim Umbau ihres Hauses.
> „To begin, begin.“
—William Wordsworth
