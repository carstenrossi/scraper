---
url: https://www.kammannrossi.de/zukunft-der-mitarbeiterzeitung-studie
scraped_at: 2026-01-08 18:39
title: Kammann Rossi – Know-How – Die Zukunft der Mitarbeiterzeitung
---

# Kammann Rossi – Know-How – Die Zukunft der Mitarbeiterzeitung

- Home
- Agentur
- Team
- Projekte
- Blog
- Know-how
- KI
- Metaverse
- Karriere
- Kontakt

###### KNOW-HOW@KR


# Die Zukunft der Mitarbeiterzeitung


## /Unsere Umfrage

vonCarsten Rossi| 09.08.2018 | 5 Minuten Lesezeit
Schnelleinstieg
- Studiendesign und Teilnehmer
- Ergebnisse
- MAZ-Formate
- Erscheinungsweise und Umfang
- Budgets
- Inhalte
- Zukunft von Print-Formaten
- Bedeutung digitaler Medien
- Erfolgsmessung
Schnelleinstieg
- Studiendesign und Teilnehmer
- Ergebnisse
- MAZ-Formate
- Erscheinungsweise und Umfang
- Budgets
- Inhalte
- Zukunft von Print-Formaten
- Bedeutung digitaler Medien
- Erfolgsmessung

#### Studiendesign und Teilnehmer

In einer gemeinsamen Studie haben wir mit der Berliner School for Communication and Management (SCM) Rahmenbedingungen und Trends rund um Produktion und Akzeptanz von Mitarbeitermagazinen untersucht. Für die Studie „Die Zukunft der Mitarbeiterzeitschrift (MAZ) 2017“ wurden mehr als200 Kommunikationsprofis aus Unternehmen, Agenturen und Dienstleisternin Deutschland, Österreich und der Schweiz befragt. Es ist die dritte Studie ihrer Art.
Die Teilnehmer der Studie „Die Zukunft der Mitarbeiterzeitschrift (MAZ) 2017“ repräsentieren einen Querschnitt aus nahezu allen Betriebsgrößen und relevanten Branchen der Wirtschaft sowie wichtiger staatlicher Institutionen in den D/A/CH-Ländern.
- Rund zwei Drittel der befragten Kommunikationsprofis arbeiten in Unternehmen mitmehr als 500 Mitarbeitern. Rund 40 Prozent der Teilnehmer kommt aus Unternehmen mit bis zu 5.000 Mitarbeitern, jeder fünfte befragte Experte ist in einem Unternehmen mitbis zu 20.000 Mitarbeiterntätig.
- Technologie- und Maschinenbauunternehmensind mit einem Anteil von 9,4 Prozent vertreten,Chemie, Pharma und Automotivekommen auf jeweils 6,4 Prozent, öffentliche Einrichtungen auf 11,4 Prozent. Neben Entscheidern aus den Unternehmen waren Experten aus Kommunikationsagenturen und Dienstleistern gefragt, deren Anteil bei 12,9 Prozent lagUpdate: Dieser Artikel bezieht sich auf eine Umfrage aus 2017 – inzwischen liegen auch die Ergebnisse aus unserer aktuellen Umfrage aus 2022 vor.Klicken Sie hier, um die aktuelle Analyse herunterzuladen.

#### Die wichtigsten Ergebnisse im Überblick

Die Ergebnisse der Studie zeichnen in vielen Punkten ein durchwachsenes Bild des Mediums und seiner Rahmenbedingungen. Einerseits istdie Zahl der Mitarbeiter-Publikationenmit einem Anteil von derzeit72,5 Prozentin den Unternehmen insgesamtrückläufig. Im Jahr 2015 waren es noch 87,0 Prozent. Zugleich hat sich jedoch der Anteil der Unternehmen, die erstmals die Herausgabe einer Mitarbeiterzeitung planen, im selben Zeitraum auf vier Prozent verdoppelt. Das Mitarbeitermagazinbleibtsomit auch in Zukunft einwichtiges – und für viele Entscheider unverzichtbares – Instrument der internen Kommunikation.
Nach den Ergebnissen der Studie von Kammann Rossi und SCM liegtdie Zukunftder Mitarbeiterzeitung dabei klar erkennbarim Digitalen, wobei die gedruckte Ausgabe derzeit noch immer ihre Berechtigung findet.
Um die strategische Planung des Mitarbeitermagazins und seiner Formate zu unterstützen und somit einen – sowohl inhaltlich als auch wirtschaftlich sinnvollen – Betrieb des Mediums zu gewährleisten, erscheint einekontinuierliche Erfolgskontrolleunverzichtbar.

#### In welchen Formaten erscheinen Mitarbeiterzeitungen

Die Printausgabe ist nach den Erhebungen von Kammann Rossi und SCM nach wie vor das in den Unternehmen am häufigsten verbreitete Format:
- 83,5 Prozent aller Mitarbeitermagazine erscheinen demnach in gedruckter Form.
Die weiteren Formate werden digital bereitgestellt:
- Dasstatische PDFdes Mitarbeitermagazins dominiert mit einem Anteil von54,5 Prozentaller Ausgaben die digitalen Kanäle.
- Onlineist das Mitarbeitermagazin ebenfalls hohen Anteil von 35,2 Prozent vertreten - überwiegend im Intranet.
- Eher selten werden genutzt: dynamische PDF und E-Magazine (jeweils 6,9 Prozent), speziell gestaltete eigene Plattformen (6,2 Prozent), Apps für mobile Endgeräte (durchschnittlich 2,8 Prozent) und Blogs (1,4 Prozent).

#### Erscheinungsweise und Umfang

Der überwiegende Teil der Mitarbeitermagazine erscheintdrei bis sechs mal jährlich(64,1 Prozent). Rund ein Fünftel der Unternehmen produziert mehr als sechs Ausgaben pro Jahr (22,1 Prozent). Die gedruckte Ausgabe umfasst dabei meist zwischen zwölf und 28 Seiten (38,6 Prozent). Nur jedes vierte Heft ist dünner als ein 12-Seiter, jedes dritte umfangreicher als 28 Seiten (35,7 Prozent).
Zum Vergleich: Knapp zwei Drittel aller Ausgaben, die für das Intranet aufbereitet werden, umfassenmaximal 15 Artikel. Ein Drittel der Online-Ausgaben besteht aus bis zu 30 Artikeln.
Was die Vorstellungen zu Umfang und Erscheinungsturnus angeht, sind sich die Unternehmen mit und ohne Mitarbeitermagazin laut Umfrage einig.

#### Budgets von Mitarbeiterzeitschriften

Die für die Produktion von Mitarbeitermagazinen zur Verfügung stehendenBudgetsbleiben sowohl im Vergleich zu früheren Studien als auch in den Prognosen der Befragtenkonstant:Knapp zwei Drittel erwarten in Zukunft keine Budgetsteigerungen, 19,3 Prozent der Befragten gehen gar von Einsparungen bei der MAZ aus. Andererseits rechnen 14,3 Prozent mit einer Erhöhung der zur Verfügung stehenden Mittel.
Dabei liegen die Jahresetats in vielen Unternehmen im Vergleich zu Kaufmagazinen auf einem allgemein eher niedrigen Niveau:
- Rund ein Drittel der Redaktionen muss mit weniger als 10.000 Euro jährlich auskommen (35,9 Prozent).
- In einem weiteren Drittel stehen bis zu 50.000 Euro per Anno für die MAZ zur Verfügung.
- 16 Prozent aller Unternehmen investiert bis zu 100.000 Euro in ein Mitarbeitermagazin. Nur 18,3 Prozent sehen höhere Etats vor.

#### Welche Inhalte werden kommuniziert

Die thematischen Schwerpunkte von Mitarbeitermagazinen liegen sowohl auf Personen und Teams als auch auf Produkten, Projekten und weiteren Sachthemen aus den Unternehmen. Beide Bereiche – Menschen und betriebliche Belange – werden von den Redaktionen  in ihrer Bedeutung als in etwa ebenbürtig betrachtet. Gleiches gilt für die Tonality der Beiträge: Sachliche und emotionale Ansprache halten sich die Waage.Bei der Verteilung der inhaltlichen Schwerpunkte auf die zur Verfügung stehenden Medienkanäle setzen die Studienteilnehmer jedoch klare Prioritäten:
- Für 77 Prozent der Befragten eignen sichHintergrundberichte ausschließlich für die gedruckte Ausgabedes Mitarbeitermagazins.
- Dagegen sind sich die Teilnehmer ausnahmslos darin einig, dassaktuelle Nachrichten eher für digitale (vor allem mobile) Endgeräteprädestiniert sind. Nur 20,6 Prozent würden solche News auch im Print bringen.
- Vorstandsmitteilungen, Interviews oder Personalien können sich die Studienteilnehmer in beiden Formaten vorstellen.

#### Die Zukunft des gedruckten Mitarbeitermagazins

Bis dato hat die Printausgabe der Mitarbeiterzeitschrift nur wenig von ihrer Zugkraft verloren, obwohl sich zugleich der Ausbau der digitalen Kanäle in der internen Mitarbeiterkommunikation dynamisch weiterentwickelt und der Vertrieb des gedruckten Mitarbeitermagazins, der häufig über den Postversand erfolgt, kostenintensiver und aufwendiger ist als die der digitalen Versionen.Die Ergebnisse der jüngsten Studie zur Zukunft des Mitarbeitermagazins legen nahe, dass für beide Formate zum jetzigen Zeitpunkt gleichermaßen erkennbarer Bedarf besteht und sie sich entsprechend ergänzen:
- Derzeit erscheinen lediglich16,5 Prozent der Mitarbeitermagazine ausschließlich online.
- Auch 80,4 Prozent der Befragten aus Unternehmen ohne Mitarbeitermagazin sehen aktuell durchaus Bedarf für eine gedruckte Ausgabe.
Dennoch können sich nur wenige Experten das gedruckte Mitarbeitermagazin als wirklich zukunftssicheres Medium vorstellen. Bereits in früheren Studien ließen sich dabei für Print eher zurückhaltende Zukunftserwartungen erkennen:
- So gaben im Jahr 2014 noch 71,2 Prozent der Unternehmen, in denen eine MAZ erscheint, der gedruckten Ausgabe eine Zukunft. Im Folgejahr sank der Anteil der Print-Befürworter bereits auf 66,9 Prozent.
- Laut jüngster Studie sank der Anteil der redaktionell Verantwortlichen, die sich für eine langfristige Beibehaltung der Printausgabe aussprechen, im Jahr 2017 auf 65,9 Prozent, bei den Befragten ohne Mitarbeitermagazin im Unternehmen sind es nur noch 62,2 Prozent.
Zumindest mental scheint der Rückzug der Printausgaben folglich unausweichlich. Er vollzieht sich allerdings in der Praxis deutlich langsamer als die Zukunftsprognosen vermuten lassen.
Viele Unternehmen setzen stattdessen auf eine Multi-Channel-Strategie, bei der die Produktion der verschiedenen Kanäle stärker miteinander verzahnt wird, ohne den eigenständigen Charakter der jeweiligen Formate zu verwässern.

#### Die Bedeutung digitaler Medien

Bei den digitalen Formaten bestehen laut Studie zur „Zukunft der Mitarbeiterzeitschrift“ weitgehende Diskrepanzen zwischen Anspruch und Wirklichkeit. Auffallend ist vor allem, dass der Anteil der derzeit genutzten Formate stark von den Wunschvorstellungen der Studienteilnehmer abweicht, in deren Unternehmen bisher noch keine Mitarbeiterzeitschrift (MAZ) erscheint:
- BeispielApp: In diesem Format für Smartphone und Tablet wird das Mitarbeitermagazin bisher lediglichvon durchschnittlich 2,8 Prozent der befragten Unternehmenangeboten. Doch rund ein Drittel der Teilnehmer aus Unternehmen ohne MAZ sehen gerade in der App die Zukunft der Mitarbeiterzeitung. Das spiegelt sich auch in der hohen Einreichungsquote von Apps beim diesjährigenInkometa Awardfür Interne Kommunikation wieder.
- Auch der Anteil von Intranet-Publikationen ist mit 64,7 Prozent unter den Zukunftsprognosen fast doppelt so stark vertreten wie die derzeit zur Verfügung stehenden Angebote im Online (35,2 Prozent).
- Das ebenfalls viel genutzte statische PDF (54,5 Prozent) wird dagegen von der Gruppe ohne Mitarbeitermagazin mit einem Anteil von nur 19,6 Prozent in Zukunft deutlich seltener gewünscht.
Im Vergleich zu den Ergebnissen aus früheren Studien ist der Anteil des statischen PDF leicht zurückgegangen (2015: 60,2 Prozent) – vor allem zugunsten einer Nutzung dynamischer Inhalte im Intranet oder als mobile App. Doch die Herausgeber der Studie beklagen, dass die Frage, auf welchen Endgeräten und in welchen Formaten die Mitarbeiter die angebotenen Informationen tatsächlich optimal wahrnehmen, mangels entsprechender Erhebungen bislang offen bleibt.

#### Erfolgsmessung von Mitarbeiterzeitungen

Titel, Ideen, Themen, Konzepte, Aufbau,r Auszeichnungen und Vertrieb des Mitarbeitermagazins stehen häufig im Fokus von Agenturen und internen Redaktionen, wenn es um die Zukunft des Mitarbeitermagazins geht. Doch nur wenige Unternehmen messen regelmäßig den damit verbundenen Erfolg. Als Gründe für die mangelnde Evaluation werden vor allem fehlende Ressourcen (52 Prozent) und Budgets (16,9 Prozent) angeführt.
Im Gegensatz dazuwünschen sich 84,9 Prozentder befragten Experten für die Zukunft ihres Mitarbeitermagazinseine kontinuierliche Erfolgsmessung. Lediglich 5,4 Prozent legen keinen Wert darauf, zu erfahren, wie das Magazin von den Mitarbeitern im Unternehmen angenommen wird.
Die Herausgeber der MAZ-Studie vermuten, dass es Unternehmen im Redaktionsalltag teilweise an technischen und administrativen Voraussetzungen mangelt, um mit vertretbarem Aufwand eine regelmäßige Erfolgsmessung für ihre Mitarbeitermagazine zu realisieren.
Dabei ließe sich eine Evaluation vor allem auf digitale Weise erreichen. So könnte etwa die gezielte Nutzung von Social Software die Feedbackbereitschaft der Mitarbeiter stärken und dadurch hilfreiche Erkenntnisse zur Akzeptanz von Inhalten und Formaten der MAZ liefern:
- Laut Studie wird bereits in 63,9 Prozent der Unternehmen Social Software eingesetzt oder ist zumindest vorgesehen.
- Rund ein Viertel der Kommunikatoren (25,9 Prozent) wünscht sich eine intensivere Vernetzung zwischen MAZ und Social Software Anwendungen.
- In 24,7 Prozent der Unternehmen ist dies bereits geplant.
Die Nutzung von Social Software für die Erfolgsmessung der gedruckten oder digitalen MAZ könnte in der derzeitigen Transformationsphase zu einem wichtigen Instrument für die Auswahl von Themen und deren Aufbereitung sowie für die Form der Bereitstellung und die Distribution der MAZ avancieren. Darüber hinaus kommen weiterhin klassische Feedbackkanäle wie Leserbriefe, E-Mails oder Gewinnspielaktionen für die Zufriedenheitsabfrage der Mitarbeiter mit „ihrer MAZ“ in Frage.
Wichtiger Hinweis:Die Einreichungsphase für denInkometa Award2019 hat begonnen. Ab sofort können Sie Ihre Projekte aus der Internen Kommunikation aus 2017 & 2018 einreichen. Die Einreichungsfrist endet am 28. Januar 2019. Mehr Informationen dazu finden Siehier.
